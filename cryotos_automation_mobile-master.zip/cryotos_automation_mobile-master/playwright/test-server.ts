import express, { Request, Response } from 'express';
import { chromium } from 'playwright';
import { performLogin } from './utils/login';
import {  createBasicWorkOrder, WorkOrderData } from './utils/workorder';


const app = express();
const port = 3000;

// Middleware to parse JSON
app.use(express.json());

// Login endpoint
app.post('/api/login', async (req: Request, res: Response) => {
  try {
    const { url, username, password } = req.body;
    
    // Validate required parameters
    if (!url || !username || !password) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters: url, username, password'
      });
    }
    
    // Launch browser
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    
    try {
      // Perform login
      await performLogin(page, url, username, password);
      
      // Close browser
      await browser.close();
      
      res.json({
        success: true,
        message: 'Login test completed successfully'
      });
      
    } catch (error) {
      await browser.close();
      res.status(500).json({
        success: false,
        error: `Login test failed: ${error instanceof Error ? error.message : String(error)}`
      });
    }
    
  } catch (error) {
    res.status(500).json({
      success: false,
      error: `Server error: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Work Order creation endpoint
app.post('/api/create-workorder', async (req: Request, res: Response) => {
  try {
    const { loginUrl, username, password, asset, workflow, description, account, location } = req.body;
    
    // Validate required parameters
    if (!loginUrl || !username || !password || !asset || !workflow || !description) {
      return res.status(400).json({
        success: false,
        error: 'Missing required parameters: loginUrl, username, password, asset, workflow, description'
      });
    }
    
    // Launch browser
    const browser = await chromium.launch({ headless: false });
    const page = await browser.newPage();
    
    try {
      // First login
      await performLogin(page, loginUrl, username, password);
      
      // Create work order data
      const workOrderData: WorkOrderData = {
        account,
        location,
        asset,
        workflow,
        description
      };
      
      // Create work order
      await createBasicWorkOrder(page, workOrderData);
      
      // Close browser
      await browser.close();
      
      res.json({
        success: true,
        message: 'Work order created successfully'
      });
      
    } catch (error) {
      await browser.close();
      res.status(500).json({
        success: false,
        error: `Work order creation failed: ${error instanceof Error ? error.message : String(error)}`
      });
    }
    
  } catch (error) {
    res.status(500).json({
      success: false,
      error: `Server error: ${error instanceof Error ? error.message : String(error)}`
    });
  }
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'OK', message: 'Login test server is running' });
});

app.listen(port, () => {
  console.log(`Login test server running on http://localhost:${port}`);
});
