# Playwright Web Testing

This directory contains the Playwright web testing framework for the CMMS application.

## Overview

This is a separate testing framework focused on web-based testing using Playwright, providing clear separation from the Maestro mobile testing framework.

## Structure

```
playwright/
├── package.json          # Playwright-specific dependencies
├── tsconfig.json         # TypeScript configuration
├── test-server.ts        # Express server with REST API endpoints
├── tests/                # Playwright test files
│   ├── login.spec.ts     # Login functionality tests
│   └── workorder.spec.ts # Work order creation tests
└── utils/                # Reusable utility functions
    ├── login.ts          # Login utilities
    └── workorder.ts      # Work order utilities
```

## Installation

```bash
# Install dependencies
yarn install

# Install Playwright browsers
yarn install-browsers
```

## Usage

### Running Tests
```bash
yarn test
```

### Starting API Server
```bash
yarn start
```

### Development Mode (with auto-reload)
```bash
yarn dev
```

## API Endpoints

The test server provides REST API endpoints for programmatic testing:

### Login Endpoint
- **POST** `/api/login`
- **Body**: `{ "url": "string", "username": "string", "password": "string" }`
- **Response**: `{ "success": boolean, "message": "string" }`

### Work Order Creation Endpoint
- **POST** `/api/create-workorder`
- **Body**: `{ "loginUrl": "string", "username": "string", "password": "string", "asset": "string", "workflow": "string", "description": "string", "account": "string", "location": "string" }`
- **Response**: `{ "success": boolean, "message": "string" }`

### Health Check Endpoint
- **GET** `/health`
- **Response**: `{ "status": "OK", "message": "Login test server is running" }`

## Running from Root Directory

You can also run Playwright commands from the root directory:

```bash
# From root directory
yarn playwright:test
yarn playwright:start
yarn playwright:dev
yarn playwright:install
```

## Dependencies

- **@playwright/test**: Playwright testing framework
- **express**: Web server for API endpoints
- **typescript**: TypeScript support
- **ts-node**: TypeScript execution

## Configuration

- **playwright.config.ts**: Playwright configuration (inherited from root)
- **tsconfig.json**: TypeScript configuration for this directory
- **package.json**: Dependencies and scripts specific to Playwright testing

## Integration

This Playwright framework works alongside the Maestro mobile testing framework, providing:
- Web-based testing capabilities
- REST API endpoints for programmatic testing
- Reusable utilities for common CMMS operations
- Clear separation from mobile testing concerns

