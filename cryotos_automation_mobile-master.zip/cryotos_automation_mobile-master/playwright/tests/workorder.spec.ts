import { test } from '@playwright/test';
import { performLogin } from '../utils/login';
import { createBasicWorkOrder, WorkOrderData } from '../utils/workorder';

test('create work order with basic fields', async ({ page }) => {
  // Login first
  await performLogin(page, 'https://stage.cryotos.com/#/login', 'admin@test.com', 'Admin@2022');
  
  // Create work order data
  const workOrderData: WorkOrderData = {
    asset: 'DELL LAPTOP (3600)',
    workflow: 'Flutter testing with all fields',
    description: 'Hello PlayWright Test Work Order'
  };
  
  // Create work order
  await createBasicWorkOrder(page, workOrderData);
});
