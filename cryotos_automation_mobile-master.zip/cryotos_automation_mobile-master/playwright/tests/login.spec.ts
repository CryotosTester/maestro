import { test } from '@playwright/test';
import { performLogin } from '../utils/login';

test('login with valid credentials', async ({ page }) => {
  const url = 'https://stage.cryotos.com/#/login';
  const username = 'admin@test.com';
  const password = 'Admin@2022';
  
  await performLogin(page, url, username, password);
});

