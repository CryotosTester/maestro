import { Page, expect } from '@playwright/test';

// Reusable login function for API server
export async function performLogin(page: Page, url: string, username: string, password: string) {
  await page.goto(url);
  await page.getByRole('textbox', { name: 'Email' }).click();
  await page.getByRole('textbox', { name: 'Email' }).fill(username);
  await page.getByRole('textbox', { name: 'Email' }).press('Tab');
  await page.getByRole('textbox', { name: 'Password' }).fill(password);
  await page.getByRole('button', { name: 'Login' }).click();
  
  
  // Wait for successful login indicator - use a more specific selector
  await expect(page.getByRole('link', { name: 'Dashboard', exact: true })).toBeVisible();
}
