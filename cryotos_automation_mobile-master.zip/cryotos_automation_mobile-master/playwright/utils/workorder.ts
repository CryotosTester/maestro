import { Page, expect } from '@playwright/test';

export interface WorkOrderData {
  account?: string;
  location?: string;
  asset: string;
  workflow: string;
  description: string;
}


// Simple and reliable work order creation following the exact user workflow
export async function createBasicWorkOrder(page: Page, workOrderData: WorkOrderData) {
  const { asset, workflow, description } = workOrderData;

  // Navigate to Work Orders
  await page.getByRole('link', { name: 'Maintenance' }).click();
  
  // Wait for the Maintenance menu to expand and Work Orders link to be visible
  await page.waitForTimeout(2000);
  await page.waitForSelector('a[href*="request"], link:has-text("Work Orders")', { timeout: 10000 });
  
  await page.getByRole('link', { name: 'Work Orders' }).click();

  // Click Create Work Order button
  await page.getByRole('button', { name: ' Work Order' }).click();

  // Wait for the form to load
  await page.waitForTimeout(2000);

  // Fill Asset Name - use search term approach like user's script
  await page.getByRole('combobox', { name: 'Asset Name' }).click();
  
  // Use first few characters for search (like 'Gener' for 'Generator')
  const assetSearchTerm = asset.substring(0, Math.min(5, asset.length));
  await page.getByRole('combobox', { name: 'Asset Name' }).fill(assetSearchTerm);
  await page.waitForTimeout(2000); // Wait for search results
  
  // Click on the exact asset name
  await page.getByText(asset).click();

  // Wait for asset selection to complete (this auto-fills Account and Location)
  await page.waitForTimeout(2000);

  // Fill Workflow Name - CODEGEN PATTERN: locator(mat-option).getByText()
  const workflowSearchTerm = workflow.substring(0, Math.min(10, workflow.length));
  await page.getByRole('combobox', { name: 'Workflow Name' }).click();
  await page.getByRole('combobox', { name: 'Workflow Name' }).fill(workflowSearchTerm);
  
  // Wait for dropdown to populate
  await page.waitForTimeout(2000);
  
  // CRITICAL: Find mat-option container first, then text inside it (like codegen)
  // This prevents clicking workflow text elsewhere on the page
  await page.locator('mat-option').getByText(workflow).first().click();

  // CRITICAL: Wait for the workflow form to load completely
  // The description field and entire form only appear after workflow selection
  await page.waitForTimeout(5000);

  await page.locator('.mat-select-placeholder').first().click();

  await page.getByText('Urgent').click();
 

  // Fill Description in the Basic Information section
  await page.getByRole('textbox', { name: 'Description' }).scrollIntoViewIfNeeded();
  await page.getByRole('textbox', { name: 'Description' }).click();
  await page.getByRole('textbox', { name: 'Description' }).fill(description);

  // Scroll down to find the "Next form copy Request" button
  await page.evaluate(() => {
    window.scrollTo(0, document.body.scrollHeight);
  });
  
  // Wait for the button to be visible

  
  // Click "Next form copy Request" to proceed to employee assignment
  await page.getByRole('link', { name: 'Submit to Technician' }).click();


  // Wait for employee assignment dialog to fully load
  await page.waitForSelector('.modal.ng-star-inserted', { timeout: 10000 });
  await page.waitForTimeout(3000);

  // await page.getByText('Select All Users').click();

  // Try multiple approaches to click the checkbox
  // try {
  //   // First try: Wait for checkbox and click normally
  //   await page.waitForSelector('[id^="mat-checkbox-"]', { timeout: 5000 });
  //   await page.locator('[id^="mat-checkbox-"] > .mat-checkbox-layout > .mat-checkbox-inner-container').first().click();
  // } catch (error) {
  //   console.log('Trying force click to assign employee...');
  //   // Second try: Force click to bypass modal interception
  //   await page.locator('[id^="mat-checkbox-"] > .mat-checkbox-layout > .mat-checkbox-inner-container').first().click({ force: true });
  // }

  await page.getByText('Select All Users').click();


  console.log('Submitting the work order...');
  // Submit the work order
  await page.getByRole('button', { name: 'Submit' }).click();

  // Wait for successful creation (redirect back to work orders list)
  await page.waitForTimeout(3000);
}