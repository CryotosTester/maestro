# Maestro-Playwright MCP Integration Testing

This directory contains the bi-directional integration between Maestro mobile testing and Playwright web testing using **Playwright MCP (Model Context Protocol)** tools.

## Overview

The integration allows Maestro tests to configure parameters and then use Playwright MCP tools directly for web browser testing, enabling comprehensive cross-platform testing.

## Architecture

```
Maestro Test → Configure Parameters → Playwright MCP Tools → Browser Test → Results
```

## Setup Instructions

### 1. Run Maestro Integration Test

```bash
# Navigate to Mobile Automation Testing directory
cd "Mobile Automation Testing"

# Run the integration test with environment and credentials
maestro test tests/integration/playwright-login.yaml --env ENV=stage USERNAME=admin@test.com PASSWORD=admin@2022
```

## Environment Configuration

The system supports three environments with direct login URLs:

- **dev**: `http://localhost:9000/#/login`
- **stage**: `https://stage.cryotos.com/#/login`
- **prod**: `https://app.cryotos.com/#/login`

## Playwright MCP Tools Usage

After running the Maestro test, use these Playwright MCP tools:

### 1. Navigate to Login Page
```javascript
// Use the URL from Maestro test configuration
mcp_mcp-playwright_browser_navigate({ url: "https://stage.cryotos.com/#/login" })
```

### 2. Fill Email Field
```javascript
mcp_mcp-playwright_browser_type({
  element: "Email textbox",
  ref: "email-field-ref",
  text: "admin@test.com"
})
```

### 3. Fill Password Field
```javascript
mcp_mcp-playwright_browser_type({
  element: "Password textbox", 
  ref: "password-field-ref",
  text: "admin@2022"
})
```

### 4. Click Login Button
```javascript
mcp_mcp-playwright_browser_click({
  element: "Login button",
  ref: "login-button-ref"
})
```

### 5. Verify Success
```javascript
mcp_mcp-playwright_browser_snapshot()
```

## File Structure

```
Mobile Automation Testing/
├── tests/integration/
│   └── playwright-login.yaml     # Maestro test that configures parameters
└── shared/
    └── config.js                 # Configuration with MCP settings
```

## Testing Flow

1. **Run Maestro Test**: Execute the integration YAML file with environment and credentials
2. **Maestro Configures**: Sets up environment URLs and credentials
3. **Use Playwright MCP**: Direct browser automation using MCP tools
4. **Verify Results**: Check login success and take screenshots

## Example Usage

```bash
# Test stage environment
maestro test tests/integration/playwright-login.yaml --env ENV=stage USERNAME=admin@test.com PASSWORD=admin@2022

# Test dev environment  
maestro test tests/integration/playwright-login.yaml --env ENV=dev USERNAME=admin@test.com PASSWORD=admin@2022

# Test prod environment
maestro test tests/integration/playwright-login.yaml --env ENV=prod USERNAME=admin@test.com PASSWORD=admin@2022
```

## Benefits of MCP Approach

- **Direct Integration**: No server needed, direct tool usage
- **Simple**: Minimal code, maximum functionality
- **Flexible**: Easy to extend with more MCP tools
- **Efficient**: No HTTP overhead, direct browser control
- **Maintainable**: Clear separation of concerns

## Troubleshooting

### MCP Tools Not Available
- Ensure you're in an environment with Playwright MCP tools enabled
- Check that browser is properly installed

### Login Failures
- Verify credentials are correct
- Check if the website is accessible
- Ensure selectors match the current page structure

## Future Enhancements

- Add more test scenarios (registration, password reset, etc.)
- Implement test result validation
- Add screenshot comparison
- Integrate with CI/CD pipelines
- Add parallel test execution