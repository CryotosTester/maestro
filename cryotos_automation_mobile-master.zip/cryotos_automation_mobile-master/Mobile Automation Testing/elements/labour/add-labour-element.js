// Add Labour element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

if (typeof output.labour === "undefined") output.labour = {};

Object.assign(output.labour, {
    addLabour: 'add_Labour',
    addLabourTask: 'add_labour_task',
    user: 'User',
    loginTime: 'login_time',
    logoutTime: 'logout_time',
    workingHours: 'working_hours',
    descriptionField: 'description_field',
    addButton: 'add_button',
 
});

