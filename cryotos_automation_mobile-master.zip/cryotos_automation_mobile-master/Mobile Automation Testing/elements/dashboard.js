// Dashboard element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Dashboard element selectors - MERGE with existing dashboard object
if (typeof output.dashboard === "undefined") output.dashboard = {};

Object.assign(output.dashboard, {
    // Header elements
    menuButton: 'menu_button',
    dashboardTitle: 'dashboard_title',
    
    // Main action buttons
    createWorkOrder: 'Create Work Order',
    scanQR: 'Scan QR',
    workRequest: 'Work Request',
    myCreation: 'My Creation',
    involvedTask: 'Involved Task',
    
    // Filter elements
    requestTypeLabel: 'Request Type',
    allButton: 'All',
    durationLabel: 'Duration',
    thisMonthButton: 'This Month',
    filterIcon: 'filter_icon',
    
    // Checkbox and labels
    assignedToMeCheckbox: 'Assigned to Me',
    totalRequestsLabel: 'Total Requests',
    totalRequestsCount: '61',
    
    // Status cards
    overdue: 'Overdue',
    closedCompleted: 'Closed - Completed',
    workInProgress: 'Work in Progress',
    pendingWithReason: 'Pending with Reason',
    closedIncomplete: 'Closed - Incomplete',
    rejected: 'Rejected',
    
    // View and time period
    viewLabel: 'View',
    yearlyButton: 'Yearly',
    monthLabel: 'Month',
    october2025Button: 'October 2025',
    
    // Asset downtime section
    assetDowntimeLabel: 'Asset Downtime',
    totalDowntimeHoursLabel: 'Total Downtime Hours',
    totalDowntimeCountLabel: 'Total Downtime Count',
    downtimeHoursValue: '336.25',
    downtimeCountValue: '7',
    
    // Bottom navigation tabs
    myTaskTab: 'My Task',
    assetTab: 'Asset',
    inventoryTab: 'Inventory',
    meterTab: 'Meter'
});








