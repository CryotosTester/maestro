if (typeof output === "undefined") {
    output = {};
}

// Dashboard element selectors - MERGE with existing dashboard object
if (typeof output.meterReading === "undefined") output.meterReading = {};

Object.assign(output.meterReading, {

  list:{
    meterReadingList: 'meter_reading_list',
    searchIcon: 'search_icon',
    qrScanIcon: 'qr_scan_icon',
    closeSearchIcon: 'close_search_icon',
  },
  details:{
    meterReadingDetails: 'Meter Reading Details',
    historyButton: 'history_button',
    updateReadingButton: 'update_reading_button',
    backButton: 'back_button',
    assetName: 'Asset Name (Serial Number)',
    currentMeterReading: 'Current Meter Reading',
  },

  history:{
    filterButton: 'assigned_filter',
    downloadButton: 'Download',
    backButton: 'Back',
    applyFilters: 'Apply Filters',
    resetFilters: 'Reset Filters',
    filterClose: 'filter_close',
    dismiss: 'Dismiss',
    search: 'Search',
  }

})
