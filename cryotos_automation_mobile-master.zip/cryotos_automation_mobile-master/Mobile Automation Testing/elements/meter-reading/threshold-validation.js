// Meter Threshold elements
output.meterThreshold = {
    viewDetails: 'View Details',
    configureThreshold: 'Configure Threshold Action',
    actionType: 'Action Type',
    priority: 'Priority',
    saveConfig: 'Save Configuration'
};
