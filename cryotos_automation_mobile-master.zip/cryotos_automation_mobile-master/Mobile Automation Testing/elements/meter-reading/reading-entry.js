// Meter Reading Entry elements
output.meterEntry = {
    meterReadingBtn: 'Meter Reading',
    currentReading: 'Current Reading',
    readingNotes: 'Reading Notes',
    submitReading: 'Submit Reading',
    newReading: 'New Reading'
};
