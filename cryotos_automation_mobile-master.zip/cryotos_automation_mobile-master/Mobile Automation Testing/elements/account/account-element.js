if (typeof output === "undefined") {
    output = {};
}

// Account element selectors
if (typeof output.account === "undefined") output.account = {};

Object.assign(output.account, {

  // Account list page
  list: {
    accountMenu: 'Account',
    addButton: 'Add',
    searchButton: 'Search'
  },

  // Account creation page
  accountCreation: {
    accountName: 'Account Name',
    accountType: 'Account Type',
    customerOption: 'Customer',
    email: 'Email',
    phone: 'Phone',
    gstVatNo: 'GST-VAT No',
    registrationNumber: 'Registration Number',
    saveButton: 'Save',
    cancelButton: 'Cancel',
    errorMessage: 'Account Name is Required'
  },

  // Account edit/details page
  accountDetails: {
    editButton: 'Edit',
    accountDetailTab: 'Account Detail',
    backButton: 'Back',
    associatedLocationsTab: 'Associated Locations',
    contactDetailsTab: 'Contact Details',
    primaryEmail: 'Primary Email',
    primaryPhone: 'Primary Phone',
    businessDetailsTab: 'Business Details',
    vatNo: 'VAT No',
    registrationNumber: 'Registration Number',
    sqFt: 'sq.ft',
    address: 'Address'
  },

  // Associated location section
  associatedLocation: {
    searchButton: 'Search',
    addButton: 'Add',
    noResultsFound: 'No Results Found'
  },

  // Location creation page
  locationCreation: {
    locationName: 'Location Name',
    address: 'Address',
    stateDropdown: 'state',
    account: 'account',
    parentLocation: 'parent_location',
    locationTypeDropdown: 'location_type',
    tenantDropdown: 'tenant',
    cancelButton: 'Cancel',
    saveButton: 'Save'
  },

  // Location edit/details page
  locationDetails: {
    editButton: 'Edit',
    locationDetailTab: 'Location Detail',
    contactDetailsTab: 'Contact Details',
    address: 'Address',
    state: 'State',
    parentLocation: 'Parent Location',
    locationType: 'Location Type',
    tenant: 'Tenant',
    createWorkRequestButton: 'Create Work Request'
  }

});
