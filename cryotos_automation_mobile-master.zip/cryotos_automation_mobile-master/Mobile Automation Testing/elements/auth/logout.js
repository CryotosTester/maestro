// Logout element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Logout element selectors - MERGE with existing logout object
if (typeof output.logout === "undefined") output.logout = {};

Object.assign(output.logout, {
    // Logout menu and buttons
    menuButton: "menu_button",
    logoutButton: "Log Out",
    logoutText: "Log Out",
    
    // Alternative logout elements
    signOut: "sign_out",
    exitButton: "exit_button",
    
    // Confirmation dialogs
    confirmLogout: "confirm_logout",
    cancelLogout: "cancel_logout",
    
    // Logout page elements
    logoutTitle: "Logout",
    logoutMessage: "Are you sure you want to logout?"
});