// Login element definitions for CMMS Mobile App
 
if (typeof output === "undefined") {
    output = {};
}
 
// Login element selectors - MERGE with existing login object
if (typeof output.login === "undefined") output.login = {};
 
Object.assign(output.login, {
    // Login form fields
    usernameField: 'user_field',
    passwordField: 'password_field',
    loginButton: 'login_button',
   
    // Alternative field names (if different IDs are used)
    emailField: 'email_field',
    userField: 'user_field',
   
    // Login page elements
    loginTitle: 'Login',
    forgotPassword: 'forgot_password',
    rememberMe: 'remember_me',
   
    // Error messages
    invalidCredentials: 'Invalid credentials',
    loginError: 'Login failed'
});
 
 
if (typeof output.loginErrorMessage === "undefined" ) output.loginErrorMessage ={};
   
Object.assign(output.loginErrorMessage, {
    invalidCredentials: 'Invalid credentials. Please try again',
    loginError: 'Login Failed',
    accessDenied: 'Access Denied',
    maxLoginAttempts: 'Maximum login attempt exceeded. Please try again after 10 minutes',
   
});
   
 