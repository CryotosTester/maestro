// Pending with Reason Elements
// Elements for pending status with reason functionality

if (typeof output === "undefined") {
    output = {};
}

// Pending with Reason Structure - MERGE with existing pendingWithReason object
if (typeof output.pendingWithReason === "undefined") output.pendingWithReason = {};

Object.assign(output.pendingWithReason, {
    // Dropdown for selecting reason category
    commentsDropdown: "comments_for_Pending_dropdown",
    
    // Reason options
    others: "Others",
    
    // Text field for entering reason
    reasonInput: "reason_for_Pending",
    
    // Buttons
    saveButton: "save_button",
    cancelButton: "cancel_button",
    backButton: "back"
});


