// Asset element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Asset element selectors - MERGE with existing asset object
if (typeof output.asset === "undefined") output.asset = {};

Object.assign(output.asset, {
    // Header Navigation elements
    headerNavigation: {
        updateAsset: 'update_asset',
        assetDetail: 'Asset Detail'
    },
    
    // Status elements
    status: {
        active: 'Active'
    },
    
    // Action elements
    actions: {
        updateImage: 'update_image'
    },
    
    // Section Navigation elements
    sectionNavigation: {
        attachments: 'Attachments',
        parts: 'Parts',
        maintenanceHistory: 'Maintenance History',
        transferHistory: 'Transfer History',
        calendar: 'Calendar'
    },
    
    // Work Order elements
    workOrder: {
        createWorkOrder: 'createWo'
    },
    
    // Asset List elements
    assetFilterList: {
        searchIcon: 'search_icon',
        searchField: 'asset_search_textfield',
        filterButton: 'filter_button',
        sortButton: 'sort_button'
    },
    
    // Asset Details Form elements
    assetDetails: {
        assetImage: 'view_asset_image',
        serialNoField: 'Enter serial no',
        assetNameField: 'Enter Asset Name',
        machineCodeField: 'Enter machine code',
        partNoField: 'Enter part no',
        categoryDropdown: 'Category',
        departmentDropdown: 'Department',
        updateButton: 'update_button',
        clearCategory: 'clear_Category',
        clearDepartment: 'clear_Department'
    }
});