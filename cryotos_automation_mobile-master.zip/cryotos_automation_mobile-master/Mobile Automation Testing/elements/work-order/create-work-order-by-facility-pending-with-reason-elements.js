// Element IDs for Maestro Test Automation
// Initialize output object if it doesn't exist
if (typeof output === 'undefined') {
    output = {};
}

// Dashboard elements
output.dashboard = {
    closedCompleted: "Closed - Completed",
    createWorkOrder: "Create Work Order",
    pendingWithReason: "Pending with Reason",
    search: "search",
    basicDetails: "basic_details",
    viewMiningDetails: "view_Mining Facility Maintenance Request_details"
};

// Work Order elements
output.workorder = {
    facilityTab: "facility_tab",
    locationId: "Location",
    workflowId: "Workflow",
    priorityInput: "priority_input",
    priorityLabel: "Priority",
    descriptionInput: "description_input",
    descriptionLabel: "Description",
    faultOccurrenceTime: "Fault Occurrence Time",
    requestingDepartment: "Requesting Department",
    equipmentIdentifier: "Equipment Identifier",
    equipmentIdentifierLabel: "Equipment Identifier",
    faultDescription: "Fault Description",
    faultDescriptionLabel: "Fault Description",
    saveButton: "save_button",
    submitButton: "submit_button",
    userSearch: "user_search",
    iyneshwarCheckbox: "Iyneshwar _checkbox"
};

// Assessment elements
output.assessment = {
    miningMaintenanceAssessment: "Mining Maintenance Assessment",
    commentsForPending: "comments_for_Pending_dropdown",
    reasonFromPendingLabel: "Reason for Pending",
    reasonForPending: "reason_for_Pending",
    commentsForPendingLabel: "Comments for Pending"
};

// Asset Downtime elements
output.downtime = {
    downtime: 'Downtime',
    downtimeStart: 'downtime_start',
    downtimeEnd: 'downtime_end',
    issueType: 'Issue Type',
    rootCause: 'Root Cause',
    correctiveAction: 'Correctuive Action',
    saveClose: 'Save & Close'
};

// Common UI elements
output.common = {
    chennai: "CHENNAI",
    miningWorkflow: "Mining Facility Maintenance Workflow",
    urgent: "URGENT",
    processingPlant: "Processing Plant",
    others: "Others",
    selectDate: "Select date",
    ok: "OK"
};

// Work in Progress form elements
output.workInProgress = {
    // Status actions
    acknowledge: "Acknowledge",
    updateStatus: "Update Status",
    
    // Priority classification
    priorityClassification: "Priority Classification",
    criticalProduction: "Critical.*Production",
    preliminaryRootCause: "Preliminary Root Cause",
    plannedMaintenanceWindow: "Planned Maintenance Window",
    
    // Maintenance assignment
    assignedMaintenanceCrew: "Assigned Maintenance Crew",
    mechanicalCrewA: "Mechanical Crew A",
    
    // Work order closure
    miningWorkOrderClosure: "Mining Work Order Closure",
    workInProgressTab: "Work in Progress",
    
    // Details view
    viewMiningAssessmentDetails: "view_Mining Maintenance Assessment_details"
};

// Work Order Closure form elements
output.workOrderClosure = {
    // Status actions
    updateStatus: "Update Status",
    
    // Closure fields
    correctiveActionSummary: "Corrective Action Summary",
    equipmentOperationalStatus: "Equipment Operational Status",
    temporarilyOperational: "Temporarily Operational",
    downtimeDuration: "Downtime Duration.*",
    maintenanceSupervisor: "Maintenance Supervisor.*",
    saveButton: "Save",
    closeButton: "Close",
    
    // Details view
    viewMiningWorkOrderClosureDetails: "view_Mining Work Order Closure_details",
    
    // Labels for assertions
    updatedByLabel: "updated_by",
    priorityLabel: "Priority",
    descriptionLabel: "Description",
    correctiveActionSummaryLabel: "Corrective Action Summary",
    equipmentOperationalStatusLabel: "Equipment Operational Status",
    downtimeDurationLabel: 'Downtime Duration .*Hours.*',
    maintenanceSupervisorSignoffLabel: "Maintenance Supervisor Sign-off"
};

// Make elements available globally
if (typeof module !== 'undefined' && module.exports) {
    module.exports = output;
} else {
    this.output = output;
}
