// Acknowledge Work Order element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Acknowledge Work Order element selectors - MERGE with existing acknowledge object
if (typeof output.acknowledge === "undefined") output.acknowledge = {};

Object.assign(output.acknowledge, {
    // Acknowledge Work Order elements
    acknowledge: 'Acknowledge',
    checkIn: 'Check In',
    updateStatus: 'Update Status'
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        acknowledge: output.acknowledge
    };
}

