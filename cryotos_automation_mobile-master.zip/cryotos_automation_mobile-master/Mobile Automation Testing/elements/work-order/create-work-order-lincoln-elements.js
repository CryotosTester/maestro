// Work Order element definitions for Lincoln CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Form 1 Elements - Work Order Creation
if (typeof output.lincolnForm1 === "undefined") output.lincolnForm1 = {};

Object.assign(output.lincolnForm1, {
    // Account and Location
    account: 'Account',
    location: 'Location',
    state: 'State',
    asset: 'Asset',
    
    // Workflow and Priority
    workflow: 'Workflow',
    priorityInput: 'priority_input',
    descriptionInput: 'description_input',
    expectedEndDate: 'expected_end_date_input',
    
    // Dates and Submission
    complaintReceivedOn: 'Complaint Received on',
    submitForWorkOrder: 'Submit For Work Order',
    
    // Search
    search: 'search'
});

// Validation Elements
if (typeof output.lincolnValidation === "undefined") output.lincolnValidation = {};

Object.assign(output.lincolnValidation, {
    // Details and Assertions
    basicDetails: 'basic_details',
    workflowBreakDown: 'Workflow.*Break Down',
    accountValue: 'Account.*gvzmb50467',
    locationValue: 'Location.*AssetNamefnu87404',
    
    // View and Status Elements
    viewRequestDetails: 'view_Request_details',
    priority: 'Priority',
    description: 'Description',
    complaintReceivedDate: 'Complaint Received on',
    
    // Action Buttons
    acknowledge: 'Acknowledge',
    checkIn: 'Check in',
    updateStatus: 'Update Status'
});

// Form 2 Elements - Maintenance Completion
if (typeof output.lincolnForm2 === "undefined") output.lincolnForm2 = {};

Object.assign(output.lincolnForm2, {
    // Maintenance Details
    replacedPartNumbers: 'Replaced Part Numbers',
    observation: 'Observation',
    actionTaken: 'Action Taken',
    customerRemarks: 'Customer Remarks',
    customerSignature: 'Customer Signature',
    
    // Customer Type and Status
    nonKeyCustomer: 'Non Key Customer',
    completed: 'Completed',
    
    // Additional Elements (based on original flow)
    save: 'Save',
    excellent: 'Excellent',
    complaintRegisteredOn: 'Complaint Registered On',
    keyCustomer: 'Key Customer',
    email1: 'Email 1',
    confirmEmails: 'Confirm Emails'
});

// Test Data Values
if (typeof output.lincolnTestData === "undefined") output.lincolnTestData = {};

Object.assign(output.lincolnTestData, {
    // Default Values
    workflowType: 'Break Down',
    priority: 'URGENT',
    accountPrefix: 'jpcmi',
    locationPrefix: 'AssetName',
    customerEmail: 'e218@minusculetechnologies.com'
});
  

// Test Data Values
if (typeof output.lincolnAsset === "undefined") output.lincolnAsset = {};

Object.assign(output.lincolnAsset, {
    // Create Asset Form Elements
    createAsset: 'Create Asset',
    serialNo: 'Enter Serial No',
    assetName: 'Enter Asset Name',
    machineCode: 'Enter Machine Code',
    partNo: 'Enter Part No',
    category: 'Category',
    department: 'Department',
    createButton: 'create_button'
});