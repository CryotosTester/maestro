// Work Order element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Work Order element selectors - MERGE with existing workorder object
if (typeof output.workorder === "undefined") output.workorder = {};

Object.assign(output.workorder, {
    // Main work order elements
    moreButton: 'more_button',
    backButton: 'back_button',
    qrScan: 'qr_scan',
    
    // Tab elements
    facilityTab: 'facility_tab',
    assetTab: 'asset_tab',
    
   // clear
    clearAccount: 'clear_Account',
     clearLocation: 'clear_Location',
     clearAsset: 'clear_Asset',
     clearWorkflow: 'clear_Workflow',

    // Form input fields with actual IDs from device
    accountId: 'Account',
    locationId: 'Location',
    assetId: 'Asset',
    workflowId: 'Workflow',
    priorityId: 'priority_input',
    descriptionInputId: 'description_input',
    dateTimeInputId: 'expected_end_date_textfield',
    
    //users - Role-based mappings
    requesterManager: 'Malar',
    facilityManager: 'Asmin',
    verifier: 'Arunkumar',
    fieldTechnician: 'Naren',
    seniorTechnician: 'Iyneshwar',
   
   //checkboxes
    selectAll: 'select_all_users_checkbox',
    requesterManagerCheckbox: 'Malar _checkbox',
    facilityManagerCheckbox: 'Asmin _checkbox',
    verifierCheckbox: 'Arunkumar _checkbox',
    fieldTechnicianCheckbox: 'Naren _checkbox',
    seniorTechnicianCheckbox: 'Iyneshwar _checkbox',
   

    // Submit to Technician
    submitToTechnician: 'Submit to Technician',
    userSearch: 'user_search',
    workOrder: 'Work Order',
    wip: 'WIP',

    //search
    search: 'search',
    clearId: 'Clear Search',
  
});

if (typeof output.workorder === "undefined") output.workorder = {};



Object.assign(output.workorder, {

    headers: {
            facilityTab: 'facility_tab',
            assetTab: 'asset_tab',
            moreButton: 'more_button',
            backButton: 'back_button',
            qrScan: 'qr_scan',
            addLabour: 'add_Labour',
            addParts :'add_Part'                
     },
     form:{
           account: 'Account',
           location: 'Location',
           state: 'State',
           asset:'Asset'
     } ,
     bottomFields:{
            addParts: 'add_part',
            addLabour: 'add_labour'
     }


    })

