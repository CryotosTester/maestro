// Work Order Creation elements
output.workOrder = {
    createBtn: 'Create Work Order',
    assetTab: 'asset_tab',
    facilityTab: 'facility_tab',
    asset: 'Asset',
    workflow: 'Workflow',
    priorityInput: 'priority_input',
    descriptionInput: 'description_input',
    submitToTechnician: 'Submit to Technician',
    submitBtn: 'Submit'
};

