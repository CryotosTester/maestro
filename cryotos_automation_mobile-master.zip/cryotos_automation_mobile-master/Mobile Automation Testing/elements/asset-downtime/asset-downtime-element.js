// Asset Downtime Element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

if (typeof output.downtime === "undefined") output.downtime = {};

Object.assign(output.downtime, {
    downtime: 'Downtime',
    downtimeStart: 'downtime_start',
    downtimeEnd: 'downtime_end',
    issueType: 'issue_type',
    rootCause: 'Root Cause',
    correctiveAction: 'Correctuive Action',
    saveClose: 'Save & Close',
   totalDowntimeTaken: 'total_downtime_taken',  
   downtimeCategory: 'downtime_category',
   cancelClose: 'Cancel & Close',
   addDowntime: 'add_Downtime',
    


});

