// Asset Downtime elements
output.downtime = {
    downtime: 'Downtime',
    downtimeStart: 'downtime_start',
    downtimeEnd: 'downtime_end',
    issueType: 'Issue Type',
    rootCause: 'Root Cause',
    correctiveAction: 'Correctuive Action',
    saveClose: 'Save & Close'
};
