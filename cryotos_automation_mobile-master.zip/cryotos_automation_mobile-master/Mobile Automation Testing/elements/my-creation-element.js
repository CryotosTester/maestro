// My Creation Elements
// Elements for drafts and "My Creation" tab
 
if (typeof output === "undefined") {
    output = {};
}
 
if (typeof output.myCreation === "undefined") {
    output.myCreation = {};
}
 
Object.assign(output.myCreation, {
    // Drafts tab identifier
    draftsTab: "drafts_tab",
    progressTab: "progress_tab",
    searchButton: "search_button"
});
 
 