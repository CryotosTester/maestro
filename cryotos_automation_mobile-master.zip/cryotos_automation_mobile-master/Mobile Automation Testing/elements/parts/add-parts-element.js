// Add Parts element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Add Parts element selectors - MERGE with existing parts object
if (typeof output.parts === "undefined") output.parts = {};

Object.assign(output.parts, {
    // Main parts elements
   
    backButton: 'back_button',
    addParts: 'add_Part',
    partName: 'Part Name',
    qrScan: 'qr_scan',
    warehouse: 'Warehouse',
    binLocation: 'Bin Location',
    consumedQuantity: 'consumed_quantity',
    minusIcon: 'minus_icon',
    plusIcon: 'plus_icon',
    addPartsIcon: 'add_parts_icon',
    cancelButton: 'cancel_button',
    saveButton: 'save_button',
    addConsumedParts: 'add_consumed_parts',
    clearPartName: 'Clear Part Name',
    clearWarehouse: 'Clear Warehouse',
    searchPartName: 'Search by Part Name',
    searchWarehouse: 'Search by Warehouse',
    addPartsIcon: 'add_parts_icon',

    

});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        parts: output.parts
    };
}

