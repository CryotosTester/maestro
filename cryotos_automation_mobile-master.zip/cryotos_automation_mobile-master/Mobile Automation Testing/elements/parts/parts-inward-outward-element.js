// Parts inward/outward element definitions for CMMS Mobile App

if (typeof output === "undefined") {
    output = {};
}

// Parts inward/outward element selectors - MERGE with existing partsInventory object
if (typeof output.partsInventory === "undefined") output.partsInventory = {};

Object.assign(output.partsInventory, {
    inventory: "Inventory",
    searchIcon: "search_icon",
    memoryCard: "memorycard",
    directionDropdown: "direction_dropdown",
    inward: "INWARD",
    outward: "OUTWARD",
    quantityTextField: "quantity_textfield",
    unitCostTextField: "unit_cost_textfield",
    availableQuantityTextField: "available_quantity_textfield",
    updateButton: "update_button"
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        partsInventory: output.partsInventory
    };
}
