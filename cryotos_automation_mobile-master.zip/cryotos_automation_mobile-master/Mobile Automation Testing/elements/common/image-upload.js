// Image Upload Elements
// Elements for image upload functionality

if (typeof output === "undefined") {
    output = {};
}

// Image Upload Structure - MERGE with existing imageUpload object
if (typeof output.imageUpload === "undefined") output.imageUpload = {};

Object.assign(output.imageUpload, {
    
    // Image upload elements
    imageView: "image_view",
    uploadImage: "Upload Image",
    done: "Done"
});

// ${output.imageUpload.imageView} → image_view element
// ${output.imageUpload.uploadImage} → Upload Image button
// ${output.imageUpload.done} → Done button


