// Common navigation elements
output.nav = {
    dashboard: 'Dashboard',
    workOrders: 'Work Orders',
    workRequests: 'Work Requests',
    schedules: 'Schedules',
    meterReading: 'Meter Reading'
};
