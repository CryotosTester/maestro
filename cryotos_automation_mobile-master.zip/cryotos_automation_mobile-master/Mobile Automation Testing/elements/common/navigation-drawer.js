// Navigation Drawer Elements
// Elements for the main navigation drawer menu
 
if (typeof output === "undefined") {
    output = {};
}
 
if (typeof output.navigationDrawer === "undefined") {
    output.navigationDrawer = {};
}
 
Object.assign(output.navigationDrawer, {
    // Main menu items
    myTask: "My Task",
    account: "Account",
    warehouse: "Warehouse",
    cycleCount: "Cycle Count",
    toolManagement: "Tool Management",
    enableBiometric: "Enable Biometric",
    gatePass: "Gate Pass",
    aboutUs: "About Us",
    rateUs: "Rate Us",
    logOut: "Log Out"
});
