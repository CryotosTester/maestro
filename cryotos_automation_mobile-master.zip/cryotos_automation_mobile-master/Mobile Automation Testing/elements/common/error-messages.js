// Common UI elements
output.common = {
    okBtn: 'OK',
    cancelBtn: 'Cancel',
    saveBtn: 'Save',
    closeBtn: 'Close',
    backBtn: 'Back',
    yesBtn: 'Yes',
    noBtn: 'No',
    submitBtn: 'Submit'
};
