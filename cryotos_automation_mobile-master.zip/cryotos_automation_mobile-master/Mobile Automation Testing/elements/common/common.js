// Common element definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Common element selectors - MERGE with existing common object
if (typeof output.common === "undefined") output.common = {};

Object.assign(output.common, {
    // Common buttons
    okButton: 'OK',
    submitButton: 'submit_button',
    cancelButton: 'Cancel',
    saveButton: 'Save',
    closeButton: 'Close',
    submit: 'submit_button',
    
    // Common dialog elements
    confirmButton: 'Confirm',
    yesButton: 'Yes',
    noButton: 'No',
    
    // Common form elements
    nextButton: 'Next',
    previousButton: 'Previous',
    backButton: 'Back',
    doneButton: 'Done',
    partsBackButton: 'back_button',
    
   
    
    addDowntime: 'add_Downtime',
    
    save: "Save",
    clear: "Clear",
    back:'back',
    search: 'search',
    clearId: 'Clear Search'
});

