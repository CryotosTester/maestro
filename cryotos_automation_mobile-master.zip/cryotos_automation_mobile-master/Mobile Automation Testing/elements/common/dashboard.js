// Dashboard element definitions for CMMS Mobile App

if (typeof output === "undefined") {
    output = {};
}

// Dashboard element selectors - MERGE with existing dashboard object
if (typeof output.dashboard === "undefined") output.dashboard = {};

Object.assign(output.dashboard, {
    // Dashboard Header elements
      
    Header: {
        menuButton: 'menu_button',
        dashboardTitle: 'dashboard_title',
        calendarIcon: 'calendar_icon'
    },
    
    // Dashboard Navigation items
    navigation: {
        createWorkOrder: 'Create Work Order',
        workRequest: 'Work Request',
        myCreation: 'My Creation',
        involvedTask: 'Involved Task'
    },
    
    // Request Filters
    requestFilters: {
        all: 'All',
        workOrder: 'Work Order',
        schedule: 'Schedule'
    },
    
    // Date Filters
    dateFilters: {
        thisMonth: 'This Month',
        today: 'Today',
        yesterday: 'Yesterday',
        previousMonth: 'Previous Month',
        custom: 'Custom',
        thisMonth: 'This Month'
    },
    
    // Filter icons and elements
    filterElements: {
        filterIcon: 'filter_icon',
        assignedToMe: 'assigned_to_me'
    },
    
    // Request Metrics
    requestMetrics: {
        overdue: 'Overdue',
        closedCompleted: 'Closed - Completed',
        workInProgress: 'Work in Progress',
        pendingWithReason: 'Pending with Reason',
        closedIncomplete: 'Closed - Incomplete',
        rejected: 'Rejected'
    },
    
    // Downtime & Period Filters
    downtimeFilters: {
        monthly: 'Monthly',
        yearly: 'Yearly',
        assetDowntimeFilterIcon: 'asset_downtime_filter_icon'
    },
    
    // Bottom Navigation
    bottomNavigation: {
        dashboard: 'Dashboard',
        asset: 'Asset',
        inventory: 'Inventory',
        meter: 'Meter'
    }
});
