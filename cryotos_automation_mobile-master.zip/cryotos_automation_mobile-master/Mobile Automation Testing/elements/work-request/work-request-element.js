// Work Request module elements

output.workRequest = {
    // Header Navigation elements
    headerNavigation: {
        backButton: 'back_button',
        workRequest: 'work_request',
        aiButton: 'AI',
        filterButton: 'filter_button'
    },
    
    // Search Bar elements
    searchBar: {
        searchByIdDescription: 'search_by_id_description'
    },
    
    // Bottom Navigation elements
    bottomNavigation: {
        workRequestFloatingButton: 'work_request_floating_button',
        createWorkRequest: 'create_work_request',
        qrScanner: 'qr_scanner'
    },
    
    // Form Dropdown elements
    dropdowns: {
        asset: 'asset_dropdown',
        category: 'category_dropdown',
        account: 'account_dropdown',
        location: 'location_dropdown',
        priority: 'priority_dropdown'
    },
    
    // Input Field elements
    inputFields: {
        description: 'description_textfield',
        contactName: 'contact_name_textfield',
        contactNumber: 'contact_number_textfield',
        invoiceReferenceNumber: 'invoice_reference_number_textfield',
        projectReferenceNumber: 'project_reference_number_textfield'
    },
    
    // Action elements
    actions: {
        submitButton: 'submit_button'
    },
    
    // Media elements
    media: {
        imageView: 'image_view'
    }
};





