// Work Request Validation module elements

output.workRequestValidation = {
    // Header Navigation elements
    headerNavigation: {
        backButton: 'back_button',
        workRequestDetail: 'Work Request Detail'
    },
    
    // Form elements
    form: {
        raisedBy: 'Raised by.*',
        accountIcon: 'account icon',
        locationIcon: 'location icon',
        moreInformation: 'More Information',
        categoryName: 'Category Name',
        contactName: 'Contact Name',
        contactNumber: 'Contact Number',
        projectReferenceNumber: 'Project Reference Number',
        invoiceReferenceNumber: 'Invoice Reference Number',
        status: 'Status',
        imageAttachment: 'Image Attachment',
        priority: 'Priority.*'
    },
    
    // Bottom Button elements
    bottomButtons: {
        rejectWorkRequest: 'Reject Work Request',
        convertToWorkOrder: 'convert_to_work_order'
    }
};
