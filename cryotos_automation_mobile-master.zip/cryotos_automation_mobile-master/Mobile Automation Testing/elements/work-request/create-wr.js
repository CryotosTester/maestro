// Work Request Creation elements
output.workRequest = {
    createBtn: 'Create Work Request',
    assetTab: 'asset_tab',
    locationTab: 'location_tab',
    priorityInput: 'priority_input',
    descriptionInput: 'description_input',
    contactName: 'contact_name',
    contactNumber: 'contact_number',
    submitBtn: 'Submit'
};
