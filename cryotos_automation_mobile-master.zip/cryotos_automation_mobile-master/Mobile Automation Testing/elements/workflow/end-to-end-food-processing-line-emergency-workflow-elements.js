// E2E WO-002 Food Processing Line Emergency Workflow
// Based on Production Line Issue Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-02 Workflow Structure
if (typeof output.e2e02 === "undefined") output.e2e02 = {};

Object.assign(output.e2e02, {
    // FORM 1: Production Line Issue
    prodIssue: {
        // Production Impact Section
        batch: "Batch Number Affected",
        batchVal: "B-2024-1019",
        impact: "Production Impact",
        impactOpt: ["Complete Shutdown", "Partial", "Quality Issue"],
        safety: "Food Safety Risk Present",
        issues: "Observed Issues",
        issuesOpt: ["Mechanical Jam", "Unusual Noise", "Safety Concern"],
        // Compliance & Loss Section
        halted: "Production Halted",
        loss: "Estimated Product Loss (kg)",
        lossVal: "250",
        haccp: "HACCP Protocol Triggered",
        haccpOpt: ["HACCP Protocol Triggered - Yes", "HACCP Protocol Triggered - No", "HACCP Protocol Triggered - N/A"],
        startTime: "Issue Start Time",
        // Buttons
        submit: "SUBMIT TO MAINTENANCE RESPONSE",
        draft: "Save As Draft",
        reject: "REJECT"
    },
    // FORM 2: Maintenance Response
    maintResp: {
        // Resolution Section
        cause: "Root Cause",
        causeOpt: ["Mechanical Wear", "Lack of Maintenance", "Operator Error"],
        test: "Safety System Test",
        testOpt: ["Safety System Test - Pass", "Safety System Test - Fail", "Safety System Test - N/A"],
        part: "Spare Part Used",
        partDef: "Conveyor Belt Motor M-250",
        sign: "Technician Sign-off",
        // Buttons
        close: "CLOSE WORK ORDER",
        draft: "Save As Draft",
        reject: "REJECT"
    }
});
