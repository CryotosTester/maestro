// E2E-01 Educational Equipment Breakdown Workflow
// Based on Equipment Failure Report Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-01 Educational Equipment Breakdown Workflow Structure
if (typeof output.e2e01 === "undefined") output.e2e01 = {};

Object.assign(output.e2e01, {
    // FORM 1: Equipment Failure Report
    failureReport: {
        // Equipment Details Section
        serial: "Equipment Serial Number",
        serialDefault: "SN-3DP-2024-205",
        runtime: "Equipment Runtime Hours",
        runtimeValue: "2450",
        impact: "Impact Level",
        impactOptions: ["No Classes", "Partial Impact", "Classes Cancelled"],
        systems: "Affected Systems",
        systemOptions: ["Extruder", "Heating Bed", "Control Panel", "Filament Feed", "Display System"],
        // Safety & Documentation Section
        hazard: "Safety Hazard Present",
        photo: "Equipment Failure Photo",
        maintenance: "Previous Maintenance Done",
        maintenanceOptions: ["Previous Maintenance Done - Yes", "Previous Maintenance Done - No", "Previous Maintenance Done - N/A"],
        students: "Students Affected",
        studentsValue: "45",
        // Labor Popup Fields
        laborPopup: "Add Labor Details",
        laborType: "Labor Type",
        laborTypeOptions: ["Technician", "Engineer", "Specialist", "Contractor"],
        laborHours: "Estimated Hours",
        laborNotes: "Labor Notes",
        // Parts Popup Fields
        partsPopup: "Add Required Parts",
        partName: "Part Name",
        partNumber: "Part Number",
        quantity: "Quantity",
        estCost: "Estimated Cost",
        // Buttons
        submit: "SUBMIT TO WORK COMPLETION",
        draft: "Save As Draft",
        reject: "REJECT"
    },
    // FORM 2: Work Completion
    completion: {
        // Work Summary Section
        summary: "Work Completed Summary",
        status: "Resolution Status",
        statusOptions: ["Fully Fixed", "Temporary Fix", "Needs Replacement"],
        test: "Post-Repair Functionality Test",
        testOptions: ["Post-Repair Functionality Test - Pass", "Post-Repair Functionality Test - Fail", "Post-Repair Functionality Test - N/A"],
        signature: "Supervisor Closure Signature",
        // Buttons
        close: "CLOSE WORK ORDER",
        draft: "Save As Draft",
        reject: "REJECT"
    }
});
