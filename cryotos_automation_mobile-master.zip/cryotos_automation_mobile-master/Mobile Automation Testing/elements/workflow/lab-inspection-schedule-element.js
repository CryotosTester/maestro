// Lab Inspection Schedule Workflow
// Based on Lab Equipment Daily Inspection Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// Lab Inspection Schedule Workflow Structure
if (typeof output.labInsp === "undefined") output.labInsp = {};

Object.assign(output.labInsp, {
    // FORM 1: Static (Work Instruction)
    static: {
        // Work Instruction Section
        workInstruction: "Work instruction",
        priority: "Priority",
        priorityOptions: ["NORMAL", "URGENT", "CRITICAL"],
    },
    
    // FORM 2: Lab Assistant Inspection
    labAssist: {
        // Basic Information Section
        labName: "Lab Name",
        inspNotes: "Inspection Notes",
        totalComp: "Total Computers",
        
        // Inspection Details Section
        shift: "Inspection Shift",
        shiftOptions: ["Morning 6 AM - 2 PM", "Afternoon 2 PM - 10 PM", "Night 10 PM - 6 AM"],
        condition: "Lab Condition",
        conditionOptions: ["Excellent", "Good", "Fair", "Poor"],
        workComp: "Working Computers",
        items: "Items Checked",
        itemOptions: ["Keyboard and Mouse", "Monitors", "Network Cabel", "Power Supply"],
        
        // Equipment Status Section
        equipTable: "Equipment Table",
        
        // Documentation Section
        photos: "Problem Photos Browse Image",
        annotated: "Annotated Image Browse Image",
        video: "Evidence Video browse_video",
        document: "Supporting Document",
        
        // Additional Info Section
        criticalSafety: "Critical Safety",
        specialInstructions: "Special Instructions",
        date: "Inspection Date",
        time: "Inspection Time",
        
        // Buttons
        submit: "SUBMIT TO SUPERVISOR",
        draft: "Save As Draft",
        reject: "REJECT"
    },
    
    // FORM 3: Supervisor Review
    supervisor: {
        // Cost Details Section
        cost: "Cost",
        
        // Supervisor Decision Section
        sign: "Supervisor Sign With  Rating",
        budgetApproved: "Budget Approved",
        budgetOptions: ["Budget Approved - Yes", "Budget Approved - No", "Budget Approved - N/A"],
        finalDecision: "Final Decision",
        decisionOptions: ["Final Decision - Pass", "Final Decision - Fail", "Final Decision - N/A"],
        
        // Reference Links Section
        prevReview: "Previous Review",
        staticLink: "static link",
        
        // Buttons
        close: "Close",
        reject: "REJECT"
    }
});
