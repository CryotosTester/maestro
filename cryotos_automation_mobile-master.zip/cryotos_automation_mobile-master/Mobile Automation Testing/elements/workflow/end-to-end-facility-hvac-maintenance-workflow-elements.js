// E2E-03 Facility HVAC Maintenance Workflow
// Based on HVAC Service Request Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-03 Facility HVAC Maintenance Workflow Structure
if (typeof output.e2e03 === "undefined") output.e2e03 = {};

Object.assign(output.e2e03, {
    // FORM 1: HVAC Service Request
    serviceRequest: {
        // Environmental Conditions Section
        temperature: "Current Temperature .*°C.*",
        employees: "Employees Affected",
        areas: "Affected Areas",
        areasOptions: ["Conference Rooms", "Open Office", "Server Room", "Cafeteria"],
        timeline: "Urgency Timeline",
        timelineOptions: ["Within 2 Hours", "Today", "Scheduled"],
        // Service History Section
        service: "Last Service",
        serviceOptions: ["Within Month", "3 Months", "6 Months", "Over Year"],
        impact: "Business Critical Impact",
        floorPlan: "Floor Plan PDF",
        contact: "Contact Person",
        // Labor Popup Fields
        laborPopup: "Add Labor (Next Form)",
        laborType: "Labor Type",
        laborTypeOptions: ["HVAC Technician", "Senior Technician", "Specialist", "Contractor"],
        laborHours: "Estimated Hours",
        laborNotes: "Labor Notes",
        // Parts Popup Fields
        partsPopup: "Add Parts .*Next Form.*",
        partName: "Part Name",
        partNumber: "Part Number",
        quantity: "Quantity",
        estCost: "Estimated Cost",
        // Buttons
        submit: "Submit to HVAC Repair",
        draft: "Save As Draft",
        reject: "REJECT"
    },
    // FORM 2: HVAC Repair
    repair: {
        // Diagnostics Section
        checklist: "Component Checklist",
        checklistColumns: ["Component", "Status", "Reading", "Notes"],
        pressure: "Refrigerant Pressure .*PSI.*",
        pressureValue: "120",
        test: "Electrical Test",
        testOptions: ["Electrical Test - Pass", "Electrical Test - Fail", "Electrical Test - N/A"],
        marked: "Problem Area Marked Browse Image",
        // Work Completion Section
        additional: "Additional Work Needed",
        status: "System Status",
        statusOptions: ["Fully Operational", "Partial", "Needs Major Repair"],
        work: "Work Performed",
        workOptions: ["Filter Replaced", "Refrigerant Added", "Motor Serviced"],
        signature: "Technician Signature",
        // Buttons
        close: "Close Work Order",
        draft: "Save As Draft",
        reject: "REJECT"
    }
});
