// E2E-06 Facility Electrical Issue Workflow
// Based on Electrical Issue Report Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-06 Facility Electrical Issue Workflow Structure
if (typeof output.e2e06 === "undefined") output.e2e06 = {};

Object.assign(output.e2e06, {
    // FORM 1: Electrical Issue Report
    issueReport: {
        // Electrical Parameters Section
        voltage: "Voltage Reading",
        voltageValue: "380V",
        issueType: "Issue Type",
        issueTypeOptions: ["Power Outage", "Tripping", "Fluctuation", "Burning Smell"],
        emergency: "Emergency Lighting Affected",
        systems: "Affected Systems",
        systemsOptions: ["HVAC", "Elevators", "Security", "Data Center"],
        // Risk Level Section
        backup: "Backup Power Active",
        backupOptions: ["Backup Power Active - Yes", "Backup Power Active - No", "Backup Power Active - N/A"],
        impact: "Business Impact",
        impactOptions: ["Critical", "High", "Medium", "Low"],
        panelId: "Panel ID",
        panelIdDefault: "MDB-C-B1-01",
        occurrence: "First Occurrence",
        // Buttons
        submitPending: "Electrical Work",
        close: "Close",
    },
    // FORM 2: Electrical Work
    electricalWork: {
        // Work Status Management Section
        workStatus: "Work Status",
        workStatusOptions: ["In Progress", "Pending", "Completed"],
        pendingReason: "Pending Reason",
        pendingReasonDefault: "Awaiting specialized breaker",
        resumeDate: "Expected Resume Date",
        additionalDays: "Additional Days Required",
        // Safety Documentation Section
        safety: "Safety Protocols",
        safetyOptions: ["LOTO Applied", "Area Cordoned", "PPE Used"],
        insulation: "Insulation Test",
        insulationOptions: ["Insulation Test - Pass", "Insulation Test - Fail", "Insulation Test - N/A"],
        panelCondition: "Panel Condition Browse Image",
        signature: "Technician Signature",
        // Buttons
        backToReport: "Electrical Issue Report",
        closeWorkOrder: "Close Work Order",
    }
});
