// E2E-08 Building Systems Emergency Response Workflow
// Based on Emergency Alert Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-08 Building Systems Emergency Response Workflow Structure
if (typeof output.e2e08 === "undefined") output.e2e08 = {};

Object.assign(output.e2e08, {
    // FORM 1: Emergency Alert - Building Systems Failure
    alert: {
        // Emergency Details Section
        incidentId: "Incident ID",
        reportedBy: "Reported By",
        emergType: "Emergency Type",
        emergTypeOpts: ["Power Outage", "Water Leak", "HVAC Failure", "Fire Alarm", "Elevator Malfunction", "Gas Leak"],
        severity: "Severity Level",
        severityOpts: ["Critical", "High", "Medium", "Low"],
        incidentTime: "Incident Time",
        // Location & Impact Section
        zone: "Building Zone",
        zoneOpts: ["North Wing", "South Wing", "East Wing", "West Wing", "Basement", "Roof"],
        floor: "Floor Level",
        occupants: "Occupants Affected",
        hazard: "Safety Hazard Present",
        photos: "Emergency Photos",
        // Buttons
        submit: "Multi-Trade Response",
        draft: "Save As Draft"
    },

    // FORM 2: Multi-Trade Response
    response: {
        // Trade Coordination Section
        leadTech: "Lead Technician",
        startTime: "Work Start Time",
        trades: "Active Trades",
        tradesOpts: ["Electrical", "Plumbing", "HVAC", "Fire Safety", "Structural", "General Maintenance"],
        // Electrical Work Section (Conditional)
        powerStatus: "Power Status",
        powerOpts: ["Restored", "Partial", "Outage Continues"],
        elecCheck: "Electrical Safety Check",
        elecCheckOpts: ["Electrical Safety Check - Pass", "Electrical Safety Check - Fail", "Electrical Safety Check - N/A"],
        // Plumbing Work Section (Conditional)
        waterStatus: "Water Flow Status",
        waterOpts: ["Normal", "Reduced", "No Flow"],
        leakRes: "Leak Resolution",
        leakResOpts: ["Leak Resolution - Resolved", "Leak Resolution - Partial", "Leak Resolution - Not Resolved"],
        // HVAC Work Section (Conditional)
        tempCtrl: "Temperature Control",
        tempOpts: ["Restored", "Partial", "System Down"],
        airCheck: "Air Quality Check",
        airCheckOpts: ["Air Quality Check - Good", "Air Quality Check - Fair", "Air Quality Check - Poor"],
        // Work Completion Section
        endTime: "Work End Time",
        summary: "Work Summary",
        materials: "Materials Used",
        beforeAfter: "Before/After Photos",
        signature: "Technician Signature",
        // Buttons
        submit: "Submit to Quality Assurance",
        close: "Close"
  
    }
});
