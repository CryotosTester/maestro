// Breakdown Basic Maintenance Workflow - Section-Based Structure
// Based on Breakdown - Basic.json structure
// Organized by forms and sections for better maintainability

if (typeof output === "undefined") { 
    output = {}; 
}

// Breakdown Basic Maintenance Workflow Structure - MERGE with existing breakdownBasic object
if (typeof output.breakdownBasic === "undefined") output.breakdownBasic = {};

Object.assign(output.breakdownBasic, {
    
    breakdownRequest: {
        breakdownRequestInfo: {
            dateOfBreakdown: "Date of Breakdown",
            videoIfAny: "Video if any",
            sign: "SIGN",
            img: "img",
            radio: "Radio",
            assetNo: "AssetNo",
            signName: "SIGN name"
        },
        buttons: {
            submitToTechnician: "Submit to Technician",
            close: "Close"
        }
    },
    breakdownExecutionForm: {
        breakdownExecutionFormSection: {
            machineDownTime: "Machine Down Time",
            technicalObservation: "Technical Observation",
            technicalSolution: "Technical Solution",
            problemSolved: "Problem Solved",
            afterImage: "After Image",
            whyAnalysis1: "Why Analysis - 1",
            whyAnalysis2: "Why Analysis - 2",
            whyAnalysis3: "Why Analysis - 3",
            machineUpTime: "Machine Up Time",
            otherCostDescription: "Other Cost Description",
            otherCost: "Other Cost",
            cableHasToChecked: "Cable has to checked",
            checkTheOilFilter: "Check the oil filter"
        },
        buttons: {
            submitForManagerApproval: "Submit for Manager Approval",
            saveAsDraft: "Save As Draft",
            reject: "Reject",
            openBreakdown: "Open Breakdown"
        }
    },
    supervisorApproval: {
        openBreakdown: {
            description: "Description",
            reasons: "Reasons",
            signature: "signature"
        },
        buttons: {
            approval: "Approval"
        }
    },
    approval: {
        remarks: {
            managerApprovalRemarks: "Manager Approval Remarks",
            approved: "Approved"
        },
        buttons: {
            close: "Close",
            reWork: "Re Work"
        }
    }
});

