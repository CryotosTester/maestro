// E2E-04 Manufacturing Equipment Breakdown Workflow - Form-Based Structure
// Based on [E2E-04] Manufacturing Equipment Breakdown_WorkOrder_Template_Json.json structure
// Organized by forms (NO sections) where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-04 Manufacturing Equipment Breakdown Workflow Structure - MERGE with existing e2e04 object
if (typeof output.e2e04 === "undefined") output.e2e04 = {};

Object.assign(output.e2e04, {
   
    // FORM 1: Machine Breakdown Report
    breakdownReport: {
        production: "Production Status",
        productionOptions: ["Stopped", "Reduced", "Alternate Arranged"],
        parts: "Parts in Progress",
        timestamp: "Breakdown Timestamp",
        cause: "Suspected Cause",
        causeOptions: ["Mechanical", "Electrical", "Software", "Unknown"],
        hazard: "Safety Hazard Created",
        error: "Operator Error Suspected",
        errorOptions: [
            "Operator Error Suspected - Yes",
            "Operator Error Suspected - No",
            "Operator Error Suspected - N/A"
        ],
        badge: "Operator Badge ID",
        display: "Machine Error Display",
        submit: "Submit to Maintenance Action",
        draft: "Save As Draft",
        reject: "Reject"
    },
   
    // FORM 2: Maintenance Action
    maintenance: {
        status: "Current Status",
        statusOptions: ["Work IN Progress", "Pending", "On Hold"],
        hours: "Estimated Hours to Complete",
        tasks: "Tasks Completed",
        taskOptions: ["Initial Assessment", "Parts Ordered", "Partial Repair", "Testing"],
        vendor: "External Vendor Needed",
        test: "Safety Lock Test",
        testOptions: [
            "Safety Lock Test - Pass",
            "Safety Lock Test - Fail",
            "Safety Lock Test - N/A"
        ],
        final: "Final Status",
        finalOptions: ["Completed", "Partial", "Scheduled"],
        signoff: "Engineer Sign-off",
        close: "Close Work Order",
        draft: "Save As Draft",
        reject: "Reject"
    }
});
