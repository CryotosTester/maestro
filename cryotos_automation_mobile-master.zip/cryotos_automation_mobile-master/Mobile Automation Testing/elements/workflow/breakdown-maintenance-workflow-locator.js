/**
 * Breakdown Maintenance Ticket Workflow Locators
 * Contains locators for all forms, sections, and fields in the breakdown maintenance workflow
 * Based on Breakdown Maintenance -Ticket.json structure
 */

const breakdownMaintenanceLocators = {
    // Form 1: Work Order Conversion
    workOrderConversion: {
        title: "Work Order Conversion",
        staticTitle: "Request",
        
        // Ticket Information Section
        ticketInformation: {
            ticketRefNo: {
                locator: "Ticket Ref No",
                type: "textInput"
            },
            trainNumber: {
                locator: "Train Number",
                type: "dropDown",
                options: ["Train 12345", "Train 67890", "Train 1111"]
            },
            coach: {
                locator: "Coach",
                type: "dropDown",
                options: ["Coach A1(AC First Class)", "Coach B1(AC 2-Tier)", "Coach B2(AC 2 Tier)", "Coach s1(sleeper)", "Coach s2(Sleeper)"]
            },
            compartment: {
                locator: "Compartment",
                type: "dropDown",
                options: ["Compartment A", "Compartment B", "Pantry Kitchen", "Luggage area"]
            },
            reporterName: {
                locator: "ReporterName",
                type: "textArea"
            },
            workOrderNumber: {
                locator: "WOrk Order Number",
                type: "textInput"
            }
        },

        // Asset & Location Section
        assetLocation: {
            assetType: {
                locator: "Asset Type",
                type: "dropDown",
                options: ["HVAC Equipment", "Electrical", "Plumbing", "Furniture", "IT Equipment"]
            },
            assetId: {
                locator: "Asset ID",
                type: "textInput"
            },
            locationBuilding: {
                locator: "Location Building",
                type: "dropDown",
                options: ["Main Office", "Branch Office", "Warehouse"]
            },
            locationFloor: {
                locator: "Location floor",
                type: "dropDown",
                options: ["Ground Floor", "1st Floor", "2nd floor", "3rd Floor"]
            },
            locationRoom: {
                locator: "Location room",
                type: "textInput"
            }
        },

        // Resource Planning Section
        resourcePlanning: {
            requiredSkills: {
                locator: "Required Skills",
                type: "dropDown",
                options: ["HVAC Technician", "Electrician", "Plumber", "General Maintenance"]
            },
            toolsNeeded: {
                locator: "Tools Needed",
                type: "textArea"
            }
        },

        // Buttons
        buttons: {
            createWorkOrder: {
                locator: "Create WorkOrder",
                color: "#3C75C6",
                action: "submit",
                tab: "Inspection",
                status: "WIP"
            }
        }
    },

    // Form 2: Inspection
    inspection: {
        title: "Inspection",
        
        // Visual inspection Section
        visualInspection: {
            overallIssue: {
                locator: "Overall issue",
                type: "dropDown",
                options: ["Clean", "Dusty", "Damaged", "Leaking"]
            },
            costInvolved: {
                locator: "Cost Involved",
                type: "textInput"
            }
        },

        // Required repairs Section
        requiredRepairs: {
            repairType: {
                locator: "Repair type",
                type: "dropDown",
                options: ["Component Replacement", "Minor Repair", "Major Repair", "System Overhaul"]
            },
            toolsNeeded: {
                locator: "Tools Needed",
                type: "dropDown",
                options: ["Electical tester", "multimeter", "component Replacement Tool"]
            },
            image: {
                locator: "Image",
                type: "images",
                cameraOnly: false
            },
            inspectorSign: {
                locator: "Inspector Sign",
                type: "signatureOnly"
            }
        },

        // Buttons
        buttons: {
            managerVerification: {
                locator: "Manager Verification",
                color: "#40c73d",
                action: "submit",
                tab: "Manager Verification",
                status: "WIP"
            }
        }
    },

    // Form 3: Manager Verification
    managerVerification: {
        title: "Manager Verification",
        
        // Manager Verification Section
        managerVerificationSection: {
            problemSeverity: {
                locator: "Problem Severity",
                type: "dropDown",
                options: ["Critical", "High", "Medium", "Low"]
            },
            description: {
                locator: "Description",
                type: "textArea"
            },
            targetCompletion: {
                locator: "Target Completion",
                type: "dateTime"
            },
            estimatedTotalCost: {
                locator: "Estimated Total Cost",
                type: "numeric"
            }
        },

        // Buttons
        buttons: {
            costApproval: {
                locator: "Cost Approval",
                color: "#17c70a",
                action: "submit",
                tab: "Cost Approval",
                status: "WIP"
            }
        }
    },

    // Form 4: Cost Approval
    costApproval: {
        title: "Cost Approval",
        
        // Detail Section
        detail: {
            sign: {
                locator: "Sign",
                type: "signatureOnly"
            }
        },

        // Buttons
        buttons: {
            submit: {
                locator: "SUBMIT",
                color: "#3C75C6",
                action: "submit",
                tab: "Rectification",
                status: "WIP"
            },
            reject: {
                locator: "Reject",
                color: "#3C75C6",
                action: "reject",
                tab: "",
                status: "Reject"
            }
        }
    },

    // Form 5: Rectification
    rectification: {
        title: "Rectification",
        
        // Issue Resolution Details Section
        issueResolutionDetails: {
            airFlow: {
                locator: "AirFlow",
                type: "dropDown",
                options: ["STRONG", "Normal", "Noisy"]
            },
            noiseLevel: {
                locator: "Noise Level",
                type: "dropDown",
                options: ["Quiet", "Normal", "Noisy"]
            }
        },

        // Buttons
        buttons: {
            rectificationApproval: {
                locator: "Rectification Approval",
                color: "#3C75C6",
                action: "submit",
                tab: "Rectification Approval",
                status: "WIP"
            },
            close: {
                locator: "Close",
                color: "#3C75C6",
                action: "closeIncident",
                tab: "",
                status: "Closed"
            }
        }
    },

    // Form 6: Rectification Approval
    rectificationApproval: {
        title: "Rectification Approval",
        
        // Quality Inspection Section
        qualityInspection: {
            visual: {
                locator: "Visual",
                type: "dropDown",
                options: ["Excellent", "Good", "Acceptable", "Poor"]
            },
            sign: {
                locator: "Sign",
                type: "signatureOnly"
            }
        },

        // Buttons
        buttons: {
            close: {
                locator: "Close",
                color: "#3C75C6",
                action: "closeIncident",
                tab: "",
                status: "Closed"
            }
        }
    },

    // Common locators for all forms
    common: {
        // Form navigation
        formTabs: {
            workOrderConversion: "Work Order Conversion",
            inspection: "Inspection",
            managerVerification: "Manager Verification",
            costApproval: "Cost Approval",
            rectification: "Rectification",
            rectificationApproval: "Rectification Approval"
        },

        // Common form elements
        formElements: {
            loadingSpinner: "Loading",
            errorMessage: "Error",
            successMessage: "Success",
            formContainer: "Form Container",
            sectionHeader: "Section Header"
        },

        // Common buttons
        commonButtons: {
            save: "Save",
            cancel: "Cancel",
            back: "Back",
            next: "Next",
            previous: "Previous"
        }
    }
};

