// E2E-07 Fire Alarm Panel Breakdown Workflow
// Based on Fire Alarm Panel Alert Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-07 Fire Alarm Panel Breakdown Workflow Structure
if (typeof output.e2e07 === "undefined") output.e2e07 = {};

Object.assign(output.e2e07, {
    // FORM 1: Fire Alarm Panel Alert
    alert: {
        // Sensor Readings Section
        errorCode: "Fire Panel Error Code",
        errorCodeDefault: "FIRE-7023",
        heatLevel: "Heat Sensor Reading",
        fireZone: "Fire Zone Location",
        fireZoneOpts: ["North Wing", "South Wing", "East Wing", "West Wing"],
        alertTime: "Alert Timestamp",
        // Fire Safety Status Section
        occupancy: "Building Occupancy",
        occupancyOpts: ["Occupied", "Vacant", "Partial"],
        suppression: "Fire Suppression System Status",
        suppressionOpts: ["Fire Suppression System Status - Active", "Fire Suppression System Status - Inactive", "Fire Suppression System Status - N/A"],
        override: "Manual Override Active",
        smokeLevel: "Smoke Detection Level .*",
        // Buttons
        submitEmerg: "Submit to Emergency Response",
        submitRoutine: "Submit to Routine Response"
    },
    // FORM 2: Emergency Response
    emergency: {
        // Emergency Response Section
        actions: "Immediate Actions",
        actionsOpts: ["Activate Sprinklers", "Sound Evacuation", "Call Fire Department", "Evacuate Building"],
        targetHeat: "Target Heat Level",
        safetyCheck: "Fire Safety Verified",
        safetyCheckOpts: ["Fire Safety Verified - Pass", "Fire Safety Verified - Fail", "Fire Safety Verified - N/A"],
        signOff: "Emergency Sign-off",
        // Buttons
        close: "Close Work Order",
        toRoutine: "Routine Response"
    },
    // FORM 3: Routine Response
    routine: {
        // Routine Response Section
        schedule: "Scheduled Action",
        scheduleOpts: ["Next Maintenance", "Monitor", "Adjust"],
        techId: "Technician ID",
        signOff: "Routine Sign-off",
        // Buttons
        close: "Close Work Order"
    }
});
