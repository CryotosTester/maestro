// Breakdown Basic Academic Workflow - Section-Based Structure
// Based on Untitled-1.json structure
// Organized by forms and sections for better maintainability

if (typeof output === "undefined") { 
    output = {}; 
}

// Breakdown Basic Academic Workflow Structure - MERGE with existing breakdownBasicAcademic object
if (typeof output.breakdownBasicAcademic === "undefined") output.breakdownBasicAcademic = {};

Object.assign(output.breakdownBasicAcademic, {
    
    breakdownInformation: {
        details: {
            faultReportedTime: "Fault Reported Time",
            requestor: "Requestor",
            modeOfRequest: "Mode of Request",
            contactNumber: "Contact Number",
            typeOfService: "Type of Service",
            attachImages: "Attach Images"
        },
        buttons: {
            submitToTechnician: "Submit to Technician"
        }
    },
    
    technicianForm: {
        technicianFormSection: {
            resolutionDescription: "Resolution Description",
            attachImage: "Attach Image",
            attendedBy: "Attended by",
            technicianSignature: "Technician Signature",
            userSignature: "User Signature"
        },
        buttons: {
            submitForVerification: "Submit for Verification",
            pendingForMaterial: "Pending for Material",
            pendingForContractor: "Pending for Contractor",
            saveAsDraft: "Save As Draft"
        }
    },
    
    pendingForMaterial: {
        pendingForm: {
            resolutionDescription: "Resolution Description",
            attachImage: "Attach Image",
            attendedBy: "Attended by",
            technicianSignature: "Technician Signature",
            userSignature: "User Signature"
        },
        buttons: {
            submitForVerification: "Submit for Verification",
            saveAsDraft: "Save As Draft"
        }
    },
    
    pendingForContractor: {
        pendingForm: {
            resolutionDescription: "Resolution Description",
            attachImage: "Attach Image",
            attendedBy: "Attended by",
            technicianSignature: "Technician Signature",
            userSignature: "User Signature"
        },
        buttons: {
            submitForVerification: "Submit for Verification",
            saveAsDraft: "Save As Draft"
        }
    },
    
    toVerification: {
        toVerificationForm: {
            comments: "Comments",
            technicalOfficer: "Technical Officer",
            signature: "Signature"
        },
        buttons: {
            submitForVerification: "Submit for Verification",
            resubmit: "Re-submit",
            saveAsDraft: "Save As Draft"
        }
    },
    
    managerVerification: {
        managerVerification: {
            comments: "Comments",
            manager: "Manager",
            signature: "Signature"
        },
        buttons: {
            submitToOCIF: "Submit to OCIF",
            resubmit: "Re-submit",
            saveAsDraft: "Save As Draft"
        }
    },
    
    ocifVerification: {
        ocifVerification: {
            comments: "Comments",
            ocif: "OCIF"
        },
        buttons: {
            close: "Close",
            resubmit: "Re-submit",
            saveAsDraft: "Save As Draft"
        }
    }
});

