// E2E-05 Hospital Medical Equipment Workflow (MRI Scanner Breakdown)
// Based on MRI Scanner Breakdown Report Template JSON structure
// Organized by forms where label = id

if (typeof output === "undefined") {
    output = {};
}

// E2E-05 Workflow Structure - MERGE with existing e2e05 object
if (typeof output.e2e05 === "undefined") output.e2e05 = {};

Object.assign(output.e2e05, {
   
    // FORM: MRI Scanner Breakdown Report
    breakdownReport: {
        // Breakdown Impact Assessment Section
        errorCode: "MRI Error Code",
        patientImpact: "Patient Service Impact",
        patientImpactOpts: ["MRI Services Stopped", "Services Delayed", "No Patient Impact"],
        patientsAffected: "Patients Affected Per Day",
        category: "Breakdown Category",
        categoryOpts: ["Magnet Quench", "RF Coil Failure", "Gradient System Error", "Software Crash", "Power Supply Issue", "Cooling System Failure"],
        // MRI Scanner Status Section
        hazard: "Safety Hazard Present",
        maintenance: "Last Maintenance Date",
        shutdown: "Emergency Shutdown Required",
        shutdownOpts: ["Emergency Shutdown Required - Yes", "Emergency Shutdown Required - No", "Emergency Shutdown Required - N/A"],
        screenshot: "MRI Error Display Screenshot",
        // Buttons
        submit: "MRI Scanner Repair",
        draft: "Save As Draft"
    },
   
    // FORM: MRI Scanner Repair
    scannerRepair: {
        // MRI Diagnostic Testing Section
        testName: "Test Name",
        expectedValue: "Expected Value",
        actualValue: "Actual Value",
        passFail: "Pass-Fail",
        systemTests: "MRI System Tests",
        documentation: "Repair Documentation",
        rootCause: "Root Cause Analysis",
        rootCauseOpts: ["Magnet Quench Event", "RF Coil Malfunction", "Gradient Amplifier Failure", "Software Bug", "Power Supply Issue", "Cooling System Breakdown"],
        fieldStrength: "Magnetic Field Strength (Tesla)",
        // MRI Safety Verification Section
        safetyChecks: "Safety Protocol Checks",
        safetyChecksOpts: ["Magnetic Field Safety", "RF Safety Compliance", "Patient Safety Protocols", "Staff Safety Training", "MRI Operational Test"],
        operationalTest: "MRI Operational Test",
        operationalTestOpts: ["MRI Operational Test - Pass", "MRI Operational Test - Fail", "MRI Operational Test - N/A"],
        signature: "Biomedical Engineer Sign-off",
        // Buttons
        close: "Close Work Order",
        draft: "Save As Draft"
    },
   
   
});
