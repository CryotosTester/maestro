// Meter Reading Threshold Violation Workflow

if (typeof output === "undefined") {
    output = {};
}

if (typeof output.meterReading === "undefined") output.meterReading = {};

Object.assign(output.meterReading, {
    workflowName: "meter reading threshold violation",
    
    // Form 1: Meter Threshold Alert Assessment
    alert: {
        actionReq: "Action Required",
        actionReqOpts: ["Inspection Required", "Maintenance Due", "Calibration Needed", "Service Required"],
        
        serviceStatus: "Service Status",
        serviceStatusOpts: ["Safe to Operate", "Requires Attention", "Needs Immediate Service"],
        
        submitReview: "Submit to Resolution Review"
    },
    
    // Form 2: Resolution Review
    review: {
        condAssess: "Condition Assessment",
        condAssessOpts: ["Condition Assessment - Pass", "Condition Assessment - Fail", "Condition Assessment - N/A"],
        
        serviceVerify: "Service Verification",
        serviceVerifyOpts: ["Service Verification - Yes", "Service Verification - No", "Service Verification - N/A"],
        
        nextService: "Next Service Due",
        
        opStatus: "Operational Status",
        opStatusOpts: ["Fully Operational", "Partially Operational", "Not Operational"],
        
        safetyCheck: "Safety Check",
        
        resolveStatus: "Resolution Status",
        resolveStatusOpts: ["Resolved", "Pending", "Requires Follow-up"],
        
        closeOrder: "Close Work Order"
    }
});
