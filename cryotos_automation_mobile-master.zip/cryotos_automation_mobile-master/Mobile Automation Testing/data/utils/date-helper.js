// date-helper.js

if (typeof output === "undefined") {
    output = {};
}

// Long format date for pickers and labels, with day names etc.
function formatDate(offset) {
    var d = new Date();
    if (typeof offset === "number") {
        d.setDate(d.getDate() + offset);
    }
    var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    var day = d.getDate();
    return day + ', ' + days[d.getDay()] + ', ' + months[d.getMonth()] + ' ' + day + ', ' + d.getFullYear();
}

// Assign long formatted dates to output.date
if (typeof output.date === "undefined") output.date = {};
Object.assign(output.date, {
    today: formatDate(0) + ', Today',
    yesterday: formatDate(-1),
    twoDaysAgo: formatDate(-2),
    tomorrow: formatDate(1),
    formatted: formatDate(0),
    start: formatDate(-2),
    end: formatDate(0) + ', Today'
});

// ONE Date instance for all time data
var now = new Date();

var hour24 = now.getHours();                      // 0-23 format
var hour12 = hour24 % 12 || 12;                   // 1-12 format (no leading zero)
var minuteNow = now.getMinutes();

// Format minute values with rollover
var minute = minuteNow.toString().padStart(2, '0');
var minuteLess = (minuteNow - 1 + 60) % 60;
var minuteGreater = (minuteNow + 1) % 60;

// Store useful timePicker values for input
output.timePicker = {
    hourSelector: 'Select hours ' + hour12,
    hour: hour12.toString(),
    minute: minute,
    minuteSelector: 'Select minutes ' + minute,
    ampm: hour24 >= 12 ? 'PM' : 'AM',
    minuteLess: minuteLess.toString().padStart(2, '0'),
    minuteGreater: minuteGreater.toString().padStart(2, '0')
};

// Short date format helper "dd/MM/yyyy"
function getShortDate(offset = 0) {
    var d = new Date();
    d.setDate(d.getDate() + offset);
    var day = d.getDate().toString().padStart(2, '0');
    var month = (d.getMonth() + 1).toString().padStart(2, '0');
    var year = d.getFullYear();
    return day + '/' + month + '/' + year;
}

// Short date-time format helper "dd/MM/yyyy HH:mm"
function getShortDateTime(offset = 0, hour = null, minute = null) {
    var d = new Date();
    d.setDate(d.getDate() + offset);
    var day = d.getDate().toString().padStart(2, '0');
    var month = (d.getMonth() + 1).toString().padStart(2, '0');
    var year = d.getFullYear();
    var hr = hour !== null ? hour : d.getHours();
    var min = minute !== null ? minute : d.getMinutes();
    var hourStr = hr.toString().padStart(2, '0');
    var minStr = min.toString().padStart(2, '0');
    return day + '/' + month + '/' + year + ' ' + hourStr + ':' + minStr;
}

// Store short date/time strings for assertions and input
output.shortDateToday     = getShortDate(0);
output.shortDateYesterday = getShortDate(-1);
output.shortDateTomorrow  = getShortDate(1);

output.shortDateTimeToday     = getShortDateTime(0, hour24, minuteNow);
output.shortDateTimeYesterday = getShortDateTime(-1, hour24, minuteNow);
output.shortDateTimeTomorrow  = getShortDateTime(1, hour24, minuteNow);

// For rollover validation windows (e.g., minute increment boundary)
output.validDateTimeWindow = [
    output.shortDateTimeToday,
    output.shortDateTimeToday.replace(minute, minuteGreater.toString().padStart(2, '0'))
];

// Optionally expose formatter functions
output.formatters = {
    getShortDate: getShortDate,
    getShortDateTime: getShortDateTime,
    formatDate: formatDate
};
