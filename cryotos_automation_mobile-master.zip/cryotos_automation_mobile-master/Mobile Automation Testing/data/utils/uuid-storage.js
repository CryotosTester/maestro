// UUID Storage - Store unique identifier for test execution
// This file generates and stores a UUID that persists throughout the test
 
if (typeof output === "undefined") {
    output = {};
}
 
// Generate a simple UUID
function generateUUID() {
    return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    }).substring(0, 32);
}
 
// Generate UUID once and store it
if (typeof output.uuidStorage === "undefined") {
    output.uuidStorage = {
        uuid: generateUUID()
    };
}
 
// Also provide it at output.uuid for easier access
if (typeof output.uuid === "undefined") {
    output.uuid = output.uuidStorage.uuid;
}
 
// Mirror to output.runUuid for convenient reuse in flows
if (typeof output.runUuid === "undefined") {
    output.runUuid = output.uuid;
}
 
 