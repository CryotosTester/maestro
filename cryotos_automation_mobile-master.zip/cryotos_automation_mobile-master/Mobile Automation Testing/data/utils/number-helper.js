// Number Helper - Random number generation utilities
// This file provides random number generation functions for test data

if (typeof output === "undefined") { 
    output = {}; 
}

// Number Helper Structure - MERGE with existing number object
if (typeof output.number === "undefined") output.number = {};

Object.assign(output.number, {
    
    // ${output.number.randomNumber} → Random float (0-1)
    randomNumber: Math.random(),
    min: 1,
    max: 100,
    randomInt: Math.floor(Math.random() * (100 - 1 + 1)) + 1,
    singleDigit: Math.floor(Math.random() * 9) + 1,
    twoDigitNumber: Math.floor(10 + Math.random() * 90),
    fourDigitNumber: Math.floor(1000 + Math.random() * 9000),
    
    // Helper functions
    generateRandomInt: function(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },
    
    generateRandomFloat: function(min, max) {
        return Math.random() * (max - min) + min;
    },
    // ${output.number.singleDigit} → Random single digit (0-9)
    generateSingleDigit: function() {
        return Math.floor(Math.random() * 10);
    }
});

// Utils Structure - MERGE with existing utils object
if (typeof output.utils === "undefined") output.utils = {};

// ${output.utils.phoneNumber} → Random phone number (e.g., "+91-1234567890")
function generatePhoneNumber() {
    var phoneNumber = "";
    for (var i = 0; i < 10; i++) {
        phoneNumber += Math.floor(Math.random() * 10);
    }
    return "+91-" + phoneNumber;
}

Object.assign(output.utils, {
    phoneNumber: generatePhoneNumber()
});
