
// User Credentials - Login information for different users
// This file provides user credentials for test automation

// User Credentials - Login information for different users
// This file provides user credentials for test automation

if (typeof output === "undefined") { 
    output = {}; 
}

// User Credentials Structure - MERGE with existing credentials object
if (typeof output.credentials === "undefined") output.credentials = {};

if(MAESTRO_ENV==="prod"){
    // Production Environment Credentials
    Object.assign(output.credentials, {
        requesterManager: {        // user1 - Creates work orders, manager approval
            email: "asas060304@gmail.com",
            password: "asmiN@123"
        },
        facilityManager: {         // user2 - OCIF approval, also creates work orders
            email: "e219@minusculetechnologies.com",
            password: "Asmin@123"
        },
        verifier: {                // user3 - Verifies completed work
            email: "e201@minusculetechnologies.com",
            password: "Welcome@1234"
        },
        fieldTechnician: {         // user4 - Primary technician performing work
            email: "naren150601@gmail.com",
            password: "Naren@1506"
        },
        seniorTechnician: {        // user5 - Senior technician/engineer
            email: "e218@minusculetechnologies.com",
            password: "Naren@1506"
        }
    });
}
else if(MAESTRO_ENV==="stage"){
    // Staging Environment Credentials
    Object.assign(output.credentials, {
        requesterManager: {        // user1 - Creates work orders, manager approval
            email: "asas060304@gmail.com1",
            password: "Admin@2022"
        },
        facilityManager: {         // user2 - OCIF approval, also creates work orders
            email: "e219@minusculetechnologies.com1",
            password: "Admin@2022"
        },
        verifier: {                // user3 - Verifies completed work
            email: "e201@minusculetechnologies.com1",
            password: "Admin@2022"
        },
        fieldTechnician: {         // user4 - Primary technician performing work
            email: "naren150601@gmail.com1",
            password: "Admin@2022"
        },
        seniorTechnician: {        // user5 - Senior technician/engineer
            email: "e218@minusculetechnologies.com1",
            password: "Admin@2022"
        }
    });
}


