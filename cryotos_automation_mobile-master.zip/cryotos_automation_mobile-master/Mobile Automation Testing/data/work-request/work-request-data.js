// Work Request data definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Work Request data - MERGE with existing workreqdata object
if (typeof output.workreqdata === "undefined") output.workreqdata = {};

Object.assign(output.workRequestData, {
    // Asset dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    assets: {
        // First set of assets captured
        cctvCameras: "CCTV Cameras (6)",
        chairs: "Chairs (4)",
        lathe: "Lathe (26)",
        upsSystem: "UPS System (2)",
        ac: "AC (10)",
        testHvac1: "TEST HVAC 1 (AxB08)",
        smokeDetectors: "Smoke Detectors (9)",
        emergencyExitsDoors: "Emergency Exits & Doors (8)",
        fireAlarmPanel: "Fire Alarm Panel (7)",
        vehiclesFleet: "Vehicles & Fleet (5)",
        waterStorageTank: "Water Storage Tank (3)"
    },
    
    // Category dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    categories: {
        // First set of categories captured
        itAvEquipment: "IT(AV) Equipment",
        safetySecurityAssets: "Safety  Security Assets",
        vehiclesFleet: "Vehicles  Fleet",
        furnitureFixtures: "Furniture  Fixtures",
        plumbingWaterSystems: "Plumbing  Water Systems",
        electricalSystems: "Electrical Systems",
        equipment: "Equipment"
    },
    
    // Account dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    accounts: {
        cryotosAutomation: "Cryotos Automation",
        wipro: "Wipro",
        techMahindra: "Tech Mahindra",
        minuscule: "Minuscule",
        lucasTvs: "Lucas TVS"
    },
    
    // Location dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    locations: {
        bangalore: "Bangalore",
        testHvacUnitPlantA: "Test HVAC Unit - Plant A",
        chennai: "CHENNAI",
        pallavaram: "Pallavaram",
        hyderabad: "Hyderabad",
        chrompetChennaiTamilNaduIndia: "Chrompet Chennai Tamil Nadu India"
    },
    
    // Priority dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    priorities: {
        normal: "NORMAL",
        urgent: "URGENT",
        critical: "CRITICAL"
    },
    

    
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        workreqdata: output.workreqdata
    };
}

