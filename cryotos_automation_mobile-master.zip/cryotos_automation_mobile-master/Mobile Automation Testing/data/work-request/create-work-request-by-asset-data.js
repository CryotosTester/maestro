


// Asset Based Work Request Test Data
// This data is used for testing work request creation where asset is the primary selection
// Flow: Asset → Form Fill → Submit (Account and Location auto-populated)

// Initialize global output object if it doesn't exist
if (typeof output === "undefined") {
    output = {};
}

// Work Request Data Structure
// Contains all necessary data for creating a work request starting from asset selection
output.workRequestData = {
    // Account Information - Auto-populated based on selected asset
    account: "Cryotos Automation",
    
    // Location Information - Auto-populated based on selected asset
    location: "Test HVAC Unit - Plant A",
    
    // Asset Information - Primary selection in this flow
    asset: "Mouse",
    
    // Category Information - Auto-populated based on asset selection
    category: "IT\(AV\) Equipment",
    
    // Work Request Details - Form fields to be filled during test execution
    priority: "URGENT",                    // Priority level selection
    description: "",                      // Will be populated with random text during test
    contactName: "",                      // Will be populated with random name during test
    contactNumber: "",                    // Will be populated with random number during test
    invoiceReferenceNumber: "",           // Will be populated with random data during test
    projectReferenceNumber: ""            // Will be populated with random data during test
};


