
// Facility Based Work Request Test Data
// This data is used for testing work request creation where only facility/location is selected
// Flow: Location → Form Fill → Submit (Account auto-populated, no asset selection)

// Initialize global output object if it doesn't exist
if (typeof output === "undefined") {
    output = {};
}

// Work Request Data Structure
// Contains all necessary data for creating a work request starting from facility selection
output.workRequestData = {
    // Account Information - Auto-populated based on selected location
    account: "Wipro",
    
    // Location Information - Primary selection in this flow (facility-based)
    location: "Hyderabad",
    
    // Asset Information - Not applicable for facility-based work requests
    asset: "",
    
    // Category Information - Not applicable when no asset is selected
    category: "",
        
    // Work Request Details - Form fields to be filled during test execution
    priority: "URGENT",                    // Priority level selection
    description: "",                      // Will be populated with random text during test
    contactName: "",                      // Will be populated with random name during test
    contactNumber: "",                    // Will be populated with random number during test
    invoiceReferenceNumber: "",           // Will be populated with random data during test
    projectReferenceNumber: ""            // Will be populated with random data during test
};

