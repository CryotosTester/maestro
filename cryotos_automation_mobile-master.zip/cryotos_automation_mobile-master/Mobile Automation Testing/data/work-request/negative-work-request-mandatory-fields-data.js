
 
if (typeof output === "undefined") {
    output = {};
}


if (typeof output.workRequest === "undefined") output.workRequest = {};
 
Object.assign(output.workRequest, {
   // Asset Information
    errorMessages: {
        account: "Please Choose Account Name",
        location: "Please Choose Location Name",
        description: "Description is required",
        contactNumber: "Contact Number is required",        
    }
});
