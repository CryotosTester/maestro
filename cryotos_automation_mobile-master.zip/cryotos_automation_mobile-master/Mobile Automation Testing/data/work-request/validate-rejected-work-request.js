// Validate Rejected Work Request API Script
// This script sends a POST request to validate a rejected work request using GraalJS

// Request data structure using hardcoded values for minimal approach
var requestData = {
    "moduleType": "workRequest",
    "testCaseName": "Validate Rejected Work Request",
    "loginDetails": {
        "username": "facility.manager@cryotos.com",
        "password": "password123",
        "env": "test"
    },
    "payload": {
        "moduleType": "workRequest",
        "workRequestId": " test",
        "description": " test",
        "locationName": "Location_Customer_1AUQETQZKMW11281821",
        "assetName": "Automation_Asset_AUQETQZKMW11281821",
        "priority": "URGENT",
        "status": "Rejected",
        "contactName": "Demo Contact Person",
        "contactNumber": "1234567890"
    }
};

// Function to send POST request using GraalJS
function sendValidationRequest(data) {
    try {
        console.log('Sending validation request for rejected work request...');
        console.log('Request Data: ' + JSON.stringify(data, null, 2));
        
        // Use http.post to send request to localhost:8080
        var response = http.post('http://localhost:8080/api/test/validate', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        console.log("Status Code: " + response.status);
        console.log("Response Body: " + response.body);
        
        // Try to parse as JSON
        try {
            var jsonResponse = JSON.parse(response.body);
            console.log("Parsed JSON Response: " + JSON.stringify(jsonResponse, null, 2));
            return jsonResponse;
        } catch (parseError) {
            console.log("Response is not valid JSON: " + response.body);
            return response.body;
        }
        
    } catch (error) {
        console.log("Request Error: " + error.message);
        throw error;
    }
}

// Execute the request
sendValidationRequest(requestData);
