// Demo Work Request Test Data
// This data contains hardcoded values for demonstration purposes
// Used for testing work request creation with predefined static values

// Initialize global output object if it doesn't exist
if (typeof output === "undefined") {
    output = {};
}

// Demo Work Request Data Structure
// Contains all hardcoded data for creating a work request
output.workRequestData = {
    // Account Information - Primary selection in this flow
    account: "Cryotos Automation Demo Account",
    
    // Location Information - Secondary selection based on account
    location: "Location_Customer_1AUQETQZKMW11281821",
    
    // Asset Information - Selected from available assets at the location
    asset: "Automation_Asset_AUQETQZKMW11281821",
    
    // Category Information - Auto-populated based on asset selection
    category: "IT(AV) Equipment Demo",
    
    // Work Request Details - Form fields with hardcoded values
    priority: "URGENT",                    // Priority level selection
    description: " test", // Hardcoded description
    contactName: "Demo Contact Person",    // Hardcoded contact name
    contactNumber: "1234567890",           // Hardcoded contact number
    invoiceReferenceNumber: "INV-DEMO-2024-001", // Hardcoded invoice reference
    projectReferenceNumber: "PROJ-DEMO-2024-001"  // Hardcoded project reference
};
