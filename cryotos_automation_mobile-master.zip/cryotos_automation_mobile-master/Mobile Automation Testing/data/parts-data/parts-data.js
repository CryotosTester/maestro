// Parts data definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Parts data - MERGE with existing partsdata object
if (typeof output.partsdata === "undefined") output.partsdata = {};

Object.assign(output.partsdata, {
    // Parts dropdown options - UPDATE THESE WITH ACTUAL VALUES FROM YOUR MOBILE
    parts: {
        screwdrivers: "Screwdrivers",
        lubricant: "lubricant",
        spindle_bearing: "Spindle bearing",
        laptop: "Laptop",
        desktop: "Desktop"
    },
    
    // Warehouse dropdown options - UPDATE THESE WITH ACTUAL VALUES FROM YOUR MOBILE
    warehouses: {
        spare_parts_warehouse: "Spare Parts Warehouse",
        prime_storage_co: "Prime Storage Co"
    },
    
    // Location dropdown options - UPDATE THESE WITH ACTUAL VALUES FROM YOUR MOBILE
    locations: {
        chrompet: "Chrompet",
        bangalore: "Bangalore",
        chennai: "Chennai"
    },
    
    
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        partsdata: output.partsdata
    };
}


