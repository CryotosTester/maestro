// Parts inward/outward data definitions for CMMS Mobile App

if (typeof output === "undefined") {
    output = {};
}

// Parts inward/outward data - MERGE with existing partsInventoryData object
if (typeof output.partsInventoryData === "undefined") output.partsInventoryData = {};

Object.assign(output.partsInventoryData, {
    searchPart: "memorycard"
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        partsInventoryData: output.partsInventoryData
    };
}
