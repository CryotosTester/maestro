// Breakdown Basic Maintenance Workflow - Field Labels and IDs
// Extracted from breakdown_basic.json template
// This file contains field definitions for the Breakdown (Basic) workflow

if (typeof output === "undefined") { 
    output = {}; 
}

// Breakdown Basic Maintenance Workflow Structure - MERGE with existing breakdownBasic object
if (typeof output.breakdownBasic === "undefined") output.breakdownBasic = {};

Object.assign(output.breakdownBasic, {
    
    // Form Titles
    formTitles: {
        breakdownRequest: "Breakdown Request",
        breakdownExecution: "Breakdown Execution Form", 
        supervisorApproval: "Supervisor Approval",
        approval: "Approval",
        form5: "Form 5"
    },
    
    // Section Names
    sections: {
        breakdownRequestInfo: "Breakdown Request info",
        breakdownExecutionForm: "Breakdown Execution Form",
        openBreakdown: "Open Breakdown",
        remarks: "Remarks",
        sgxjvbj: "sgxjvbj"
    },
    
    // Field Labels and IDs from Breakdown Request info section
    breakdownRequestFields: {
        hasNext: "HasNext",
        dateOfBreakdown: "Date of Breakdown",
        videoIfAny: "Video if any", 
        sign: "SIGN",
        img: "img",
        radio: "Radio"
    },
    
    // Field Labels and IDs from Breakdown Execution Form section
    breakdownExecutionFields: {
        hasNext: "HasNext",
        machineDownTime: "Machine Down Time",
        technicalObservation: "Technical Observation",
        technicalSolution: "Technical Solution",
        problemSolved: "Problem Solved",
        afterImage: "After Image",
        whyAnalysis1: "Why Analysis - 1",
        whyAnalysis2: "Why Analysis - 2", 
        whyAnalysis3: "Why Analysis - 3",
        machineUpTime: "Machine Up Time",
        otherCostDescription: "Other Cost Description",
        otherCost: "Other Cost",
        cableHasToChecked: "Cable has to checked",
        checkTheOilFilter: "Check the oil filter"
    },
    
    // Field Labels and IDs from Supervisor Approval section
    supervisorApprovalFields: {
        hasNext: "HasNext",
        description: "Description",
        reasons: "Reasons",
        signature: "signature"
    },
    
    // Field Labels and IDs from Approval section
    approvalFields: {
        hasNext: "HasNext",
        managerApprovalRemarks: "Manager Approval Remarks",
        approved: "Approved"
    },
    
    // Field Labels and IDs from Form 5 section
    form5Fields: {
        hasNext: "HasNext",
        description: "Description"
    },
    
    // Button Labels
    buttons: {
        submitToTechnician: "Submit to Technician",
        close: "Close",
        submitForManagerApproval: "Submit for Manager Approval",
        saveAsDraft: "Save As Draft",
        reject: "Reject",
        openBreakdown: "Open Breakdown",
        approval: "Approval",
        reWork: "Re Work"
    },
    
    // Dropdown Options
    dropdownOptions: {
        problemSolved: ["Yes", "No"],
        whyAnalysis3: ["Option 1", "Option 2", "Option 3"],
        cableHasToChecked: ["Yes", "option"]
    },
    
    // Field Types
    fieldTypes: {
        hasNext: "hasNext",
        dateTime: "dateTime",
        video: "video",
        signatureOnly: "signatureOnly",
        images: "images",
        textInput: "textInput",
        radioButton: "radioButton",
        imageWithAnnotation: "imageWithAnnotation",
        dropDown: "dropDown",
        numeric: "numeric",
        checkBox: "checkBox",
        toggleWithReason: "toggleWithReason",
        signaturewithSatisfactory: "signaturewithSatisfactory",
        textArea: "textArea"
    },
    
    // UUIDs for field identification (if needed)
    fieldUUIDs: {
        dateOfBreakdown: "2019b0a15e9506804050f146855c4a93",
        videoIfAny: "39011a9ea337c6832bf087c0b9547e0b",
        sign: "d84ecbb3e7de3ae073134bdd8584b0b2",
        img: "fc0a513c989c10e74028dd3cb2089fac",
        radio: "40a7f65407fd77e8061713e4937a1db3",
        machineDownTime: "c58d0470b742b7b9224b2d5ea87194cb",
        technicalObservation: "8277acbb6c2a7bfffd97760302356810",
        technicalSolution: "e78f91fd7d0e1905dbaf4a4d39198da3",
        problemSolved: "6e29c131607538133d7746dc69d215d2",
        afterImage: "629e61aeabdbd0d6863ffbf5d1b7d129",
        whyAnalysis1: "3829f48fe4726d70aa85fed64d15f6e4",
        whyAnalysis2: "bd5e4e0712142d3fa1bfbc5aac018024",
        whyAnalysis3: "fa66c204187594f2f600fa1ade0894fb",
        machineUpTime: "0d301b2fd6473f59d0464668973e32e6",
        otherCostDescription: "70c7b9b7b3a4b052c62708d6777adadb",
        otherCost: "f98d370e3091fbe9b12005af5ae0842e",
        cableHasToChecked: "0aaaee3f69956bbe6dc77a9dc5762ba2",
        checkTheOilFilter: "5c38370e46e78f310e89e201621747a8",
        description: "9a2f3a173db06c81cbde54541bee454e",
        reasons: "c0680f265777f411f32260419d241576",
        signature: "dc5e13fa3e3e8e371fdf5716a9d52518",
        managerApprovalRemarks: "5e738a0e322c5ab4bc6a4adc2672b0c6",
        approved: "26496020a4507310eeea324e467de209",
        form5Description: "fceefb55a4278e6b94814fde4d978338"
    }
});

