// API Request Data for Playwright Work Order Creation
// This file contains the data structure for API requests to the Playwright server

const apiRequestData = {
  // Base configuration
  baseUrl: 'http://localhost:3000',
  endpoints: {
    createWorkOrder: '/api/create-workorder',
    login: '/api/login',
    health: '/health'
  },
  
  // Login credentials
  login: {
    url: 'https://stage.cryotos.com/#/login',
    username: 'admin@test.com',
    password: 'Admin@2022'
  },
  
  // Work order data sets
  workOrders: {
    default: {
      asset: 'DELL LAPTOP (3600)',
      workflow: 'Flutter testing with all fields',
      description: 'Hello PlayWright Work Order',
      account: 'Minuscule',
      location: 'Chennai'
    },
    educational: {
      asset: 'Educational Equipment',
      workflow: 'Educational Equipment Breakdown',
      description: 'Educational Equipment Maintenance',
      account: 'Educational Institution',
      location: 'Classroom A'
    },
    foodProcessing: {
      asset: 'Food Processing Machine',
      workflow: 'Food Processing Emergency',
      description: 'Emergency Food Processing Maintenance',
      account: 'Food Processing Plant',
      location: 'Production Floor'
    }
  },
  
  // Headers for API request
  headers: {
    'Content-Type': 'application/json'
  },
  
  // Get work order payload for specific type
  getWorkOrderPayload: function(workOrderType = 'default') {
    const workOrder = this.workOrders[workOrderType] || this.workOrders.default;
    return {
      loginUrl: this.login.url,
      username: this.login.username,
      password: this.login.password,
      asset: workOrder.asset,
      workflow: workOrder.workflow,
      description: workOrder.description,
      account: workOrder.account,
      location: workOrder.location
    };
  },
  
  // Get login payload
  getLoginPayload: function() {
    return {
      url: this.login.url,
      username: this.login.username,
      password: this.login.password
    };
  },
  
  // Get full URL for specific endpoint
  getUrl: function(endpoint = 'createWorkOrder') {
    return this.baseUrl + this.endpoints[endpoint];
  },
  
  // Get all available work order types
  getWorkOrderTypes: function() {
    return Object.keys(this.workOrders);
  }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = apiRequestData;
} else {
  // For Maestro environment
  window.apiRequestData = apiRequestData;
}
