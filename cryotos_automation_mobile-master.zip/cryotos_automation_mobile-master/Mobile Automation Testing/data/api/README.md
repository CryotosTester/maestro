# API Request Data Structure

This directory contains the data configuration for API requests to the Playwright server.

## Files

- `apiRequestData.js` - Main data configuration file
- `../shared/apiRequest.js` - Work order creation API request
- `../shared/apiLoginRequest.js` - Login API request

## Usage

### Basic Usage

```javascript
// Load the data
const apiData = require('./data/api/apiRequestData.js');

// Get default work order payload
const payload = apiData.getWorkOrderPayload();

// Get specific work order type
const educationalPayload = apiData.getWorkOrderPayload('educational');

// Get login payload
const loginPayload = apiData.getLoginPayload();

// Get URL for specific endpoint
const workOrderUrl = apiData.getUrl('createWorkOrder');
const loginUrl = apiData.getUrl('login');
```

### Available Work Order Types

1. **default** - Standard work order
2. **educational** - Educational equipment work order
3. **foodProcessing** - Food processing equipment work order

### Environment Variables

You can set the work order type using environment variables:

```bash
# Set work order type
export WORK_ORDER_TYPE=educational

# Or in Maestro flows
WORK_ORDER_TYPE: educational
```

### Data Structure

```javascript
{
  baseUrl: 'http://localhost:3000',
  endpoints: {
    createWorkOrder: '/api/create-workorder',
    login: '/api/login',
    health: '/health'
  },
  login: {
    url: 'https://stage.cryotos.com/#/login',
    username: 'admin@test.com',
    password: 'Admin@2022'
  },
  workOrders: {
    default: { /* work order data */ },
    educational: { /* work order data */ },
    foodProcessing: { /* work order data */ }
  }
}
```

## Benefits

1. **Centralized Configuration** - All API data in one place
2. **Multiple Work Order Types** - Easy to switch between different scenarios
3. **Environment Flexibility** - Can be configured via environment variables
4. **Maintainable** - Easy to update credentials and endpoints
5. **Reusable** - Can be used across different Maestro flows
