// Asset Based WOC Test Data
// Test data for asset-based work order creation scenario using food processing workflow

if (typeof output === "undefined") {
    output = {};
}

// Asset Based WOC Data Structure - MERGE with existing assetBasedWocData object
if (typeof output.assetBasedWocData === "undefined") output.assetBasedWocData = {};

// Use the centralized UUID from uuid-storage.js
// NOTE: uuid-storage.js must be loaded before this file in the YAML

Object.assign(output.assetBasedWocData, {
   
    // Description (UUID for this test run)
    description: output.uuid,
   
    // Asset Information
    asset: {
        name: "Assembly Line Unit 3",
        type: "Manufacturing Equipment",
        location: "Bangalore",
        account: "Tech Mahindra"
    },
   
    // Workflow Information
    workflow: {
        name: "Food Processing Line Emergency BD",
        priority: "NORMAL"
    },
   
    // Form 1: Production Line Issue Data
    productionLineIssue: {
        productionImpact: {
            productionImpact: "Partial",
            observedIssues: "Unusual Noise"
        },
        complianceAndLoss: {
            haccpProtocolTriggered: "HACCP Protocol Triggered - No",
            issueStartTime: "2024-01-15T08:30:00"
        }
    },
   
    // Form 2: Maintenance Response Data
    maintenanceResponse: {
        resolution: {
            rootCause: "Lack of Maintenance",
            safetySystemTest: "Safety System Test - Pass",
            sparePartUsed: "Hydraulic Pump P-150",
            technicianSignOff: "Technician signature and satisfactory feedback"
        }
    },
   
    // User assignments
    users: {
        technician: "Iyneshwar",
        engineer: "Production Engineer",
        supervisor: "Line Supervisor"
    },
   
    // Button elements
    buttons: {
        submitToMaintenanceResponse: "Submit to Maintenance Response",
        submitToQualityControl: "Submit to Quality Control",
        good: "Good"
    }
});

