// Work Order Data - Fields and Dropdown Values
// This file will contain field definitions and dropdown options for Work Order creation
// Values will be extracted from mobile device

if (typeof output === "undefined") { 
    output = {}; 
}

// Work Order Data Structure - MERGE with existing workorder object
if (typeof output.workorder === "undefined")
     output.workorder = {};

Object.assign(output.workorder, {
    
    // Named Data Access - More readable and maintainable
    dropdowns: {
        account: {
            "Lucas TVS": "Lucas TVS",
            "Minuscule": "Minuscule", 
            "Tech Mahindra": "Tech Mahindra",
            "Wipro": "Wipro",
            "Cryotos Automation": "Cryotos Automation"
        },
        location: {
            "Bangalore": "Bangalore",
            "Test HVAC Unit - Plant A": "Test HVAC Unit - Plant A",
            "CHENNAI": "CHENNAI",
            "Pallavaram": "Pallavaram",
            "Hyderabad": "Hyderabad",
            "Chrompet Chennai Tamil Nadu India": "Chrompet Chennai Tamil Nadu India",
            "Production Building A": {
                value: "Production Building A",
                subLocations: {
                    "Ground-Floor Line 3": "Ground-Floor Line 3"
                }
            }
        },
        asset: {
            "Vehicles & Fleet": "Vehicles & Fleet",
            "Fire Alarm Panel": "Fire Alarm Panel",
            "Emergency Exits & Doors": "Emergency Exits & Doors",
            "Smoke Detectors": "Smoke Detectors",
            "AC": "AC",
            "UPS System": "UPS System",
            "CCTV Cameras": "CCTV Cameras",
            "Lathe": "Lathe",
            "Chairs": "Chairs",
            "TEST HVAC 1": "TEST HVAC 1",
            "3D-Printer-Lab205": "3D-Printer-Lab205"
        },
        workflow: {
            "Meter_Schedule": "Meter_Schedule",
            "Mechanical Shop": "Mechanical Shop",
            "Flutter Test": "Flutter Test",
            "Breakdown Maintenance -Ticket": "Breakdown Maintenance -Ticket",
            "Breakdown Maintenance - Academic": "Breakdown Maintenance - Academic",
            "Breakdown - Basic": "Breakdown - Basic",
            "Breakdown123": "Breakdown123",
            "[E2E-01] Educational Equipment Breakdown": "[E2E-01] Educational Equipment Breakdown",
            "[E2E-002] Food Processing Line Emergency BD": "[E2E-002] Food Processing Line Emergency BD"
        },
        priority: {
            normal: "NORMAL",
            urgent: "URGENT",
            critical: "CRITICAL"
        }
    },
    
  
    
    
});

