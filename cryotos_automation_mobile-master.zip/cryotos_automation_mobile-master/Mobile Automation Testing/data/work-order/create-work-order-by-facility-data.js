if (typeof output === "undefined") {
    output = {};
}
if (typeof output.facilityBasedWocData === "undefined") output.facilityBasedWocData = {};
Object.assign(output.facilityBasedWocData, {
    location: {
        name: "Office-Building-B",
        type: "Commercial Facility",
        account: "Minuscule"
    },
    workflow: {
        name: "Facility Electrical Issue",
        priority: "URGENT"
    },
    description: ""
});
