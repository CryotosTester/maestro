// Data for negative-work-order-location-account.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.locationAccount === "undefined") output.locationAccount = {};
Object.assign(output.locationAccount, {
  locationName: "OFFICE",
  expectedAccount: "Cryotos Automation"
});
