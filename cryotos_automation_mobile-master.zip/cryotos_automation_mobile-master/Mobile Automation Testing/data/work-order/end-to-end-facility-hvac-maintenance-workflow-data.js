// E2E-03 Facility HVAC Maintenance Test Data
// Test data for Microsoft Building Campus HVAC-Unit-B15-01 maintenance scenario

if (typeof output === "undefined") { 
    output = {}; 
}


// E2E-03 Test Data Structure - MERGE with existing e2e03Data object
if (typeof output.e2e03Data === "undefined") output.e2e03Data = {};

Object.assign(output.e2e03Data, {
    
    // Asset Information
    asset: {
        name: "Hvac",
        type: "HVAC System",
        location: "Perumal Nagar Minuscule Technologies",
        account: "Minuscule"
    },
    
    // Workflow Information
    workflow: {
        name: "HVAC Repair Service",
        priority: "NORMAL",
   
    },
    
    description: ""

});

