// Data for negative-work-order-description-whitespace.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.descriptionWhitespace === "undefined") output.descriptionWhitespace = {};
Object.assign(output.descriptionWhitespace, {
  assetName: "UPS System",
  workflowName: "Comprehensive Equipment Maintenance & Inspection",
  priority: "URGENT",
  spaceInput: " ",
  expectedErrorText: "This field cannot be empty."
});
