// E2E-07 Fire Alarm Panel Breakdown Test Data
// Test data for Temperature-Sensor-Floor7 conditional temperature response scenario

if (typeof output === "undefined") { 
    output = {}; 
}

// E2E-07 Test Data Structure - MERGE with existing e2e07Data object
if (typeof output.e2e07Data === "undefined") output.e2e07Data = {};

Object.assign(output.e2e07Data, {
    
    // Asset Information
    asset: {
        name: "Temperature-Sensor-Floor7",
        type: "Smart Building Temperature Control",
        location: "Smart Office - Floor 7",
        account: "Smart Office"
    },
    
    // Workflow Information
    workflow: {
        name: "Fire Alarm Panel Breakdown",
        priority: "NORMAL", // Conditional: changes based on temperature
    },
    description: ""

});


