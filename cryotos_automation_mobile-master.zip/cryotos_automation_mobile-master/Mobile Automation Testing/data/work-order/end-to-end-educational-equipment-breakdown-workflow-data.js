// E2E-01 Educational Equipment Breakdown Test Data
// Test data for 3D-Printer-Lab205 asset breakdown scenario
 
if (typeof output === "undefined") {
    output = {};
}
// Use the centralized UUID from uuid-storage.js
// NOTE: uuid-storage.js must be loaded before this file in the YAML

// E2E-01 Test Data Structure - MERGE with existing e2e01Data object
if (typeof output.e2e01Data === "undefined") output.e2e01Data = {};
 
Object.assign(output.e2e01Data, {
   // Asset Information
    asset: {
        name: "3D-Printer-Lab205",
        type: "3D Printer",
        location: "OFFICE",
        account: "Cryotos Automation"
    },
   // Workflow Information
    workflow: {
        name: "Educational Equipment Breakdown",
        priority: "NORMAL"
    },
    description: ""
});

