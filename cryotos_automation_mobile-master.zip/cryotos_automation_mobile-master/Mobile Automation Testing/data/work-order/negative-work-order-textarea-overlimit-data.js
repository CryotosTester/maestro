// Test data for Work Order Description textarea over-limit negative scenario

if (typeof output === "undefined") {
  output = {};
}

// Namespace for this test's data
if (typeof output.textareaOverlimit === "undefined") output.textareaOverlimit = {};

Object.assign(output.textareaOverlimit, {
  // Selection data
  assetName: "UPS System",
  workflowName: "Comprehensive Equipment Maintenance & Inspection",
  priority: "URGENT",

  // Text input strategy
  overLimitChar: "a",

  // Exact sentence to input (targeting ~255 chars as provided)
  exactText: "Creating a sentence that is precisely 255 characters long, including all spaces and punctuation like a period at the end, requires careful crafting to ensure accuracy in meeting the requested length constraint, presenting a specific and somewhat unusual .",

  // Expected UI indicator when limit is enforced
  expectedCounterText: "No characters remaining"
});
