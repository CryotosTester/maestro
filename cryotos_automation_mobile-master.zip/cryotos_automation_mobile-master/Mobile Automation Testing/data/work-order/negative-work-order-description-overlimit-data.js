// Data for negative-work-order-description-overlimit.yaml (alias of textarea-overlimit)
if (typeof output === "undefined") { output = {}; }
if (typeof output.descriptionOverlimit === "undefined") output.descriptionOverlimit = {};
Object.assign(output.descriptionOverlimit, {
  assetName: "UPS System",
  workflowName: "Comprehensive Equipment Maintenance & Inspection",
  priority: "URGENT",
  overLimitChar: "a",
  exactText: "Creating a sentence that is precisely 255 characters long, including all spaces and punctuation like a period at the end, requires careful crafting to ensure accuracy in meeting the requested length constraint, presenting a specific and somewhat unusual .",
  expectedCounterText: "No characters remaining"
});
