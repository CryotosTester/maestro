// Data for negative-work-order-number-input-special-character.yaml
if (typeof output === 'undefined') { output = {}; }
if (typeof output.numberSpecial === 'undefined') output.numberSpecial = {};

Object.assign(output.numberSpecial, {
  assetName: 'UPS System',
  workflowName: 'Comprehensive Equipment Maintenance & Inspection',
  priorityName: 'URGENT',
  description1: `Description ${output.uuid}`,
  description2: `Description ${output.uuid}`,
  descriptionFieldText: 'Description',
  voltageReadingId: 'Voltage Reading',
  specialChars: '%^&*'
});
