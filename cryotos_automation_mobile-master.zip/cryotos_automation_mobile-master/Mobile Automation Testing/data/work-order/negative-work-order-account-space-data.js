// Data for negative-work-order-account-space.yaml (whitespace)
if (typeof output === "undefined") { output = {}; }
if (typeof output.accountWhitespace === "undefined") output.accountWhitespace = {};
Object.assign(output.accountWhitespace, {
  expectedText: "Please Choose Account Name",
  spaceInput: " "
});
