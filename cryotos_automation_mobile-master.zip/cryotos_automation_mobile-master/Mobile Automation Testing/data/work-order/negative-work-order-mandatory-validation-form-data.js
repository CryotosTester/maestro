// Data for labels, IDs, and texts used in mandatory validation flow
if (typeof output === 'undefined') { output = {}; }
if (typeof output.mandatoryForm === 'undefined') output.mandatoryForm = {};

Object.assign(output.mandatoryForm, {
  // General
  formSectionId: 'Form 2',
  errorText: 'This field cannot be empty.',
  errorSelectAtLeastOne: 'Please select at least one option',
  errorDateRequired: 'Date is required',
  errorDateTimeRequired: 'Date and time is required',

  // Fields and values
  productionStatusId: 'Production Status',
  productionStatusValueReduced: 'Reduced',
  voltageReadingId: 'Voltage Reading',
  voltageReadingValue: '234',
  warehouseId: 'Warehouse',
  otherId: 'Other',
  equipmentBreakdownOption: 'Equipment Breakdown',
  dateOfBreakdownId: 'Date of Breakdown',
  firstOccurrenceId: 'First Occurrence',
  electricalTestPassId: 'Electrical Test - Pass',
  equipmentMaintenanceManualId: 'Equipment Maintenance Manual',
  equipmentMaintenanceManualText: 'Equiment maintanance',
  backupPowerActiveYesId: 'Backup Power Active - Yes',
  afterImageBrowseImageId: 'After Image Browse Image',

  // Picker/media texts
  pickerMoreText: 'More',
  pickerBrowseText: 'Browse…',
  pickerFileLabel: '190mb.jpg, 205 MB, Nov 5',

  // Quality and signature
  qualityExcellentId: 'Excellent',
  technicianSignatureId: 'Technician Signature',
  saveText: 'Save',
  signId: 'SIGN',
  okText: 'OK',

  // Submission
  submitButtonId: 'submit_button',
  chooseAtLeastOneUserText: 'Choose atleast one user!!',
  selectAllUsersId: 'select_all_users',

  // Post-submit workflow navigation
  wipId: 'Work in Progress',
  workflowDescriptionId: 'description about workflow',
  acknowledgeId: 'acknowledge',
  updateStatusId: 'update_status',
  submitId: 'submit',

  // Date strings (note: these are device/locale dependent)
  datePickerToday: '6, Thursday, November 6, 2025, Today',
  firstOccurrenceDate: '20, Thursday, November 20, 2025'
});
