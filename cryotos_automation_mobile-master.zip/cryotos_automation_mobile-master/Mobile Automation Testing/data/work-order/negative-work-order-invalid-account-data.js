// Data for negative-work-order-invalid-account.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.invalidAccount === "undefined") output.invalidAccount = {};
Object.assign(output.invalidAccount, {
  workflowName: "Comprehensive Equipment Maintenance & Inspection",
  accountInvalidName: "Invalid Account Name",
  expectedText: "No records found"
});
