// Data for negative-work-order-account-location-empty-validation.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.accountEmpty === "undefined") output.accountEmpty = {};
Object.assign(output.accountEmpty, {
  workflowName: "Comprehensive Equipment Maintenance & Inspection",
  expectedText: "Please Choose Account Name",
  expectedTextLocation: "Please Choose Location Name"
});
