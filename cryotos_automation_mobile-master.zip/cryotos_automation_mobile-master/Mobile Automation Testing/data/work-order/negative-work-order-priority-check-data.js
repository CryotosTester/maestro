// Data for negative-work-order-priority-check.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.priorityCheck === "undefined") output.priorityCheck = {};
Object.assign(output.priorityCheck, {
  assetName: "UPS System",
  workflowName: "Comprehensive Equipment Maintenance & Inspection",
  invalidPriorityName: "Invalid Priority Name",
  expectedText: "No records found"
});
