// Data for negative-work-order-invalid-location.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.invalidLocation === "undefined") output.invalidLocation = {};
Object.assign(output.invalidLocation, {
  locationInvalidName: "Invalid Location Name",
  expectedText: "No records found"
});
