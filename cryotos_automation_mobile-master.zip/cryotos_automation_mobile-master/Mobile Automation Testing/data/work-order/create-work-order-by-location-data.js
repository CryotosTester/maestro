if (typeof output === "undefined") {
    output = {};
}
if (typeof output.locationBasedWocData === "undefined") output.locationBasedWocData = {};
Object.assign(output.locationBasedWocData, {
    location: {
        name: "CHENNAI",
        type: "City Location",
        account: "Minuscule"
    },
    asset: {
        name: "Main-Distribution-Board",
        type: "Electrical Panel",
        category: "Electrical System"
    },
    workflow: {
        name: "Food Processing Line Emergency BD",
        priority: "CRITICAL"
    },
    description: ""
});
