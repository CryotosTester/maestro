// Data for negative-work-order-asset-space.yaml (whitespace)
if (typeof output === "undefined") { output = {}; }
if (typeof output.assetWhitespace === "undefined") output.assetWhitespace = {};
Object.assign(output.assetWhitespace, {
  expectedText: "No records found",
  spaceInput: " "
});
