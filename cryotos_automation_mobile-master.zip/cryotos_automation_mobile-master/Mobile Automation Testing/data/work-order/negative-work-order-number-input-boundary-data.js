// Data for negative-work-order-number-input-boundary.yaml
if (typeof output === 'undefined') { output = {}; }
if (typeof output.numberBoundary === 'undefined') output.numberBoundary = {};

Object.assign(output.numberBoundary, {
  assetName: 'UPS System',
  workflowName: 'Comprehensive Equipment Maintenance & Inspection',
  priorityName: 'URGENT',
  description1: `Description ${output.uuid}`,
  description2: `Description ${output.uuid}`,
  descriptionFieldText: 'Description',
  voltageReadingId: 'Voltage Reading',
  longNumber: '824971563028475910236549871235698741203659847120365984710236598471023659847120365984710236598471023659847120365984710236598471023659'
});
