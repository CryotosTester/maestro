// Location + Asset Based WOC Test Data
// Test data for location + asset based work order creation scenario

if (typeof output === "undefined") {
    output = {};
}

// Location + Asset Based WOC Data Structure - MERGE with existing locationAssetBasedWocData object
if (typeof output.locationAssetBasedWocData === "undefined") output.locationAssetBasedWocData = {};

// Use the centralized UUID from uuid-storage.js
// NOTE: uuid-storage.js must be loaded before this file in the YAML

Object.assign(output.locationAssetBasedWocData, {
   
    // Description (UUID for this test run)
    description: output.uuid,
   
    // Location Information
    location: {
        name: "CHENNAI",
        type: "City Location",
        account: "Minuscule"
    },
   
    // Asset Information
    asset: {
        name: "Fire Alarm Panel",
        type: "Safety Equipment",
        category: "Equipment"
    },
   
    // Workflow Information
    workflow: {
        name: "Breakdown - Basic",
        priority: "NORMAL"
    }
});

