// Account Based WOC Test Data
// Test data for account-based work order creation scenario

if (typeof output === "undefined") {
    output = {};
}

// Account Based WOC Data Structure - MERGE with existing accountBasedWocData object
if (typeof output.accountBasedWocData === "undefined") output.accountBasedWocData = {};

// Use the centralized UUID from uuid-storage.js
// NOTE: uuid-storage.js must be loaded before this file in the YAML

Object.assign(output.accountBasedWocData, {
   
    // Description (UUID for this test run)
    description: output.uuid,
   
    // Asset Information
    asset: {
        name: "TEST HVAC 1",
        type: "HVAC Equipment",
        location: "Test HVAC Unit - Plant A",
        account: "Cryotos Automation"
    },
   
    // Workflow Information
    workflow: {
        name: "Breakdown - Basic",
        priority: "NORMAL"
    }
});

