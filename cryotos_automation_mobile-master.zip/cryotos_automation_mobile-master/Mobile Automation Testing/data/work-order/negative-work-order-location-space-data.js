// Data for negative-work-order-location-space.yaml (whitespace)
if (typeof output === "undefined") { output = {}; }
if (typeof output.locationWhitespace === "undefined") output.locationWhitespace = {};
Object.assign(output.locationWhitespace, {
  expectedText: "Please Choose Location Name",
  spaceInput: " "
});
