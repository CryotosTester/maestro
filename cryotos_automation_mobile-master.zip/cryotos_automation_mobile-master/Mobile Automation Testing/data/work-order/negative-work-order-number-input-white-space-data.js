// Data for negative-work-order-number-input-white-space.yaml
if (typeof output === 'undefined') { output = {}; }
if (typeof output.numberWhitespace === 'undefined') output.numberWhitespace = {};

Object.assign(output.numberWhitespace, {
  assetName: 'UPS System',
  workflowName: 'Comprehensive Equipment Maintenance & Inspection',
  priorityName: 'URGENT',
  description1: `Description ${output.uuid}`,
  description2: `Description ${output.uuid}`,
  descriptionFieldText: 'Description',
  voltageReadingId: 'Voltage Reading',
  whitespace: ' '
});
