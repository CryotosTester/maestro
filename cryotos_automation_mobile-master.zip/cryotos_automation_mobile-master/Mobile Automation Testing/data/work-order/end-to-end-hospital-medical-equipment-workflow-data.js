// E2E-05 Hospital Medical Equipment Test Data
// Test data for MRI Scanner breakdown scenario
 
if (typeof output === "undefined") {
    output = {};
}

// E2E-05 Test Data Structure - MERGE with existing e2e05Data object
if (typeof output.e2e05Data === "undefined") output.e2e05Data = {};
 
Object.assign(output.e2e05Data, {
    // Asset Information
    asset: {
        name: "MRI-Scanner-02",
        account: "Apollo",
        location: "COIMBATORE"
    },
    
    // Workflow Information
    workflow: {
        name: "MRI Scanner Breakdown",
        priority: "NORMAL",
    },
    description: ""
});
