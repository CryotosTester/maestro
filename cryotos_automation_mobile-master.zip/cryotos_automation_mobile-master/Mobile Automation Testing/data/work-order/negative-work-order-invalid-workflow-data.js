// Data for negative-work-order-invalid-workflow.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.invalidWorkflow === "undefined") output.invalidWorkflow = {};
Object.assign(output.invalidWorkflow, {
  workflowInvalidName: "Invalid Workflow Name",
  expectedText: "No records found"
});
