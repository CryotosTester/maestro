// Work Order test data for Lincoln CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Shared Test Data Values
if (typeof output.lincolnTestData === "undefined") output.lincolnTestData = {};

Object.assign(output.lincolnTestData, {
    // Default Values
    workflowType: 'Break Down',
    account: '',
    location:'',
    priority: 'URGENT',
    description:'',
    customerEmail: 'e218@minusculetechnologies.com',
    
    // Asset Creation Values
    category: 'Equipment',
    department: 'General',
    createAsset: "",
    serialNo: '',
    assetName: '',
    machineCode: '',
    partNo: ''
});

// Asset Details Data for Validation
if (typeof output.assetData === "undefined") output.assetData = {};

Object.assign(output.assetData, {
    // Map Lincoln asset data to asset details format
    assetName: output.lincolnTestData.assetName,
    machineCode: output.lincolnTestData.machineCode,
    partNo: output.lincolnTestData.partNo ,
    category: output.lincolnTestData.category ,
    department: output.lincolnTestData.department ,
    customer: output.lincolnTestData.account, // Default customer value
    location: output.lincolnTestData.location  // Default location value
});
