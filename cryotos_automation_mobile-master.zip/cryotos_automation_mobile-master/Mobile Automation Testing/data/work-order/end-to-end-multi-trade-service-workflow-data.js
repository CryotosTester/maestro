// E2E-08 Building Systems Emergency Response Test Data
// Test data for building systems emergency response scenario

if (typeof output === "undefined") {
    output = {};
}

// E2E-08 Data Structure - MERGE with existing e2eWo008Data object
if (typeof output.e2e08Data === "undefined") output.e2e08Data = {};

Object.assign(output.e2e08Data, {
   
   
    // Location Information
    location: {
        name: "Main Building",
        type: "Commercial Building"
    },
   
    // Workflow Information
    workflow: {
        name: "Building Systems Emergency Response",
        priority: "CRITICAL"
    },
   description: ""
       
});

