// Data for negative-work-order-invalid-asset.yaml
if (typeof output === "undefined") { output = {}; }
if (typeof output.invalidAsset === "undefined") output.invalidAsset = {};
Object.assign(output.invalidAsset, {
  assetInvalidName: "Invalid Asset Name",
  expectedText: "No records found"
});
