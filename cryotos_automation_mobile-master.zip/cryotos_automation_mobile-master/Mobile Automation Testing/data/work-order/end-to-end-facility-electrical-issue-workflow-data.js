// E2E-WO-006 Facility Electrical Issue Test Data
// Test data for facility electrical issue scenario

if (typeof output === "undefined") {
    output = {};
}

// E2E-06 Test Data Structure - MERGE with existing e2e06Data object
if (typeof output.e2e06Data === "undefined") output.e2e06Data = {};

// Use the centralized UUID from uuid-storage.js
// NOTE: uuid-storage.js must be loaded before this file in the YAML

Object.assign(output.e2e06Data, {
   
    // Asset Information
    asset: {
        name: "Electrical-Panel-MDB-C-B1-01",
        type: "Electrical Panel",
        location: "Basement - Electrical Room",
        account: "Lucas TVS"
    },
   
    // Workflow Information
    workflow: {
        name: "Facility Electrical Issue",
        priority: "NORMAL"
    },
   
    description: ""
});
