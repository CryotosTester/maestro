// Test data and output variables for Maestro Test Automation
// Initialize output object if it doesn't exist
if (typeof output === 'undefined') {
    output = {};
}

// Initialize output variables
output.description = "";
output.equipmentId = "";
output.faultDescription = "";
output.reasonForPending = "";
output.formattedDate = "";
output.faultOccurrenceTime = "";

// Work in Progress form variables
output.plannedMaintenanceWindow = "";
output.preliminaryRootCause = "";

// Work Order Closure form variables
output.correctiveActionSummary = "";
output.downtimeDuration = "";
output.maintenanceSupervisorSignoff = "";

// Facility-based Work Order data
output.facilityBasedWocData = {
    location: {
        name: "CHENNAI",
        account: "Minuscule"
    },
    workflow: {
        name: "Mining Facility Maintenance Workflow"
    },
    priority: "URGENT",
    requestingDepartment: "Processing Plant",
    commentsForPending: "Others",
    userName: "Iyneshwar",
    
    // Random generation settings
    randomNumberLength: 10,
    randomTextLength: 10,
    equipmentTextLength: 3,
    equipmentNumberLength: 3
};

// Helper functions
output.helpers = {
    // Generate formatted date (MM/DD/YYYY)
    getFormattedDate: function() {
        const d = new Date();
        return String(d.getMonth() + 1).padStart(2, '0') + '/' + 
               String(d.getDate()).padStart(2, '0') + '/' + 
               d.getFullYear();
    },
    
    // Generate random text for equipment identifier
    generateEquipmentId: function() {
        // This will be handled by inputRandomText and inputRandomNumber in YAML
        return "equipment-id-placeholder";
    }
};

// Make data available globally
if (typeof module !== 'undefined' && module.exports) {
    module.exports = output;
} else {
    this.output = output;
}
