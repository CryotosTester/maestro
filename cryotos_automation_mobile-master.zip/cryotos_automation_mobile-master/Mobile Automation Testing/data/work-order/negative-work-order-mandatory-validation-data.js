// Data for Negative - Mandatory Field Validation (fill up to workflow)
if (typeof output === 'undefined') {
  output = {};
}

if (typeof output.mandatory === 'undefined') output.mandatory = {};

Object.assign(output.mandatory, {
  // Default workflow (aligned with description-whitespace data)
  assetName: "UPS System",
  workflowName: "Comprehensive Equipment Maintenance & Inspection",
  expectedErrorText: "This field cannot be empty."
  
});
