// E2E-02 Food Processing Line Emergency Breakdown Test Data
// Test data for food processing line emergency breakdown scenario

if (typeof output === "undefined") {
    output = {};
}

if (typeof output.e2e02Data === "undefined") output.e2e02Data = {};

Object.assign(output.e2e02Data, {
   
    // Asset Information
    asset: {
        name: "Food-Processing-Line-01",
        type: "Food Processing Equipment",
        location: "Perumal Nagar Minuscule Technologies",
        account: "Minuscule"
    },
   
    // Workflow Information
    workflow: {
        name: "Food Processing Line Emergency BD",
        priority: "CRITICAL"
    },
    description: ""
});

