// Parts Labour and Downtime Test Data
// Test data for parts, labour, and downtime capture in work order scenario

if (typeof output === "undefined") {
    output = {};
}

// Asset Information
output.assetName = "Fire Hosereel Pump-2 (Z1 HRP - 0029)";
output.assetFullName = "Fire Hosereel Pump-2 .*Z1 HRP - 0029.*",
output.accountName = "Minuscule";
output.locationName = "Perumal Nagar Minuscule Technologies";
// Workflow Information
output.workflowName = "Manufacturing Equipment Breakdown";
output.priorityLevel = "URGENT";
output.description = "";
