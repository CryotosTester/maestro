// E2E-04 Manufacturing Equipment Breakdown Test Data
// Test data for manufacturing equipment breakdown scenario

if (typeof output === "undefined") {
    output = {};
}

if (typeof output.e2e04Data === "undefined") output.e2e04Data = {};

Object.assign(output.e2e04Data, {
   
    // Asset Information
    asset: {
        name: "CNC-Machine-05",
        type: "Manufacturing Equipment",
        location: "Tower B",
        account: "Microsoft Building Campus"
    },
   
    // Workflow Information
    workflow: {
        name: "Manufacturing Equipment Breakdown",
        priority: "URGENT"
    },
    description: ""
});

