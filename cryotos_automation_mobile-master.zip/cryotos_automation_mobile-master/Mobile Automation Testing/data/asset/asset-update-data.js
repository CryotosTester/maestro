// Asset Update Test Data
// Test data for asset update scenario using mobile automation

if (typeof output === "undefined") {
    output = {};
}

// Asset Update Data Structure - MERGE with existing assetData object
if (typeof output.assetData === "undefined") output.assetData = {};

Object.assign(output.assetData, {

    customer: "Customer_Account_AUQWFXBRIH12051925",
    location: "Location_Customer_1AUQWFXBRIH12051925",
    serialNo: "Primary_Serial_No_AUQYRGLLIX12051930",
    assetName: "",
    machineCode: "",
    partNo: "",
    categories: [
        "Automation_Category_AUQHAOBIBT12051511",
        "Automation_Category_AUQZKBTYYH12051224",
        "Automation_Category_AUQIRQXJHC12051216",
        "Automation_Category_AUQGCVGYHI12051204"
    ],
    departments: [
        "Dept_AUQRKYRHQQ10311941",
        "Dept_AUQLNALUVF10311933",
        "Dept_AUQUAVFPIX10311706",
        "Dept_AUQSIVMVKU10311653"
    ],
    get category() {
        return this.categories[Math.floor(Math.random() * this.categories.length)];
    },
    get department() {
        return this.departments[Math.floor(Math.random() * this.departments.length)];
    }
});