if (typeof output === "undefined") {
    output = {};
}

// Account test data
if (typeof output.accountData === "undefined") output.accountData = {};

Object.assign(output.accountData, {

  // Account creation data
  accountCreation: {
    accountName: "",
    accountType: "",
    customerOption: "",
    email: "",
    phone: "",
    gstVatNo: "",
    registrationNumber: ""
  },

  // Location creation data
  locationCreation: {
    account: "",
    locationName: "",
    locationType: ["Plant", "Store Room", "Conference Room"],
    address: "",
    state: ["Tamil Nadu", "Kerala", "Andhra Pradesh"],
    parentLocation: "",
    tenant: ["Desk", "Facility", "None"]
  },

  // Random selection helpers
  get locationTypes() {
    return this.locationCreation.locationType[Math.floor(Math.random() * this.locationCreation.locationType.length)];
  },
  get states() {
    return this.locationCreation.state[Math.floor(Math.random() * this.locationCreation.state.length)];
  },
  get tenants() {
    return this.locationCreation.tenant[Math.floor(Math.random() * this.locationCreation.tenant.length)];
  }


});
