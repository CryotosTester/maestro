// Asset Downtime data definitions for CMMS Mobile App

if (typeof output === "undefined") { 
    output = {}; 
}

// Asset Downtime data - MERGE with existing assetdowntimedata object
if (typeof output.assetdowntimedata === "undefined") output.assetdowntimedata = {};

Object.assign(output.assetdowntimedata, {
    // Issue Type dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    issueTypes: {
        external_factors: "External Factors",
        equipment_age_wear: "Equipment Age or Wear",
        maintenance_issues: "Maintenance Issues",
        software_automation_issues: "Software or Automation Issues",
        supply_chain_issues: "Supply Chain Issues",
        environmental_factors: "Environmental Factors",
        human_error: "Human Error",
        process_related_issues: "Process-Related Issues",
        electrical_issues: "Electrical Issues",
        mechanical_issues: "Mechanical Issues",
        others: "Others"
    },
    
    // Root Cause dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    rootCauses: {
        others: "Others",
        bearing_failure: "Bearing Failure",
        gearbox_malfunction: "Gearbox Malfunction",
        motor_failure: "Motor Failure",
        pump_failure: "Pump Failure",
        lubrication_failure: "Lubrication Failure"
    },
    
    // Corrective Action dropdown options - CAPTURED FROM YOUR MOBILE DEVICE
    correctiveActions: {
        others: "Others",
        replaced_faulty_parts: "Replaced Faulty Parts",
        realigned_components: "Re-aligned Components",
        recalibrated_machine: "Re-calibrated Machine",
        repaired_wiring_connections: "Repaired Wiring or Connections",
        lubricated_equipment: "Lubricated Equipment",
        replaced_bearings: "Replaced Bearings",
        cleaned_inspected_components: "Cleaned and Inspected Components"
    },
    
    // Sample test data
    testData: {
        description: "Test asset downtime description",
        notes: "Test notes for downtime"
    }
    
});

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        assetdowntimedata: output.assetdowntimedata
    };
}

