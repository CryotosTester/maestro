class AuthAPI {
    constructor(baseURL = URL) {
        this.baseURL = baseURL;
        this.token = null;
    }
 
    async authenticate() {
        try {
            const response = await http.post(`${this.baseURL}/api/authenticate`, {
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    username: output.credentials.facilityManager.email,
                    password: output.credentials.facilityManager.password,
                    origin: "web"
                })
            });
 
            if (!response.ok) {
                console.log('Authentication failed:', response.status, response.body);
                throw new Error('Authentication failed');
            }
 
            console.log('Auth response body:', response.body);
            const data = json(response.body);
            this.token = data.token || data.id_token;
            console.log('Authentication successful');
            return this.token;
        } catch (error) {
            console.error('Authentication failed:', error.message);
            throw error;
        }
    }
 
    getAuthHeaders() {
        if (!this.token) {
            throw new Error('Not authenticated. Call authenticate() first.');
        }
        return {
            'Authorization': `Bearer ${this.token}`,
            'content-type': 'application/json'
        };
    }
}
 
class DailyScheduleJobAPI {
    constructor(baseURL = URL) {
        this.baseURL = baseURL;
        this.auth = new AuthAPI(baseURL);
    }
 
    async findNextDailyOccurrence(scheduleJobId) {
        try {
            // For now, return a mock next occurrence since the API endpoint might not exist
            // or might require different parameters
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
           
            const nextOccurrence = {
                scheduleJobId: scheduleJobId,
                nextDate: tomorrow.toISOString().split('T')[0],
                nextTime: '09:00:00',
                status: 'scheduled'
            };
           
            console.log('Next daily occurrence found (mock):', nextOccurrence);
            return nextOccurrence;
        } catch (error) {
            console.error(`Failed to find next daily occurrence for job ${scheduleJobId}:`, error.message);
            throw error;
        }
    }
 
    async updateReleaseDateToNow(scheduleJobId) {
        try {
            const now = new Date();
            const releaseDate = now.toISOString().split('T')[0]; // YYYY-MM-DD
            const releaseTime = now.toTimeString().split(' ')[0]; // HH:MM:SS
 
            console.log(`Updating job ${scheduleJobId} release date to ${releaseDate} and time to ${releaseTime}`);
 
            const token = await this.auth.authenticate();
            const headers = this.auth.getAuthHeaders();
           
            const response = await http.post(
                `${this.baseURL}/api/schedule-jobs/updateReleaseDateAndTime/${scheduleJobId}`,
                {
                    headers: headers,
                    body: JSON.stringify({
                        releaseDate: releaseDate,
                        releaseTime: releaseTime
                    })
                }
            );
 
            if (!response.ok) {
                console.log('Failed to update release date and time:', response.status, response.body);
                throw new Error('Failed to update release date and time');
            }
 
            console.log(`Successfully updated release date and time for job ID: ${scheduleJobId}`);
            return {
                success: true,
                releaseDate: releaseDate,
                releaseTime: releaseTime,
                response: response.body
            };
        } catch (error) {
            console.error(`Failed to update release date and time for job ${scheduleJobId}:`, error.message);
            throw error;
        }
    }
 
    async triggerScheduleRequest(scheduleJobId, delayMinutes = 1) {
        try {
            // Since the trigger endpoint doesn't exist, we'll simulate the trigger
            // by noting that the release date update should cause the schedule to be processed
            const triggerTime = new Date();
            triggerTime.setMinutes(triggerTime.getMinutes() + delayMinutes);
           
            console.log(`Schedule job ${scheduleJobId} will be processed automatically after release date update.`);
            console.log(`Expected processing time: ${triggerTime.toISOString()}`);
           
            return {
                success: true,
                triggerTime: triggerTime.toISOString(),
                message: 'Schedule will be processed automatically after release date update',
                simulated: true
            };
        } catch (error) {
            console.error(`Failed to trigger schedule request for job ${scheduleJobId}:`, error.message);
            throw error;
        }
    }

    async waitForRequestId(scheduleJobInstanceId, maxAttempts = 10, delaySeconds = 6) {
        try {
            console.log(`\n======= WAITING FOR REQUEST ID GENERATION =======`);
            console.log(`Schedule Job Instance ID: ${scheduleJobInstanceId}`);
            console.log(`Max attempts: ${maxAttempts}, Delay: ${delaySeconds} seconds`);
            
            const token = await this.auth.authenticate();
            const headers = this.auth.getAuthHeaders();
            
            for (let attempt = 1; attempt <= maxAttempts; attempt++) {
                console.log(`\n--- Attempt ${attempt}/${maxAttempts} ---`);
                
                try {
                    const response = await http.get(
                        `${this.baseURL}/api/schedule-job-instances/${scheduleJobInstanceId}`,
                        { headers: headers }
                    );
                    
                    if (!response.ok) {
                        console.log(`Attempt ${attempt} failed: HTTP ${response.status}`);
                        console.log('Response:', response.body);
                    } else {
                        const instanceData = json(response.body);
                        console.log('Instance status:', instanceData.status || 'unknown');
                        console.log('RequestId:', instanceData.requestId || 'null');
                        
                        // Check if requestId is populated
                        if (instanceData.requestId && instanceData.requestId !== null) {
                            console.log(`\n✓ SUCCESS! RequestId found: ${instanceData.requestId}`);
                            console.log(`Found after ${attempt} attempt(s)`);
                            return instanceData;
                        }
                        
                        console.log(`RequestId not yet generated. Waiting ${delaySeconds} seconds...`);
                    }
                } catch (error) {
                    console.log(`Attempt ${attempt} error:`, error.message);
                }
                
                // Wait before next attempt (except on last attempt)
                if (attempt < maxAttempts) {
                    // Simple delay by blocking
                    const startTime = Date.now();
                    while (Date.now() - startTime < delaySeconds * 1000) {
                        // Busy wait
                    }
                }
            }
            
            console.log(`\n✗ TIMEOUT: RequestId not generated after ${maxAttempts} attempts`);
            console.log(`Total wait time: ${maxAttempts * delaySeconds} seconds`);
            return null;
            
        } catch (error) {
            console.error('Error while waiting for requestId:', error.message);
            throw error;
        }
    }
 
    async executeDailyScheduleAutomation(scheduleJobId) {
        try {
            console.log(`Starting Daily Schedule Automation for job ID: ${scheduleJobId}`);
           
            // Step 1: Find the next Daily occurrence
            console.log('Step 1: Finding next Daily occurrence...');
            const nextOccurrence = await this.findNextDailyOccurrence(scheduleJobId);
           
            // Step 2: Update release date/time to now()
            console.log('Step 2: Updating release date/time to current time...');
            const updateResult = await this.updateReleaseDateToNow(scheduleJobId);
           
            // Step 3: Extract scheduleJobInstanceId from the response
            console.log('Step 3: Extracting scheduleJobInstanceId...');
            const responseText = updateResult.response;
            const instanceIdMatch = responseText.match(/"scheduleJobInstanceId"\s*:\s*(\d+)/);
            
            if (!instanceIdMatch) {
                throw new Error('Could not extract scheduleJobInstanceId from response');
            }
            
            const scheduleJobInstanceId = instanceIdMatch[1];
            console.log(`Extracted scheduleJobInstanceId: ${scheduleJobInstanceId}`);
            
            // Step 4: Trigger schedule request within ~1 minute
            console.log('Step 4: Triggering schedule request...');
            const triggerResult = await this.triggerScheduleRequest(scheduleJobId, 1);
            
            // Step 5: Wait for requestId to be generated (NEW STEP)
            console.log('Step 5: Waiting for requestId to be generated...');
            const instanceWithRequestId = await this.waitForRequestId(scheduleJobInstanceId, 10, 6);
            
            let requestId = null;
            if (instanceWithRequestId && instanceWithRequestId.requestId) {
                requestId = instanceWithRequestId.requestId;
                console.log(`✓ RequestId successfully retrieved: ${requestId}`);
            } else {
                console.log('⚠ WARNING: RequestId not found after waiting period');
                console.log('The schedule may need more time to execute or may have failed');
            }
           
            console.log('Daily Schedule Automation completed!');
           
            return {
                success: true,
                scheduleJobId: scheduleJobId,
                scheduleJobInstanceId: scheduleJobInstanceId,
                requestId: requestId,
                nextOccurrence: nextOccurrence,
                updateResult: updateResult,
                triggerResult: triggerResult,
                instanceDetails: instanceWithRequestId,
                timestamp: new Date().toISOString()
            };
           
        } catch (error) {
            console.error(`Daily Schedule Automation failed for job ${scheduleJobId}:`, error.message);
            throw error;
        }
    }
}
 
// Main automation function
async function main() {
    const dailyScheduleAPI = new DailyScheduleJobAPI();
   
    // Example: Execute automation for a known Daily schedule job
    const scheduleJobId = SCHEDULE_JOB_ID;
   
    try {
        const result = await dailyScheduleAPI.executeDailyScheduleAutomation(scheduleJobId);
        console.log('\n======= FINAL AUTOMATION RESULT =======');
        console.log(JSON.stringify(result, null, 2));
        
        // Export requestId for use in YAML flow
        if (result.requestId) {
            output.requestId = result.requestId;
            output.scheduleJobInstanceId = result.scheduleJobInstanceId;
            console.log(`\n✓ Exported requestId: ${output.requestId}`);
            console.log(`✓ Exported scheduleJobInstanceId: ${output.scheduleJobInstanceId}`);
        } else {
            console.log('\n⚠ WARNING: No requestId found to export!');
            console.log('The schedule may still be processing. Check later using scheduleJobInstanceId:', result.scheduleJobInstanceId);
            // Still export the instance ID so you can check manually
            output.scheduleJobInstanceId = result.scheduleJobInstanceId;
        }
    } catch (error) {
        console.error('Automation Error:', error.message);
    }
}
 
// Export for use as module
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DailyScheduleJobAPI, AuthAPI };
}
 
// Run the main function
main();