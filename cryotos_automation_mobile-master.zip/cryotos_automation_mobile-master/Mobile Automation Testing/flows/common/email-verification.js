// email-validation-complete.js

// ========================================
// CONFIGURATION
// ========================================
var emailSubject = EMAIL_SUBJECT;
var fieldNamesString =  EMAIL_FIELDS; // Only these fields will be extracted

// ========================================
// STEP 1: AUTHENTICATION
// ========================================

output.authToken = null;
output.authSuccess = false;
output.authError = '';

try {
  console.log('=== STEP 1: AUTHENTICATION ===');
  
  var tenantId = TENANT_ID;
  var clientId = CLIENT_ID;
  var clientSecret = SECRET_KEY;
  var tokenUrl = 'https://login.microsoftonline.com/' + tenantId + '/oauth2/v2.0/token';

  var authBody = 'grant_type=client_credentials' +
    '&scope=https://graph.microsoft.com/.default' +
    '&client_id=' + clientId +
    '&client_secret=' + clientSecret;

  var tokenResponse = http.post(tokenUrl, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: authBody,
  });

  if (!tokenResponse.ok) {
    console.log('❌ Authentication failed:', tokenResponse.status);
    output.authSuccess = false;
    output.authError = 'Authentication failed: ' + tokenResponse.status;
    throw new Error('Authentication failed');
  }

  var tokenData = JSON.parse(tokenResponse.body);
  output.authToken = tokenData.access_token;
  output.authSuccess = true;
  console.log('✅ Authentication successful\n');

} catch (error) {
  console.log('❌ Authentication error:', error.message);
  throw error;
}

// ========================================
// STEP 2: FETCH AND PARSE EMAIL
// ========================================

// Split field names from the provided string
var fieldNames = fieldNamesString.split('|');
for (var i = 0; i < fieldNames.length; i++) {
  fieldNames[i] = fieldNames[i].trim();
}

output.emailFound = false;
output.emailParsed = false;
output.parseError = '';
output.extractedValues = [];

try {
  console.log('=== STEP 2: FETCH AND PARSE EMAIL ===');
  console.log('Subject:', emailSubject);
  console.log('Fields to extract (' + fieldNames.length + '):', fieldNames.join(', '));
  console.log('Note: Only these fields will be extracted in this order\n');

  var accessToken = output.authToken;
  var userEmail =   USER;
  var maxAttempts = 6;
  var waitSeconds = 10;

  // Search for email
  var foundEmail = null;
  var lastError = '';

  console.log('--- SEARCHING FOR EMAIL ---');
  
  for (var attempt = 1; attempt <= maxAttempts; attempt++) {
    console.log('Search attempt', attempt, 'of', maxAttempts);
    
    var searchUrl = 'https://graph.microsoft.com/v1.0/users/' + userEmail + '/messages' +
      '?$filter=contains(subject,\'' + emailSubject + '\')&$top=5';
    
    var searchResponse = http.get(searchUrl, {
      headers: {
        Authorization: 'Bearer ' + accessToken,
        Accept: 'application/json',
        ConsistencyLevel: 'eventual'
      },
    });
    
    if (searchResponse.ok) {
      var searchData = JSON.parse(searchResponse.body);
      
      if (searchData.value && searchData.value.length > 0) {
        for (var i = 0; i < searchData.value.length; i++) {
          if (searchData.value[i].subject === emailSubject || 
              searchData.value[i].subject.indexOf(emailSubject) > -1) {
            foundEmail = searchData.value[i];
            console.log('✅ Email found!\n');
            break;
          }
        }
        if (foundEmail) break;
      }
    } else {
      lastError = searchResponse.status;
    }
    
    if (attempt < maxAttempts && !foundEmail) {
      console.log('Waiting', waitSeconds, 'seconds...\n');
      var start = Date.now();
      while (Date.now() - start < waitSeconds * 1000) {}
    }
  }

  if (!foundEmail) {
    output.emailFound = false;
    output.parseError = 'Email not found after ' + maxAttempts + ' attempts';
    console.log('❌ Email not found');
    throw new Error('Email not found');
  }

  output.emailFound = true;
  var emailId = foundEmail.id;
  console.log('Email ID:', emailId);

  // Fetch email body
  console.log('\n--- FETCHING EMAIL BODY ---');
  
  var fullEmailUrl = 'https://graph.microsoft.com/v1.0/users/' + userEmail + '/messages/' + emailId;

  var emailResponse = http.get(fullEmailUrl, {
    headers: {
      Authorization: 'Bearer ' + accessToken,
      Accept: 'application/json',
    },
  });

  if (!emailResponse.ok) {
    console.log('❌ Failed to fetch email body');
    throw new Error('Failed to fetch email body');
  }

  var fullEmail = JSON.parse(emailResponse.body);
  var emailBody = fullEmail.body.content;
  console.log('✅ Email body retrieved');

  // Clean email body
  var cleanBody = emailBody
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<\/li>/gi, '\n')
    .replace(/<\/div>/gi, '\n')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n');

  console.log('\n--- CLEANED EMAIL BODY ---');
  console.log(cleanBody);
  console.log('--- END ---');

  // Parse ONLY the specified fields in the given order
  console.log('\n--- PARSING SPECIFIED FIELDS ---');
  
  // Build regex pattern ONLY from the requested fieldNames
  var patternString = '(' + fieldNames.join('|') + ')';
  var nextFieldPattern = new RegExp(patternString, 'i');
  
  console.log('Field pattern:', patternString);
  console.log('');

  // Extract each field in the order specified
  for (var i = 0; i < fieldNames.length; i++) {
    var fieldName = fieldNames[i];
    var value = extractField(cleanBody, fieldName, nextFieldPattern);
    output.extractedValues[i] = value;
    console.log('✅ extractedValues[' + i + '] (' + fieldName + ') = ' + (value || '(empty)'));
  }

  console.log('\n--- FINAL ARRAY ---');
  console.log(JSON.stringify(output.extractedValues, null, 2));
  console.log('\n✅ Extraction complete: ' + fieldNames.length + ' fields processed');
  output.emailParsed = true;

} catch (error) {
  console.log('❌ Error:', error.message);
  output.emailParsed = false;
  if (!output.parseError) {
    output.parseError = error.message;
  }
  throw error;
}

// ========================================
// HELPER FUNCTION
// ========================================

function extractField(emailBody, fieldName, nextFieldPattern) {
  var escapedFieldName = fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  var patterns = [
    new RegExp(escapedFieldName + ':\\s*([^\\n]*)', 'i'),
    new RegExp(escapedFieldName + ':\\s*\\n\\s*([^\\n]*)', 'i'),
    new RegExp(escapedFieldName + '[^:]*:\\s*([^\\n]*)', 'i')
  ];
  
  for (var i = 0; i < patterns.length; i++) {
    var match = emailBody.match(patterns[i]);
    if (match) {
      var value = match[1].trim();
      value = value.replace(/^[^:]*:/, '').trim();
      
      if (value === '-' || value === '' || value === 'null' || value.toLowerCase() === 'null') {
        return null;
      }
      
      var nextFieldMatch = value.match(nextFieldPattern);
      if (nextFieldMatch && nextFieldMatch.index > 0) {
        value = value.substring(0, nextFieldMatch.index).trim();
      }
      
      return value;
    }
  }
  
  return null;
}