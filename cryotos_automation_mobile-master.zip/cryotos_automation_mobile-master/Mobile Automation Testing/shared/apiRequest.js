// Maestro JavaScript file for making HTTP request to Playwright endpoint
// This file will be called from login-with-api.yaml

// Generate 32-character UUID without hyphens
function generateUUID() {
  return 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'.replace(/[x]/g, function(c) {
    const r = Math.random() * 16 | 0;
    return r.toString(16);
  });
}

// Generate short unique ID (4 characters)
function generateShortID() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 4; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Generate unique description with UUID only
function generateUniqueDescription() {
  return generateUUID();
}

try {
  // Generate description once and reuse it
  const workOrderDescription = generateUniqueDescription();
  
  // Make HTTP POST request to Playwright endpoint
  const response = http.post('http://localhost:3000/api/create-workorder', {
    headers: { 
      'Content-Type': 'application/json' 
    },
    body: JSON.stringify({
      loginUrl: 'https://app.cryotos.com/#/login/',
      username: 'e218@minusculetechnologies.com',
      password: 'Naren@1506',
      asset: 'CCTV Cameras (6)',
      workflow: 'Breakdown - Basic',
      description: workOrderDescription,
      account: 'Lucas TVS',
      location: 'Pallavaram'
    })
  });

  // Parse the JSON response
  const jsonResponse = JSON.parse(response.body);
  
  // Initialize output.script if it doesn't exist
  if (typeof output === 'undefined') {
    output = {};
  }
  if (typeof output.script === 'undefined') {
    output.script = {};
  }
  
  // Store the result for evaluation in Maestro
  output.script.result = {
    success: jsonResponse.success,
    message: jsonResponse.message,
    error: jsonResponse.error,
    statusCode: response.statusCode,
    responseBody: jsonResponse,
    generatedDescription: workOrderDescription
  };
  
  // Log the response for debugging
  console.log('API Response:', JSON.stringify(output.script.result, null, 2));
  
} catch (error) {
  // Initialize output.script if it doesn't exist
  if (typeof output === 'undefined') {
    output = {};
  }
  if (typeof output.script === 'undefined') {
    output.script = {};
  }
  
  // Handle any errors
  output.script.result = {
    success: false,
    error: error.message,
    statusCode: 0,
    responseBody: null
  };
  
  console.log('API Error:', error.message);
}
