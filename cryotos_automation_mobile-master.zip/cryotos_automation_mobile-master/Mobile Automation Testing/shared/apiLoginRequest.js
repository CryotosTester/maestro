// Maestro JavaScript file for making HTTP request to Playwright login endpoint
// This file will be called from Maestro flows for login testing

// Load API request data
const apiData = require('../data/api/apiRequestData.js');

try {
  // Make HTTP POST request to Playwright login endpoint
  const response = http.post(apiData.getUrl('login'), {
    headers: apiData.headers,
    body: JSON.stringify(apiData.getLoginPayload())
  });

  // Parse the JSON response
  const jsonResponse = JSON.parse(response.body);
  
  // Initialize output.script if it doesn't exist
  if (typeof output === 'undefined') {
    output = {};
  }
  if (typeof output.script === 'undefined') {
    output.script = {};
  }
  
  // Store the result for evaluation in Maestro
  output.script.result = {
    success: jsonResponse.success,
    message: jsonResponse.message,
    error: jsonResponse.error,
    statusCode: response.statusCode,
    responseBody: jsonResponse
  };
  
  // Log the response for debugging
  console.log('Login API Response:', JSON.stringify(output.script.result, null, 2));
  
} catch (error) {
  // Initialize output.script if it doesn't exist
  if (typeof output === 'undefined') {
    output = {};
  }
  if (typeof output.script === 'undefined') {
    output.script = {};
  }
  
  // Handle any errors
  output.script.result = {
    success: false,
    error: error.message,
    statusCode: 0,
    responseBody: null
  };
  
  console.log('Login API Error:', error.message);
}
