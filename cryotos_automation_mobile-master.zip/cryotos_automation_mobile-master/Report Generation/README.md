# Test Reports

All report scripts and outputs are stored here.

## Scripts
- generate_test_suite_report.py
- generate_html_report.py

## Usage
From project root:
```bash
py .report/generate_test_suite_report.py .maestro/<run_folder>
py .report/generate_html_report.py .maestro/<run_folder>/commands-(Flow).json
```
