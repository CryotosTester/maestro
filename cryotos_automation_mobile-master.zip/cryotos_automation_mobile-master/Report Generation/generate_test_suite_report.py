#!/usr/bin/env python3
"""
Generate consolidated HTML test suite report from multiple Maestro JSON files
Processes all commands-*.json files in a directory and creates a unified report
"""
import json
import sys
from datetime import datetime
from pathlib import Path
import importlib.util

# Import functions from generate_html_report.py without modifying it
def load_functions_from_module(module_path):
    """Dynamically load functions from generate_html_report.py"""
    spec = importlib.util.spec_from_file_location("generate_html_report", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def process_single_json(json_file_path):
    """Process a single JSON file and return its analysis data"""
    try:
        # Load the existing module functions
        script_dir = Path(__file__).parent
        html_report_module = load_functions_from_module(script_dir / "generate_html_report.py")
        
        # Read JSON
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Extract flow name
        flow_name = Path(json_file_path).stem.replace('commands-', '').replace('(', '').replace(')', '').replace('.yaml', '')
        
        # Analyze data
        total_commands = len(data)
        passed = 0
        failed = 0
        total_duration = 0
        failed_commands = []
        command_breakdown = {}
        timestamps = []
        
        for idx, entry in enumerate(data):
            metadata = entry.get("metadata", {})
            status = metadata.get("status", "UNKNOWN")
            duration = metadata.get("duration", 0)
            timestamp = metadata.get("timestamp")
            
            total_duration += duration
            if timestamp:
                timestamps.append(timestamp)
            
            command_info = html_report_module.extract_command_info(entry.get("command", {}))
            cmd_type = command_info["type"]
            
            # Count command types
            command_breakdown[cmd_type] = command_breakdown.get(cmd_type, 0) + 1
            
            if status == "COMPLETED":
                passed += 1
            elif status == "FAILED":
                failed += 1
                error = metadata.get("error", {})
                element_info = html_report_module.extract_element_from_error(error)
                
                failed_cmd = {
                    "index": idx + 1,
                    "type": cmd_type,
                    "description": command_info["description"],
                    "details": command_info["details"],
                    "error": {
                        "message": error.get("message", "Unknown error"),
                        "duration": f"{(duration / 1000):.2f}s",
                        "timestamp": datetime.fromtimestamp(timestamp / 1000).isoformat() if timestamp else None
                    },
                    "elementInfo": element_info
                }
                failed_commands.append(failed_cmd)
        
        # Calculate execution time
        execution_time = None
        if timestamps:
            start_time = min(timestamps)
            end_time = max(timestamps)
            elapsed = (end_time - start_time) / 1000
            execution_time = {
                "start": datetime.fromtimestamp(start_time / 1000).isoformat(),
                "end": datetime.fromtimestamp(end_time / 1000).isoformat(),
                "elapsed": f"{elapsed:.2f}s"
            }
        
        pass_rate = (passed / total_commands * 100) if total_commands > 0 else 0
        overall_status = "PASSED" if failed == 0 else "FAILED"
        
        # Get file creation time
        file_stat = Path(json_file_path).stat()
        created_time = datetime.fromtimestamp(file_stat.st_ctime)
        
        return {
            "flow_name": flow_name,
            "file_path": json_file_path,
            "file_name": Path(json_file_path).name,
            "created_time": created_time,
            "total_commands": total_commands,
            "passed": passed,
            "failed": failed,
            "pass_rate": pass_rate,
            "overall_status": overall_status,
            "total_duration": total_duration,
            "execution_time": execution_time,
            "failed_commands": failed_commands,
            "command_breakdown": command_breakdown
        }
    except Exception as e:
        return {
            "flow_name": Path(json_file_path).stem,
            "file_path": json_file_path,
            "file_name": Path(json_file_path).name,
            "error": str(e),
            "overall_status": "ERROR"
        }

def generate_test_suite_report(directory_path, output_file_path=None, suite_name: str | None = None):
    """Generate consolidated HTML report from all JSON files in a directory"""
    
    dir_path = Path(directory_path)
    if not dir_path.exists():
        raise FileNotFoundError(f"Directory not found: {directory_path}")
    
    if not dir_path.is_dir():
        raise ValueError(f"Path is not a directory: {directory_path}")
    
    # Find all commands-*.json files
    json_files = sorted(dir_path.glob("commands-*.json"), key=lambda p: p.stat().st_ctime)
    
    if not json_files:
        raise ValueError(f"No commands-*.json files found in: {directory_path}")
    
    print(f"Found {len(json_files)} test case(s) to process")
    
    # Process each JSON file
    test_results = []
    overall_stats = {
        "total_files": 0,  # Total test cases
        "passed_files": 0,  # Passed test cases
        "failed_files": 0,  # Failed test cases
        "total_commands": 0,
        "total_passed": 0,
        "total_failed": 0,
        "total_duration": 0,
        "all_failed_commands": [],
        "suite_start_time": None,
        "suite_end_time": None
    }
    
    for json_file in json_files:
        print(f"Processing test case: {Path(json_file).stem.replace('commands-', '').replace('(', '').replace(')', '').replace('.yaml', '')}")
        result = process_single_json(json_file)
        test_results.append(result)
        
        if "error" not in result:
            overall_stats["total_files"] += 1
            if result["overall_status"] == "PASSED":
                overall_stats["passed_files"] += 1
            else:
                overall_stats["failed_files"] += 1
            
            overall_stats["total_commands"] += result["total_commands"]
            overall_stats["total_passed"] += result["passed"]
            overall_stats["total_failed"] += result["failed"]
            overall_stats["total_duration"] += result["total_duration"]
            overall_stats["all_failed_commands"].extend(result["failed_commands"])
            
            # Track suite execution time
            if result["execution_time"]:
                start = datetime.fromisoformat(result["execution_time"]["start"])
                end = datetime.fromisoformat(result["execution_time"]["end"])
                if overall_stats["suite_start_time"] is None or start < overall_stats["suite_start_time"]:
                    overall_stats["suite_start_time"] = start
                if overall_stats["suite_end_time"] is None or end > overall_stats["suite_end_time"]:
                    overall_stats["suite_end_time"] = end
    
    # Calculate suite-wide metrics
    suite_elapsed = None
    if overall_stats["suite_start_time"] and overall_stats["suite_end_time"]:
        elapsed_seconds = (overall_stats["suite_end_time"] - overall_stats["suite_start_time"]).total_seconds()
        suite_elapsed = f"{elapsed_seconds:.2f}s"
    
    overall_pass_rate = (overall_stats["total_passed"] / overall_stats["total_commands"] * 100) if overall_stats["total_commands"] > 0 else 0
    suite_pass_rate = (overall_stats["passed_files"] / overall_stats["total_files"] * 100) if overall_stats["total_files"] > 0 else 0
    suite_status = "PASSED" if overall_stats["failed_files"] == 0 else "FAILED"
    
    # Update terminology: files -> test cases
    total_test_cases = overall_stats["total_files"]
    passed_test_cases = overall_stats["passed_files"]
    failed_test_cases = overall_stats["failed_files"]
    
    # Generate HTML
    display_suite_name = suite_name if suite_name else dir_path.name
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Suite Report - {dir_path.name}</title>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Source Sans Pro', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f5f5f5;
            color: #2c3e50;
            line-height: 1.6;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        
        .header {{
            background: #2c3e50;
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 20px;
        }}
        
        .header-image {{
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            object-fit: cover;
            flex-shrink: 0;
        }}
        
        .header-content {{
            flex: 1;
        }}
        
        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        .header .suite-name {{
            font-size: 1.2em;
            opacity: 0.9;
        }}
        
        .status-badge {{
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            margin-top: 10px;
            font-size: 0.9em;
        }}
        
        .status-passed {{
            background: #2ecc71;
            color: white;
        }}
        
        .status-failed {{
            background: #e74c3c;
            color: white;
        }}
        
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .metric-card {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.2s;
            border: 1px solid #e0e0e0;
        }}
        
        .metric-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
            border-color: #3498db;
        }}
        
        .metric-value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #3498db;
            margin: 10px 0;
        }}
        
        .metric-label {{
            color: #7f8c8d;
            font-size: 0.9em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .metric-value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
            margin: 10px 0;
        }}
        
        .metric-label {{
            color: #7f8c8d;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .section {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
        }}
        
        .section h2 {{
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #3498db;
        }}
        
        .test-file-section {{
            background: #f8f9fa;
            border-left: 5px solid #3498db;
            padding: 25px;
            margin: 20px 0;
            border-radius: 5px;
        }}
        
        .test-file-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }}
        
        .test-file-header h3 {{
            color: #2c3e50;
            font-size: 1.5em;
            margin: 0;
        }}
        
        .test-file-stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }}
        
        .test-stat {{
            background: white;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            border: 1px solid #e0e0e0;
        }}
        
        .test-stat-value {{
            font-size: 1.8em;
            font-weight: bold;
            color: #3498db;
        }}
        
        .test-stat-label {{
            color: #7f8c8d;
            font-size: 0.85em;
            margin-top: 5px;
        }}
        
        .failed-command {{
            background: #fee;
            border-left: 5px solid #e74c3c;
            padding: 20px;
            margin: 15px 0;
            border-radius: 5px;
        }}
        
        .failed-command h4 {{
            color: #e74c3c;
            margin-bottom: 10px;
        }}
        
        .failed-command .error-details {{
            background: white;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            color: #2c3e50;
        }}
        
        .timestamp {{
            color: #7f8c8d;
            font-size: 0.9em;
            margin-top: 10px;
        }}
        
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }}
        
        .info-item {{
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
            color: #2c3e50;
        }}
        
        .info-item strong {{
            color: #3498db;
        }}
        
        .breakdown-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }}
        
        .breakdown-table th {{
            background: #34495e;
            color: white;
            padding: 12px;
            text-align: left;
        }}
        
        .breakdown-table td {{
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            color: #2c3e50;
        }}
        
        .breakdown-table tr:hover {{
            background: #f8f9fa;
        }}
        
        .file-error {{
            background: #fee;
            border-left: 5px solid #e74c3c;
            padding: 20px;
            margin: 15px 0;
            border-radius: 5px;
            color: #e74c3c;
        }}
        
        .separator {{
            height: 2px;
            background: linear-gradient(90deg, transparent, #667eea, transparent);
            margin: 40px 0;
        }}
        
        .test-case-container {{
            margin-bottom: 16px;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
            background: white;
        }}
        .test-case-container:last-child {{
            margin-bottom: 0;
        }}
        
        .test-case-header {{
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border: 0;
            margin-bottom: 0;
            transition: background-color 0.2s;
            border-bottom: 1px solid #e0e0e0; /* separate header from details */
        }}

        /* Inner section spacing to avoid large gaps */
        .test-file-section {{
            box-shadow: none;
            border-radius: 0;
            border-top: 0; /* avoid double separators between cards */
            margin: 0;
        }}
        
        .test-case-header:hover {{
            background: #f8f9fa;
        }}
        
        .test-case-header-content {{
            display: flex;
            align-items: center;
            gap: 15px;
        }}
        
        .expand-icon {{
            font-size: 1.2em;
            transition: transform 0.3s;
            color: #3498db;
        }}
        
        .expand-icon.expanded {{
            transform: rotate(90deg);
        }}
        
        .test-case-details {{
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }}
        
        .test-case-details.expanded {{
            max-height: 5000px;
        }}
    </style>
    <script>
        function toggleTestCase(element) {{
            const container = element.closest('.test-case-container');
            const details = container.querySelector('.test-case-details');
            const icon = container.querySelector('.expand-icon');
            
            details.classList.toggle('expanded');
            icon.classList.toggle('expanded');
        }}
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-content">
                <h1>🧪 Maestro Test Suite Report</h1>
                <div class="suite-name">Suite: {display_suite_name}</div>
                <span class="status-badge status-{'passed' if suite_status == 'PASSED' else 'failed'}">
                    {suite_status}
                </span>
                <div class="timestamp">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
            </div>
        </div>
        
        <div class="summary-grid">
            <div class="metric-card">
                <div class="metric-label">Total Test Cases</div>
                <div class="metric-value">{total_test_cases}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">✅ Passed Test Cases</div>
                <div class="metric-value" style="color: #2ecc71;">{passed_test_cases}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">❌ Failed Test Cases</div>
                <div class="metric-value" style="color: #e74c3c;">{failed_test_cases}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Suite Pass Rate</div>
                <div class="metric-value" style="font-size: 2em;">{suite_pass_rate:.2f}%</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Suite Duration</div>
                <div class="metric-value" style="font-size: 1.8em;">{(overall_stats["total_duration"]/1000):.2f}s</div>
            </div>
        </div>
"""
    
    # Add suite execution timeline
    if overall_stats["suite_start_time"] and overall_stats["suite_end_time"]:
        html += f"""
        <div class="section">
            <h2>⏱️ Suite Execution Timeline</h2>
            <div class="info-grid">
                <div class="info-item">
                    <strong>Suite Start Time:</strong><br>
                    {overall_stats["suite_start_time"].isoformat()}
                </div>
                <div class="info-item">
                    <strong>Suite End Time:</strong><br>
                    {overall_stats["suite_end_time"].isoformat()}
                </div>
            </div>
        </div>
"""
    
    # Add individual test case results
    html += """
        <div class="section">
            <h2>📋 Individual Test Case Results</h2>
"""
    
    # Sort by creation time
    test_results_sorted = sorted([r for r in test_results if "error" not in r], 
                                  key=lambda x: x["created_time"])
    error_results = [r for r in test_results if "error" in r]
    
    for idx, result in enumerate(test_results_sorted):
        html += f"""
        <div class="test-case-container">
            <div class="test-case-header" onclick="toggleTestCase(this)">
                <div class="test-case-header-content">
                    <span class="expand-icon">▶</span>
                    <h3 style="margin: 0;">{result["flow_name"]}</h3>
                </div>
                <span class="status-badge status-{'passed' if result["overall_status"] == 'PASSED' else 'failed'}">
                    {result["overall_status"]}
                </span>
            </div>
            
            <div class="test-case-details">
                <div class="test-file-section">
                    <div class="test-file-header">
                        <h3>{result["flow_name"]}</h3>
                    </div>
                    
                    <div class="info-item" style="margin-bottom: 15px;">
                        <strong>Test Case:</strong> {result["flow_name"]}<br>
                        <strong>Run Time:</strong> {result["created_time"].strftime('%Y-%m-%d %H:%M:%S')}
                    </div>
                    
                    <div class="test-file-stats">
                <div class="test-stat">
                    <div class="test-stat-value">{result["pass_rate"]:.2f}%</div>
                    <div class="test-stat-label">Pass Rate</div>
                </div>
                <div class="test-stat">
                    <div class="test-stat-value">{(result["total_duration"]/1000):.2f}s</div>
                    <div class="test-stat-label">Duration</div>
                </div>
"""
        
        if result.get("execution_time"):
            html += f"""
                <div class="test-stat">
                    <div class="test-stat-value">{result["execution_time"]["elapsed"]}</div>
                    <div class="test-stat-label">Run Time</div>
                </div>
"""
        
        html += """
            </div>
"""
        
        # Add failed commands for this test file
        if result["failed_commands"]:
            html += f"""
            <div style="margin-top: 20px;">
                <h4 style="color: #e74c3c; margin-bottom: 15px;">❌ Failed Commands ({len(result["failed_commands"])})</h4>
"""
            for cmd in result["failed_commands"][:5]:  # Show first 5 failed commands
                html += f"""
                <div class="failed-command">
                    <h4>Command #{cmd['index']}: {cmd['type']}</h4>
                    <div class="error-details">
                        <strong>Error:</strong> {cmd['error']['message']}<br>
                        <strong>Duration:</strong> {cmd['error']['duration']}
                    </div>
                </div>
"""
            if len(result["failed_commands"]) > 5:
                html += f"""
                <div style="margin-top: 10px; color: #7f8c8d;">
                    ... and {len(result["failed_commands"]) - 5} more failed commands
                </div>
"""
            html += """
            </div>
"""
        
        html += """
                    </div>
                </div>
            </div>
"""
    
    # Add error results if any
    for result in error_results:
        html += f"""
        <div class="file-error">
            <h3>Error Processing Test Case: {result["flow_name"]}</h3>
            <p><strong>Error:</strong> {result["error"]}</p>
        </div>
"""
    
    html += """
        </div>
    </div>
</body>
</html>
"""
    
    # Write HTML file
    if not output_file_path:
        # If suite_name is provided, place the file under requested report_html folder
        if suite_name:
            base_dir = Path(r"C:\Users\Developers\Documents\Project\.report\report_html")
            base_dir.mkdir(parents=True, exist_ok=True)
            safe_name = "".join(c for c in suite_name if c not in "\\/:*?\"<>|").strip()
            output_file_path = base_dir / f"{safe_name}.html"
        else:
            base_dir = Path('.report')
            base_dir.mkdir(parents=True, exist_ok=True)
            output_file_path = base_dir / f"{dir_path.name}_test_suite_report.html"
    else:
        output_file_path = Path(output_file_path)
    
    # Ensure output directory exists
    output_file_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output_file_path, 'w', encoding='utf-8') as f:
        f.write(html)
    
    return str(output_file_path)

if __name__ == "__main__":
    import argparse
    
    # Set UTF-8 encoding
    if sys.stdout.encoding != 'utf-8':
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except:
            pass
    
    parser = argparse.ArgumentParser(
        description='Generate consolidated HTML test suite report from multiple Maestro JSON files',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process all JSON files in a directory
  python generate_test_suite_report.py .maestro/2025-10-29_165941
  
  # Specify custom output file
  python generate_test_suite_report.py .maestro/2025-10-29_165941 -o reports/suite_report.html
        """
    )
    
    parser.add_argument(
        'directory',
        type=str,
        help='Path to directory containing commands-*.json files'
    )
    
    parser.add_argument(
        '-o', '--output',
        type=str,
        default=None,
        help='Output HTML file path (default: <directory>_test_suite_report.html in the same directory)'
    )
    parser.add_argument(
        '-n', '--suite-name',
        type=str,
        default=None,
        help='Optional suite name to display in report header and to name the output file (stored under .report/report_html)'
    )
    
    args = parser.parse_args()
    
    try:
        print(f"Processing directory: {args.directory}")
        if args.output:
            print(f"Output will be: {args.output}")
        
        generated_path = generate_test_suite_report(args.directory, args.output, args.suite_name)
        
        print(f"\n✅ Success! Test suite report generated:")
        print(f"   {Path(generated_path).absolute()}")
        print(f"\nOpen in browser to view the consolidated report.")
        
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)

