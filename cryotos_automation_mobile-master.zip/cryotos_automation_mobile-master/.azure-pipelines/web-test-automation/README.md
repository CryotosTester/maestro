# Azure Pipeline - Web Application Automation Testing

This document describes the Azure DevOps pipeline configuration for automated web application testing with Allure reporting.

## 📋 Overview

This pipeline is designed for **orchestration only** - the code remains in GitHub and executes on a self-hosted EC2 agent with comprehensive Allure reporting capabilities.

## 🚀 Pipeline Configuration

### Trigger Settings
- **Manual Trigger**: `trigger: none` - Pipeline runs only when manually triggered or scheduled
- **Scheduled Execution**: Daily at 6:00 PM UTC (11:30 AM IST)
- **Target Branch**: `main`

### Variables
| Variable | Description | Example Value |
|----------|-------------|---------------|
| `GITHUB_REPO` | GitHub repository URL with PAT | `https://$(GITHUB_PAT)@github.com/$(USERNAME)/cryotos_automation.git` |
| `GITHUB_BRANCH` | Target branch for testing | `master` |
| `TEST_ENV` | Test environment | `$(TESTENV)` |
| `HEADLESS` | Browser headless mode | `true` |

### Agent Pool
- **Pool Name**: `Default`
- **Type**: Self-hosted EC2 agent

## 🔧 Pipeline Stages

### 1. Clone from GitHub
```yaml
- script: |
    echo "Cloning from GitHub..."
    git clone --depth 1 -b $(GITHUB_BRANCH) $(GITHUB_REPO) workspace
    echo "Clone complete"
```
- **Purpose**: Shallow clone of the repository to workspace directory
- **Authentication**: Uses GitHub Personal Access Token (PAT)
- **Depth**: Limited to 1 commit for faster cloning

### 2. Install Allure 2.35.1
```yaml
- script: |
    # Check if Allure is already installed, install if not
    if command -v allure &> /dev/null; then
        echo "✅ Allure is already installed"
    else
        # Installation process...
    fi
```
- **Purpose**: Ensures Allure reporting tool is available
- **Version**: 2.35.1 (specific version for consistency)
- **Dependencies**: Installs Java 17 if not present
- **Installation Method**: Downloads from GitHub releases and sets up via update-alternatives

### 3. Run Tests and Generate Allure Report
```yaml
- task: Maven@4
  inputs:
    mavenPomFile: 'workspace/pom.xml'
    goals: 'clean test allure:report'
    options: '-Denv=$(TEST_ENV) -Dheadless=$(HEADLESS) -Dtest=TestSuiteOrder'
```
- **Build Tool**: Maven
- **Goals**: `clean test allure:report`
- **Test Suite**: `TestSuiteOrder`
- **Results Directory**: `allure-results`
- **JUnit Results**: Published automatically

### 4. Verify Results and Generate Single-File Report
```yaml
- script: |
    # Verify Allure Results
    ls -la allure-results/
    find allure-results/ -name "*.json" | wc -l
    
    # Generate Single-File Report
    allure generate --clean --single-file -o allure-single-report allure-results
```
- **Purpose**: Validates test execution and creates portable report
- **Output**: Single HTML file for easy sharing
- **Condition**: Always runs regardless of test results

### 5. Publish Test Results
```yaml
- task: PublishTestResults@2
  inputs:
    testResultsFormat: 'JUnit'
    testResultsFiles: 'workspace/target/surefire-reports/TEST-*.xml'
```
- **Format**: JUnit XML
- **Integration**: Azure DevOps test results dashboard
- **Merge**: Combines multiple test result files

### 6. Publish Allure Report Artifact
```yaml
- task: PublishBuildArtifacts@1
  inputs:
    pathToPublish: 'workspace/allure-single-report'
    artifactName: 'allure-single-report-$(Build.BuildId)'
```
- **Artifact Name**: Includes unique Build ID
- **Content**: Single-file Allure report
- **Accessibility**: Available for download from Azure DevOps

### 7. Send Report via Email
```yaml
- script: |
    mvn exec:java -Dexec.mainClass="com.piqotech.automation.utils.AllureReportSender"
```
- **Method**: Maven exec plugin with custom Java class
- **Security**: Uses Azure DevOps secure variables
- **Error Handling**: Continues pipeline even if email fails

### 8. Cleanup
```yaml
- script: |
    cd ..
    rm -rf workspace
```
- **Purpose**: Removes cloned workspace to save disk space
- **Condition**: Always runs

## 🔐 Required Variables

Configure these variables in Azure DevOps:

### Repository Access
- `GITHUB_PAT` - GitHub Personal Access Token
- `USERNAME` - GitHub username

### Environment Configuration
- `TESTENV` - Target test environment (staging/production)

### Email Configuration
- `EMAIL_SMTP_USERNAME` - SMTP server username
- `EMAIL_SMTP_PASSWORD` - SMTP server password (secure variable)
- `EMAIL_RECIPIENTS` - Comma-separated email addresses

## 📊 Reporting Features

### Allure Report Benefits
- **Rich Visualizations**: Test execution trends, failure analysis
- **Detailed Test Steps**: Step-by-step execution with screenshots
- **Historical Data**: Trend analysis across builds
- **Single File Export**: Portable HTML report for sharing

### Report Distribution
1. **Azure DevOps Artifacts**: Download from build artifacts
2. **Email Delivery**: Automatic email with report attachment
3. **Test Results Dashboard**: Integrated Azure DevOps view

## 🛠️ Prerequisites

### Self-Hosted Agent Requirements
- **Operating System**: Linux (Amazon Linux/Ubuntu)
- **Java**: Version 17 or higher
- **Maven**: For build and test execution
- **Git**: For repository cloning
- **Network Access**: GitHub and email SMTP server

### Repository Structure
```
workspace/
├── pom.xml                    # Maven configuration
├── src/test/                  # Test source code
├── allure-results/           # Generated test results
└── target/surefire-reports/  # JUnit XML reports
```

## 🔄 Execution Flow

```mermaid
graph TD
    A[Scheduled Trigger] --> B[Clone Repository]
    B --> C[Install Allure]
    C --> D[Run Maven Tests]
    D --> E[Generate Allure Report]
    E --> F[Publish Test Results]
    F --> G[Publish Artifacts]
    G --> H[Send Email Report]
    H --> I[Cleanup Workspace]
```

## 📈 Monitoring and Troubleshooting

### Common Issues
1. **Clone Failures**: Check GitHub PAT permissions
2. **Test Failures**: Review test logs in Azure DevOps
3. **Email Issues**: Verify SMTP credentials and recipients
4. **Allure Installation**: Check Java installation and network access

### Log Locations
- **Build Logs**: Azure DevOps pipeline execution logs
- **Test Results**: Published test results dashboard
- **Allure Report**: Downloaded artifacts or email attachment

## 🚀 Usage Instructions

### Manual Execution
1. Navigate to Azure DevOps pipeline
2. Click "Run pipeline"
3. Select branch and environment variables
4. Monitor execution in real-time

### Scheduled Execution
- Runs automatically daily at 6:00 PM UTC
- No manual intervention required
- Results delivered via email and Azure DevOps

### Accessing Results
1. **Azure DevOps**: View test results in pipeline summary
2. **Artifacts**: Download Allure report from build artifacts
3. **Email**: Check inbox for automated report delivery

## 🔧 Customization Options

### Modify Schedule
```yaml
schedules:
- cron: "30 14 * * *"  # Change time as needed
  displayName: Custom Test Execution
```

### Add Test Parameters
```yaml
options: '-Denv=$(TEST_ENV) -Dheadless=$(HEADLESS) -DcustomParam=value'
```

### Multiple Test Suites
```yaml
options: '-Dtest=TestSuite1,TestSuite2,TestSuite3'
```

This pipeline provides a robust, automated testing solution with comprehensive reporting and notification capabilities.
