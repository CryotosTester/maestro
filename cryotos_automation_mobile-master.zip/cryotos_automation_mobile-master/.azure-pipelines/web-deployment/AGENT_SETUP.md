## Self-hosted Azure Pipelines Agent — STAGING EC2

This guide installs and registers a self-hosted Azure Pipelines agent on the STAGING EC2 instance so the pipeline can execute `script/cdupgrade.sh` locally without SSH.

### Prerequisites
- Azure DevOps organization and project
- Agent Pool created (e.g., `cryotos-staging`)
- EC2 instance (Amazon Linux 2 or similar) with outbound internet access
- Logged in as `ec2-user` with sudo

### 1) Create/choose Agent Pool
In Azure DevOps → Project Settings → Agent Pools → New pool → name: `cryotos-staging`.

### 2) Download and configure the agent
On the EC2 instance:

```bash
mkdir -p ~/azp && cd ~/azp
curl -fsSL https://vstsagentpackage.azureedge.net/agent/3.246.0/vsts-agent-linux-x64-3.246.0.tar.gz -o agent.tar.gz
tar zxvf agent.tar.gz
```

Run `./config.sh` and answer prompts (Organization URL, PAT, pool name, agent name):

```bash
./config.sh
# Organization URL: https://dev.azure.com/<org>
# Authentication: PAT (Personal Access Token with Agent Pools (read, manage))
# Agent Pool: cryotos-staging
# Agent Name: cryotos-ec2-agent (or any)
# Work folder: _work (default)
```

### 3) Run as a service

```bash
sudo ./svc.sh install ec2-user
sudo ./svc.sh start
sudo ./svc.sh status
```

The agent should appear online in Azure DevOps → Agent Pools → `cryotos-staging`.

### 4) Recommended directory layout

Place the Cryotos repo under the agent work directory or in `/home/ec2-user/cryotos-cd`. The pipeline checks out the repo automatically; the deployment script path should be `script/cdupgrade.sh` at repo root.

### 5) Security notes
- The agent runs jobs with the `ec2-user` permissions by default.
- Restrict who can queue pipelines and approve the `cryotos-staging` environment.
- Keep the PAT scoped and rotate it periodically.
- Keep the EC2 OS and Java/Maven packages patched.


