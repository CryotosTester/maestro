## Pipeline Overview

This project uses an Azure DevOps pipeline that runs on a self-hosted agent installed on the STAGING EC2 instance. It executes the existing deployment script `script/cdupgrade.sh` to build and run the application.

### Files
- `deploy-staging.yml` — main pipeline definition (manual trigger)
- `AGENT_SETUP.md` — how to install and register the self-hosted agent
- `DEPLOYMENT.md` — how to run the deployment and approvals

### Variables / Parameters
- Parameter `environment`: `STAGING`
- Parameter `confirmDeployment`: boolean confirmation when queuing the run

### Agent Pool
Configure the pipeline to use agent pool: `cryotos-staging`.

### Script Location
The deployment script must exist at `script/cdupgrade.sh` in the repository. The pipeline auto-confirms the script's Y/N prompt by piping `Y`.






