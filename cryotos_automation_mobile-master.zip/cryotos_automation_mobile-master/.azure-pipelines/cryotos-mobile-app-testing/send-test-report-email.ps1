param(
    [Parameter(Mandatory = $true)]
    [string]$TestResultsDir,
    
    [Parameter(Mandatory = $true)]
    [string]$Environment,
    
    [Parameter(Mandatory = $true)]
    [string]$EmailRecipients,
    
    [Parameter(Mandatory = $true)]
    [string]$SmtpHost,
    
    [Parameter(Mandatory = $true)]
    [string]$SmtpPort,
    
    [Parameter(Mandatory = $true)]
    [string]$SmtpUsername,
    
    [Parameter(Mandatory = $true)]
    [string]$SmtpPassword,
    
    [Parameter(Mandatory = $true)]
    [string]$SenderEmail,
    
    [Parameter(Mandatory = $false)]
    [string]$SenderName = "Cryotos Automation",
    
    [Parameter(Mandatory = $false)]
    [string]$EmailSubject = "",
    
    [Parameter(Mandatory = $false)]
    [string[]]$AttachmentPaths = @()
)

$ErrorActionPreference = "Stop"

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'SUCCESS', 'WARNING', 'ERROR')]
        [string]$Level = 'INFO'
    )
    
    $Timestamp = Get-Date -Format "HH:mm:ss"
    $Color = switch ($Level) {
        'SUCCESS' { 'Green' }
        'WARNING' { 'Yellow' }
        'ERROR'   { 'Red' }
        default   { 'White' }
    }
    
    Write-Host "[$Timestamp] $Level - $Message" -ForegroundColor $Color
}

function Parse-JUnitXmlResults {
    param([string]$ResultsDir)
    
    $totalTests = 0
    $passed = 0
    $failed = 0
    $broken = 0
    $skipped = 0
    
    try {
        $xmlFiles = Get-ChildItem -Path $ResultsDir -Filter "*.xml" -ErrorAction SilentlyContinue
        
        foreach ($xmlFile in $xmlFiles) {
            Write-Log "Processing XML file: $($xmlFile.Name)" -Level INFO
            try {
                [xml]$xml = Get-Content -Path $xmlFile.FullName -Raw -ErrorAction Stop
                Write-Log "XML loaded successfully" -Level INFO
                
                # Parse testsuites element with testsuite child
                if ($xml.testsuites -and $xml.testsuites.testsuite) {
                    Write-Log "Found testsuites with testsuite element, parsing attributes..." -Level INFO
                    $totalTests += [int]$xml.testsuites.testsuite.tests
                    $failed += [int]$xml.testsuites.testsuite.failures
                    $broken += [int]$xml.testsuites.testsuite.errors
                    $skipped += [int]$xml.testsuites.testsuite.skipped
                    $passed = $totalTests - $failed - $broken - $skipped
                    Write-Log "Parsed from testsuites.testsuite: Total=$totalTests, Failed=$failed, Broken=$broken, Skipped=$skipped, Passed=$passed" -Level INFO
                }
                # Parse testsuites element (if it has attributes directly)
                elseif ($xml.testsuites) {
                    Write-Log "Found testsuites element, parsing attributes..." -Level INFO
                    $totalTests += [int]$xml.testsuites.tests
                    $failed += [int]$xml.testsuites.failures
                    $broken += [int]$xml.testsuites.errors
                    $skipped += [int]$xml.testsuites.skipped
                    $passed = $totalTests - $failed - $broken - $skipped
                    Write-Log "Parsed from testsuites: Total=$totalTests, Failed=$failed, Broken=$broken, Skipped=$skipped, Passed=$passed" -Level INFO
                }
                # Parse testsuite element (alternative structure)
                elseif ($xml.testsuite) {
                    Write-Log "Found testsuite element, parsing attributes..." -Level INFO
                    $totalTests += [int]$xml.testsuite.tests
                    $failed += [int]$xml.testsuite.failures
                    $broken += [int]$xml.testsuite.errors
                    $skipped += [int]$xml.testsuite.skipped
                    $passed = $totalTests - $failed - $broken - $skipped
                    Write-Log "Parsed from testsuite: Total=$totalTests, Failed=$failed, Broken=$broken, Skipped=$skipped, Passed=$passed" -Level INFO
                }
                # Parse individual testcase elements
                elseif ($xml.SelectNodes("//testcase")) {
                    Write-Log "Found testcase elements, parsing individually..." -Level INFO
                    $testCases = $xml.SelectNodes("//testcase")
                    $totalTests += $testCases.Count
                    Write-Log "Found $($testCases.Count) testcase elements" -Level INFO

                    foreach ($testCase in $testCases) {
                        if ($testCase.failure -or $testCase.error) {
                            if ($testCase.failure) {
                                $failed++
                            } else {
                                $broken++
                            }
                        } elseif ($testCase.skipped) {
                            $skipped++
                        } else {
                            $passed++
                        }
                    }
                    Write-Log "Parsed from testcases: Total=$totalTests, Failed=$failed, Broken=$broken, Skipped=$skipped, Passed=$passed" -Level INFO
                }
            }
            catch {
                Write-Log "Error parsing XML file $($xmlFile.Name): $_" -Level WARNING
            }
        }
    }
    catch {
        Write-Log "Error reading test results directory: $_" -Level WARNING
    }
    
    return @{
        Total = $totalTests
        Passed = $passed
        Failed = $failed
        Broken = $broken
        Skipped = $skipped
    }
}

function Generate-EmailHtml {
    param(
        [hashtable]$TestResults,
        [string]$Environment
    )
    
    $envUpper = $Environment.ToUpper()
    $total = $TestResults.Total
    $passed = $TestResults.Passed
    $failed = $TestResults.Failed
    $broken = $TestResults.Broken
    $skipped = $TestResults.Skipped
    
    $passedPercent = if ($total -gt 0) { [math]::Round(($passed / $total) * 100, 1) } else { 0 }
    $failedPercent = if ($total -gt 0) { [math]::Round(($failed / $total) * 100, 1) } else { 0 }
    
    $envUrl = if ($Environment -eq 'prod') { "https://app.cryotos.com" } else { "https://app-stage.cryotos.com" }
    
    $html = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #e0e0e0;
        }
        .header-icon {
            width: 24px;
            height: 24px;
            margin-right: 12px;
        }
        .header-title {
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin: 0;
        }
        .environment {
            color: #666;
            font-size: 14px;
            margin-top: 5px;
        }
        .summary-section {
            margin-top: 30px;
        }
        .summary-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
        }
        .test-item {
            display: flex;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .test-item:last-child {
            border-bottom: none;
        }
        .test-label {
            flex: 1;
            font-size: 14px;
            color: #333;
        }
        .test-value {
            font-size: 14px;
            font-weight: 600;
        }
        .passed {
            color: #4caf50;
        }
        .failed {
            color: #f44336;
        }
        .broken {
            color: #ff9800;
        }
        .skipped {
            color: #2196f3;
        }
        .icon {
            display: inline-block;
            width: 16px;
            height: 16px;
            margin-right: 8px;
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <svg class="header-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 3V21H21V3H3ZM19 19H5V5H19V19Z" fill="#333"/>
                <path d="M7 7H17V9H7V7ZM7 11H17V13H7V11ZM7 15H12V17H7V15Z" fill="#333"/>
            </svg>
            <div>
                <h1 class="header-title">Test Execution Report - $envUpper</h1>
                <div class="environment">Environment: $envUrl</div>
            </div>
        </div>
        
        <div class="summary-section">
            <div class="summary-title">Test Results Summary</div>
            
            <div class="test-item">
                <span class="test-label"><strong>Total Tests:</strong></span>
                <span class="test-value">$total</span>
            </div>
            
            <div class="test-item">
                <span class="test-label">
                    <span style="color: #4caf50;">&#10003;</span> <strong>Passed:</strong>
                </span>
                <span class="test-value passed">$passed ($passedPercent%)</span>
            </div>
            
            <div class="test-item">
                <span class="test-label">
                    <span style="color: #f44336;">&#10007;</span> <strong>Failed:</strong>
                </span>
                <span class="test-value failed">$failed ($failedPercent%)</span>
            </div>
            
            <div class="test-item">
                <span class="test-label">
                    <span style="color: #ff9800;">&#9888;</span> <strong>Broken:</strong>
                </span>
                <span class="test-value broken">$broken</span>
            </div>
            
            <div class="test-item">
                <span class="test-label">
                    <span style="color: #2196f3;">&#9193;</span> <strong>Skipped:</strong>
                </span>
                <span class="test-value skipped">$skipped</span>
            </div>
        </div>
    </div>
</body>
</html>
"@
    
    return $html
}

function Send-TestReportEmail {
    param(
        [string]$ToEmail,
        [string]$Subject,
        [string]$HtmlContent,
        [string[]]$AttachmentPaths
    )
    
    try {
        Write-Log "Configuring SMTP client for Amazon SES" -Level INFO
        Write-Log "SMTP Host: $SmtpHost" -Level INFO
        Write-Log "SMTP Port: $SmtpPort" -Level INFO
        
        # Create SMTP client (similar to Java Properties approach)
        $smtpPortInt = [int]$SmtpPort
        $smtpClient = New-Object System.Net.Mail.SmtpClient($SmtpHost, $smtpPortInt)
        $smtpClient.EnableSsl = $true
        $smtpClient.Timeout = 60000
        $smtpClient.DeliveryMethod = [System.Net.Mail.SmtpDeliveryMethod]::Network
        
        # Create credentials with plain string password
        # Note: Azure DevOps passes credentials as plain strings, so SecureString conversion is not needed
        $credentials = New-Object System.Net.NetworkCredential($SmtpUsername, $SmtpPassword)
        $smtpClient.Credentials = $credentials
        
        Write-Log "Creating email message" -Level INFO
        
        # Create mail message
        $mailMessage = New-Object System.Net.Mail.MailMessage
        $mailMessage.From = New-Object System.Net.Mail.MailAddress($SenderEmail, $SenderName)
        $mailMessage.Subject = $Subject
        $mailMessage.IsBodyHtml = $true
        $mailMessage.Body = $HtmlContent
        $mailMessage.BodyEncoding = [System.Text.Encoding]::UTF8
        
        # Parse recipients (support comma and semicolon separated)
        $recipients = $ToEmail -split '[;,]' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }
        
        foreach ($recipient in $recipients) {
            if ($recipient -match '^[^\s@]+@[^\s@]+\.[^\s@]+$') {
                $mailMessage.To.Add($recipient)
                Write-Log "Added recipient: $recipient" -Level INFO
            } else {
                Write-Log "Invalid email address skipped: $recipient" -Level WARNING
            }
        }
        
        if ($mailMessage.To.Count -eq 0) {
            throw "No valid email recipients found"
        }
        
        # Add attachments if provided
        if ($AttachmentPaths -and $AttachmentPaths.Count -gt 0) {
            foreach ($attachmentPath in $AttachmentPaths) {
                if (Test-Path -Path $attachmentPath) {
                    $attachment = New-Object System.Net.Mail.Attachment($attachmentPath)
                    $mailMessage.Attachments.Add($attachment)
                    Write-Log "Added attachment: $(Split-Path -Leaf $attachmentPath)" -Level INFO
                } else {
                    Write-Log "Attachment file not found: $attachmentPath" -Level WARNING
                }
            }
        }
        
        Write-Log "Sending email to $($mailMessage.To.Count) recipient(s)..." -Level INFO
        
        # Send email
        $smtpClient.Send($mailMessage)
        
        Write-Log "Email sent successfully to: $ToEmail" -Level SUCCESS
        
        # Cleanup
        if ($mailMessage.Attachments) {
            $mailMessage.Attachments.Dispose()
        }
        $mailMessage.Dispose()
        $smtpClient.Dispose()
        
        return $true
    }
    catch {
        Write-Log "Failed to send email: $_" -Level ERROR
        Write-Log "Error details: $($_.Exception.Message)" -Level ERROR
        return $false
    }
}

# Main execution
try {
    Write-Log "Starting email report generation" -Level INFO
    Write-Log "Test Results Directory: $TestResultsDir" -Level INFO
    Write-Log "Environment: $Environment" -Level INFO
    
    # Parse test results from JUnit XML files
    Write-Log "Parsing JUnit XML test results..." -Level INFO
    $testResults = Parse-JUnitXmlResults -ResultsDir $TestResultsDir
    
    Write-Log "Test Results Summary:" -Level INFO
    Write-Log "  Total Tests: $($testResults.Total)" -Level INFO
    Write-Log "  Passed: $($testResults.Passed)" -Level INFO
    Write-Log "  Failed: $($testResults.Failed)" -Level INFO
    Write-Log "  Broken: $($testResults.Broken)" -Level INFO
    Write-Log "  Skipped: $($testResults.Skipped)" -Level INFO
    
    # Generate HTML email content
    Write-Log "Generating HTML email content..." -Level INFO
    $htmlContent = Generate-EmailHtml -TestResults $testResults -Environment $Environment
    
    # Set email subject if not provided
    if ([string]::IsNullOrWhiteSpace($EmailSubject)) {
        $executionTime = Get-Date -Format "yyyy-MM-dd HH:mm"
        $EmailSubject = "[REPORT] Cryotos Mobile Automation Test Execution Report - [$($Environment.ToUpper())] $executionTime"
    }
    
    # Send email
    $emailSent = Send-TestReportEmail -ToEmail $EmailRecipients -Subject $EmailSubject -HtmlContent $htmlContent -AttachmentPaths $AttachmentPaths
    
    if ($emailSent) {
        Write-Log "Email report sent successfully" -Level SUCCESS
        exit 0
    } else {
        Write-Log "Failed to send email report" -Level ERROR
        exit 1
    }
}
catch {
    Write-Log "Error in email report generation: $_" -Level ERROR
    Write-Log "Stack trace: $($_.ScriptStackTrace)" -Level ERROR
    exit 1
}

