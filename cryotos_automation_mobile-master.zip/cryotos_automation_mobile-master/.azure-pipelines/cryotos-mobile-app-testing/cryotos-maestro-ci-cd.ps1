param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('stage', 'prod')]
    [string]$Environment = $env:ENVIRONMENT,

    [Parameter(Mandatory = $false)]
    [ValidateSet('automation', 'regular')]
    [string]$ConfigType = 'automation',

    [Parameter(Mandatory = $false)]
    [string]$GitAccessToken = $env:GIT_ACCESS_TOKEN,

    [Parameter(Mandatory = $false)]
    [string]$FlutterRepoUrl ='https://github.com/MinusculeTechnologiesLtd/cmmsflutter.git',

    [Parameter(Mandatory = $false)]
    [string]$TestRepoUrl = 'https://github.com/MinusculeTechnologiesLtd/cryotos_automation_mobile.git',

[Parameter(Mandatory = $false)]
[string]$BaseProjectPath = "C:\Users\Developers\Pictures\cryotos-cicd",

[Parameter(Mandatory = $false)]
[string]$EmulatorName = "Pixel_9a"
)

$ExecutionTimestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BaseProjectPath = "$BaseProjectPath\execution_$ExecutionTimestamp"

# Expose the dynamically generated execution path to Azure DevOps
# so that subsequent tasks (e.g. artifact publishing) can use it.
# This creates a pipeline variable named 'ExecutionBasePath'.
# Using isOutput=true makes it available as an output variable for dependent stages
Write-Host "##vso[task.setvariable variable=ExecutionBasePath;isOutput=true]$BaseProjectPath"
Write-Host "[INFO] ExecutionBasePath set to: $BaseProjectPath"

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$FlutterAppDir = "$BaseProjectPath\cmms_flutter"
$MaestroTestDir = "$BaseProjectPath\cryotos_automation_mobile"
$LogsDir = "$BaseProjectPath\logs"
$AllureReportDir = "$BaseProjectPath\maestro-reports\allure-report"
$MaestroResultsDir = "$MaestroTestDir\.maestro\test-results"
$MaestroSessionsDir = "$env:USERPROFILE\.maestro\sessions"

$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$EmulatorLogFile = "$LogsDir\emulator-$Timestamp.log"
$PipelineSummaryLogFile = "$LogsDir\pipeline-summary-$Timestamp.log"

$StagePackageName = "com.maintenanceCryotosStage.cmms"
$ProdPackageName = "com.maintenanceCryotosProd.cmms"
$AutomationPackageName = "com.maintenanceCryotosAutomation.cmms"
$AppPackageName = switch ($Environment) {
    'stage' { $StagePackageName }
    'prod' { $ProdPackageName }
    'automation' { $AutomationPackageName }
}

# APK path will be set after building

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'SUCCESS', 'WARNING', 'ERROR')]
        [string]$Level = 'INFO'
    )
    
    $Timestamp = Get-Date -Format "HH:mm:ss"
    $Color = switch ($Level) {
        'SUCCESS' { 'Green' }
        'WARNING' { 'Yellow' }
        'ERROR'   { 'Red' }
        default   { 'White' }
    }
    
    Write-Host "[$Timestamp] $Level - $Message" -ForegroundColor $Color
}

function Test-DirectoryExists {
    param([string]$Path)
    if (Test-Path -Path $Path -PathType Container) {
        return $true
    }
    return $false
}

function Clear-Directory {
    param([string]$Path)
    
    if (Test-DirectoryExists -Path $Path) {
        Write-Log "Clearing directory: $Path" -Level INFO
        Remove-Item -Path "$Path\*" -Recurse -Force -ErrorAction SilentlyContinue
        Write-Log "Directory cleared: $Path" -Level SUCCESS
    }
}

function Create-Directory {
    param([string]$Path)
    
    if (-not (Test-DirectoryExists -Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
        Write-Log "Directory created: $Path" -Level SUCCESS
    }
}

function Initialize-Pipeline {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "CRYOTOS MAESTRO CI/CD PIPELINE" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Log "Environment: $Environment" -Level INFO
    Write-Log "Config Type: $ConfigType" -Level INFO
    Write-Log "Base Project Path: $BaseProjectPath" -Level INFO
    Write-Log "Emulator: $EmulatorName" -Level INFO
    Write-Log "Execution ID: $Timestamp" -Level INFO
}

function Prepare-Directories {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 1: PREPARE DIRECTORIES" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    Create-Directory -Path $LogsDir
    Create-Directory -Path "$BaseProjectPath\maestro-reports"
    
    Clear-Directory -Path $FlutterAppDir
    Remove-Item -Path $MaestroTestDir\* -Recurse -Force -ErrorAction SilentlyContinue
    Clear-Directory -Path $AllureReportDir
    
    Create-Directory -Path $FlutterAppDir
    Create-Directory -Path $MaestroTestDir
    Create-Directory -Path $AllureReportDir
    
    Write-Log "All directories prepared" -Level SUCCESS
}

function Clone-GitRepository {
    param(
        [string]$RepoUrl,
        [string]$TargetDir,
        [string]$RepositoryName,
        [string]$Branch
    )
    
    Write-Log "Cloning $RepositoryName from: $RepoUrl" -Level INFO
    
    $RepoUrlWithToken = $RepoUrl -replace "https://", "https://git:$GitAccessToken@"
    
    try {
        Push-Location -Path $TargetDir
        if ($Branch) {
            & git clone --quiet -b $Branch $RepoUrlWithToken .
        } else {
            & git clone --quiet $RepoUrlWithToken .
        }
        Write-Log "Repository cloned successfully: $RepositoryName" -Level SUCCESS
        Pop-Location
    }
    catch {
        Write-Log "Failed to clone $RepositoryName : $_" -Level ERROR
        Pop-Location
        throw
    }
}

function Prepare-GitRepositories {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 2: CLONE GIT REPOSITORIES" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    Clone-GitRepository -RepoUrl $FlutterRepoUrl -TargetDir $FlutterAppDir -RepositoryName "Flutter App" -Branch "develop"
    Clone-GitRepository -RepoUrl $TestRepoUrl -TargetDir $MaestroTestDir -RepositoryName "Maestro Tests" -Branch "master"

    Create-Directory -Path $MaestroResultsDir
    
}

function Setup-Flutter {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 3: SETUP FLUTTER ENVIRONMENT" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    Push-Location -Path $FlutterAppDir
    
    try {

        Write-Log "Current user (env): $($env:USERDOMAIN)\$($env:USERNAME)" -Level INFO
        Write-Log "Current user (whoami): $(whoami)" -Level INFO
        Write-Log "Current user (identity): $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)" -Level INFO

        Write-Log "Marking Flutter Git repo as safe for SYSTEM" -Level INFO
        git config --global --add safe.directory "C:/Users/Developers/AppData/Local/flutter"

        Write-Log "Running Flutter doctor" -Level INFO
        & flutter doctor --verbose 2>&1 | Select-Object -First 20
        
        Write-Log "Running Flutter clean" -Level INFO
        & flutter clean | Out-Null
        
        Write-Log "Running Flutter pub get" -Level INFO
        & flutter pub get | Out-Null
        
        Write-Log "Fixing Android dependencies" -Level INFO
        & dart run fix_android_dependencies.dart | Out-Null
        
        Write-Log "Flutter setup completed" -Level SUCCESS
    }
    catch {
        Write-Log "Flutter setup failed: $_" -Level ERROR
        throw
    }
    finally {
        Pop-Location
    }
}

function Switch-Environment {
    Write-Log "Switching environment to: $Environment with config: $ConfigType" -Level INFO

    Push-Location -Path $FlutterAppDir

    try {
        & python scripts/switch_env.py $Environment $ConfigType | Out-Null
        Write-Log "Environment switched successfully" -Level SUCCESS
    }
    catch {
        Write-Log "Warning: Environment switch may have failed" -Level WARNING
    }
    finally {
        Pop-Location
    }
}

function Build-Flutter {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 4: BUILD FLUTTER APK" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""

    Write-Log "FlutterAppDir: $FlutterAppDir" -Level INFO
    Push-Location -Path $FlutterAppDir
    
    try {
        Write-Log "Building Flutter APK for environment: $Environment ($ConfigType)" -Level INFO

        # Determine flavor based on environment
        $flavor = switch ($Environment) {
            'stage' { 'stage' }
            'prod' { 'prod' }
            'automation' { 'automation' }
        }

        Write-Log "Configuring Flutter JDK directory" -Level INFO
        & flutter config --jdk-dir="C:\Program Files\Eclipse Adoptium\jdk-21.0.9.10-hotspot" | Out-Host

        # Build APK with flavor
        Write-Log "Running: flutter build apk " -Level INFO
        & flutter build apk | Out-Host

        if ($LASTEXITCODE -ne 0) {
            throw "Flutter build failed with exit code $LASTEXITCODE"
        }
        
        # Find the built APK file
        $apkOutputDir = "$FlutterAppDir\build\app\outputs\flutter-apk"
        Write-Log "Looking for APK in: $apkOutputDir" -Level INFO

        # Check if directory exists
        if (-not (Test-Path -Path $apkOutputDir)) {
            throw "APK output directory does not exist: $apkOutputDir"
        }

        # List all files in the directory for debugging
        $allFiles = Get-ChildItem -Path $apkOutputDir -ErrorAction SilentlyContinue
        Write-Log "Files in APK directory: $($allFiles.Name -join ', ')" -Level INFO

        $apkFile = Get-ChildItem -Path $apkOutputDir -Filter "app-release.apk" -ErrorAction SilentlyContinue
        Write-Log "Found APK file: $($apkFile.Name)" -Level INFO

        if (-not $apkFile) {
            # Try alternative path structure
            Write-Log "Trying alternative APK search..." -Level INFO
            $apkFile = Get-ChildItem -Path $apkOutputDir -Filter "*.apk" -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -like "*release*" } |
                       Select-Object -First 1
            Write-Log "Alternative search found: $($apkFile.Name)" -Level INFO
        }
        
        if (-not $apkFile) {
            throw "APK file not found in $apkOutputDir after build"
        }
        
        $apkPath = $apkFile.FullName
        Write-Log "APK found at: $apkPath" -Level INFO
        Write-Log "APK built successfully: $apkPath" -Level SUCCESS
        Write-Log "APK size: $([math]::Round($apkFile.Length / 1MB, 2)) MB" -Level INFO

        return $apkPath
    }
    catch {
        Write-Log "Flutter build failed: $_" -Level ERROR
        throw
    }
    finally {
        Pop-Location
    }
}

function Get-EmulatorStatus {
    try {
        $devices = & adb devices 2>&1
        $running = $devices | Select-String "emulator-" | Select-String "device"
        return $running.Count -gt 0
    }
    catch {
        return $false
    }
}

function Verify-EmulatorPrerequisites {
    Write-Log "Verifying emulator prerequisites..." -Level INFO
    
    # Check emulator executable exists
    try {
        $emulatorPath = & where.exe emulator 2>&1
        if ($LASTEXITCODE -ne 0) {
            throw "Emulator executable not found in PATH"
        }
        Write-Log "Emulator found at: $emulatorPath" -Level SUCCESS
    }
    catch {
        throw "CRITICAL: Emulator executable not available. Install Android SDK or add to PATH"
    }
    
    # Check if AVD exists
    $avdHome = "$env:USERPROFILE\.android\avd"
    $avdPath = "$avdHome\$EmulatorName.avd"
    if (-not (Test-Path -Path $avdPath)) {
        $availableAvds = Get-ChildItem -Path $avdHome -Filter "*.avd" -ErrorAction SilentlyContinue | ForEach-Object { $_.Name -replace '\.avd$', '' }
        throw "AVD '$EmulatorName' not found. Available AVDs: $($availableAvds -join ', ')"
    }
    Write-Log "AVD exists: $EmulatorName" -Level SUCCESS
    
    # Kill any stale emulator processes
    $staleEmulators = Get-Process -Name "qemu-system-*" -ErrorAction SilentlyContinue
    if ($staleEmulators) {
        Write-Log "Killing stale emulator processes..." -Level WARNING
        $staleEmulators | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
    
    Write-Log "Prerequisites verified" -Level SUCCESS
}

function Start-EmulatorWithLogging {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 5: START EMULATOR AND CAPTURE LOGS" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    # Verify prerequisites before attempting to start
    Verify-EmulatorPrerequisites
    
    $isRunning = Get-EmulatorStatus
    
    if ($isRunning) {
        Write-Log "Emulator already running" -Level SUCCESS
        Write-Log "Waiting 5 seconds for stability" -Level INFO
        Start-Sleep -Seconds 5
    }
    else {
        Write-Log "Starting emulator: $EmulatorName" -Level INFO
        
        try {
            $argumentList = @(
                "-avd", $EmulatorName,
                "-gpu", "swiftshader_indirect",
                "-accel", "on",
                "-no-boot-anim",
                "-noaudio",
                "-no-snapshot",
                "-no-window"
            )
            
            $emulatorErrorLog = "$($EmulatorLogFile).err"
            $emulatorProcess = Start-Process -FilePath "emulator" `
                -ArgumentList $argumentList `
                -RedirectStandardOutput $EmulatorLogFile `
                -RedirectStandardError $emulatorErrorLog `
                -WindowStyle Hidden `
                -PassThru
            
            Write-Log "Emulator process started (PID: $($emulatorProcess.Id))" -Level SUCCESS
            Write-Log "Emulator stdout: $EmulatorLogFile" -Level INFO
            Write-Log "Emulator stderr: $emulatorErrorLog" -Level INFO
            
            # Check if process is still running after 3 seconds
            Start-Sleep -Seconds 3
            if ($emulatorProcess.HasExited) {
                $errorContent = Get-Content $emulatorErrorLog -Raw -ErrorAction SilentlyContinue
                throw "Emulator exited immediately (crashed on startup). Error: $errorContent"
            }
            Write-Log "Emulator process is running" -Level SUCCESS
            
            Write-Log "Waiting 90 seconds for emulator to boot..." -Level INFO
            Start-Sleep -Seconds 90
            
            # Verify emulator is still running
            if ($emulatorProcess.HasExited) {
                $errorContent = Get-Content $emulatorErrorLog -Raw -ErrorAction SilentlyContinue
                throw "Emulator crashed during boot. Error: $errorContent"
            }
            
            # Verify ADB can see the emulator
            $devices = & adb devices 2>&1
            $devicesString = $devices -join "`n"
            Write-Log "ADB devices output:`n$devicesString" -Level INFO
            
            # Check if any line contains emulator-XXXX followed by device (with any whitespace)
            $deviceDetected = $devices | Where-Object { $_ -match "emulator-\d+\s+device" }
            if (-not $deviceDetected) {
                throw "Emulator is running but ADB cannot detect it. ADB output: $devicesString"
            }
            Write-Log "Emulator detected: $($deviceDetected -join ', ')" -Level SUCCESS
            
            Write-Log "Emulator stabilized and ready" -Level SUCCESS
        }
        catch {
            Write-Log "Failed to start emulator: $_" -Level ERROR
            throw
        }
    }
}

function Uninstall-OldApplication {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 6: UNINSTALL OLD APPLICATION" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Log "Uninstalling old package: $AppPackageName" -Level INFO
    
    try {
        & adb uninstall $AppPackageName 2>&1 | Out-Null
        Write-Log "Old application uninstalled" -Level SUCCESS
    }
    catch {
        Write-Log "No old application found or uninstall failed" -Level WARNING
    }
}


function Test-AdbAvailable {
    try {
        $null = & adb devices 2>&1
        return $LASTEXITCODE -eq 0
    }
    catch {
        return $false
    }
}

function Restart-AdbServer {
    Write-Log "Restarting ADB server..." -Level INFO
    try {
        # Kill existing ADB server
        $killOutput = & adb kill-server 2>&1
        if ($LASTEXITCODE -ne 0 -and $killOutput -notmatch "server not running") {
            Write-Log "Warning: adb kill-server failed: $killOutput" -Level WARNING
        }
        Start-Sleep -Seconds 2

        # Start ADB server - capture output but don't treat normal startup messages as errors
        $startOutput = & adb start-server 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Log "adb start-server failed with exit code $LASTEXITCODE" -Level ERROR
            return $false
        }

        # Check if the output contains the normal startup message (not an error)
        if ($startOutput -match "daemon not running.*starting now") {
            Write-Log "ADB daemon was not running, now started successfully" -Level INFO
        } elseif ($startOutput -match "daemon started successfully") {
            Write-Log "ADB daemon started successfully" -Level INFO
        } elseif ($startOutput) {
            Write-Log "ADB start output: $startOutput" -Level INFO
        }

        Start-Sleep -Seconds 3

        if (Test-AdbAvailable) {
            Write-Log "ADB server restarted successfully" -Level SUCCESS
            return $true
        }
        Write-Log "ADB server restart verification failed" -Level ERROR
        return $false
    }
    catch {
        Write-Log "Failed to restart ADB server: $_" -Level ERROR
        return $false
    }
}



function Install-Application {
    param([string]$ApkPath)
    
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 7: INSTALL NEW APPLICATION" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""

    Write-Log "Install-Application called with ApkPath: '$ApkPath'" -Level INFO

    if ([string]::IsNullOrWhiteSpace($ApkPath)) {
        Write-Log "APK path is not provided" -Level ERROR
        throw "APK path is required"
    }

    if (-not (Test-Path -Path $ApkPath)) {
        Write-Log "APK not found at: $ApkPath" -Level ERROR
        throw "APK file not found"
    }

    # Check if ADB is working, restart only if necessary
    Write-Log "Checking ADB connectivity..." -Level INFO
    $adbWorking = $false
    try {
        $devices = & adb devices 2>&1
        $deviceReady = $devices | Where-Object { $_ -match "emulator-\d+\s+device" -or $_ -match "^\w+\s+device$" }
        if ($deviceReady) {
            Write-Log "ADB is working correctly - device detected: $($deviceReady -join ', ')" -Level SUCCESS
            $adbWorking = $true
        } else {
            Write-Log "ADB devices command succeeded but no device ready. Output: $($devices -join '; ')" -Level WARNING
        }
    }
    catch {
        Write-Log "ADB devices command failed: $_" -Level WARNING
    }

    # Only restart ADB server if it's not working properly
    if (-not $adbWorking) {
        Write-Log "ADB appears to have issues, restarting server..." -Level WARNING
        if (-not (Restart-AdbServer)) {
            throw "ADB server restart failed"
        }
    } else {
        Write-Log "ADB server restart skipped - ADB is working correctly" -Level INFO
    }

    # Wait for device to be ready (final verification)
    $maxRetries = 10
    for ($i = 0; $i -lt $maxRetries; $i++) {
        $devices = & adb devices 2>&1
        $deviceReady = $devices | Where-Object { $_ -match "emulator-\d+\s+device" -or $_ -match "^\w+\s+device$" }
        if ($deviceReady) {
            break
        }
        if ($i -eq $maxRetries - 1) {
            throw "No Android device/emulator is connected or ready"
        }
        Start-Sleep -Seconds 3
    }
    
    Write-Log "Installing APK from: $ApkPath" -Level INFO
    
    try {
        $installOutput = & adb install -r $ApkPath 2>&1
        $installOutput | ForEach-Object { Write-Host $_ }
        
        if ($LASTEXITCODE -ne 0) {
            throw "ADB install failed with exit code $LASTEXITCODE. Output: $($installOutput -join '; ')"
        }
        
        Start-Sleep -Seconds 2
        
        $installedPackages = & adb shell pm list packages 2>&1
        if ($installedPackages -match [regex]::Escape($AppPackageName)) {
            Write-Log "Application installed successfully: $AppPackageName" -Level SUCCESS
        }
        else {
            throw "Application not found after installation. Expected package: $AppPackageName"
        }
    }
    catch {
        Write-Log "Application installation failed: $_" -Level ERROR
        throw
    }
}

function Configure-InputMethod {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 8: CONFIGURE INPUT METHOD" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    Write-Log "Checking input method configuration" -Level INFO
    
    try {
        $installedMethods = & adb shell ime list -a 2>&1
        
        & adb shell ime enable com.android.adbkeyboard/.AdbIME 2>&1 | Out-Null
        & adb shell ime set com.android.adbkeyboard/.AdbIME 2>&1 | Out-Null
        
        Write-Log "Input method configured successfully" -Level SUCCESS
    }
    catch {
        Write-Log "Input method configuration warning: non-critical" -Level WARNING
    }
}

function Run-MaestroTests {
    param(
        [string]$TestType,
        [string]$ConfigPath,
        [string]$OutputFile,
        [string]$AppPackageName
    )
    
    Write-Log "Running $TestType tests" -Level INFO
    
    Push-Location -Path $MaestroTestDir
    
    try {
        # Resolve config path to absolute path
        $absoluteConfigPath = Join-Path -Path $MaestroTestDir -ChildPath $ConfigPath
        if (-not (Test-Path -Path $absoluteConfigPath)) {
            Write-Log "Config file not found: $absoluteConfigPath" -Level ERROR
            throw "Config file not found: $absoluteConfigPath"
        }


        #delete following file $MaestroSessionsDir
        Remove-Item -Path $MaestroSessionsDir -Force -ErrorAction SilentlyContinue
        
        # Set environment variable for maestro to use   
        $env:MAESTRO_APP_ID = $AppPackageName
        $env:MAESTRO_ENV = $Environment
        
        Write-Log "Running: maestro test --config $absoluteConfigPath . --format junit --output $OutputFile (MAESTRO_APP_ID=$AppPackageName)" -Level INFO
        & maestro test --config "$absoluteConfigPath" . --format junit --output "$OutputFile" 2>&1 | ForEach-Object {
            Write-Host $_
        }
        
        if (Test-Path -Path $OutputFile) {
            Write-Log "$TestType tests completed successfully" -Level SUCCESS
            return $true
        }
        else {
            Write-Log "$TestType tests failed - no output generated" -Level ERROR
            return $false
        }
    }
    catch {
        Write-Log "$TestType tests execution failed: $_" -Level ERROR
        return $false
    }
    finally {
        Pop-Location
    }
}

function ExecuteMaestroTests {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 9: EXECUTE MAESTRO TEST SUITES" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    $testResults = @{}
    
    Write-Host ""
    Write-Host "========== REGRESSION TESTS ==========" -ForegroundColor Yellow
    Write-Host ""
    $regressionConfig = "Mobile Automation Testing/tests/regression/regression.yaml"
    $testResults['regression'] = Run-MaestroTests -TestType "Regression" -ConfigPath $regressionConfig -OutputFile "$MaestroResultsDir\regression-report.xml" -AppPackageName $AppPackageName
    
    
    Write-Host ""
    Write-Host "========== END-TO-END TESTS ==========" -ForegroundColor Yellow
    Write-Host ""
    $e2eConfig = "Mobile Automation Testing/tests/end-to-end/end-to-end.yaml"
    $testResults['e2e'] = Run-MaestroTests -TestType "End-to-End" -ConfigPath $e2eConfig -OutputFile "$MaestroResultsDir\end-to-end-report.xml" -AppPackageName $AppPackageName

    # Write-Host ""
    # Write-Host "========== INTEGRATION TESTS ==========" -ForegroundColor Yellow
    # Write-Host ""
    # $integrationConfig = "Mobile Automation Testing/tests/integration/web-to-mobile-work-order-integration.yaml"
    # $testResults['integration'] = Run-MaestroTests -TestType "Integration" -ConfigPath $integrationConfig -OutputFile "$MaestroResultsDir\integration-report.xml" -AppPackageName $AppPackageName
    
    return $testResults
}

function VerifyTestReports {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 10: VERIFY TEST REPORTS" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    $reportFiles = @(
        "$MaestroResultsDir\regression-report.xml",
        "$MaestroResultsDir\integration-report.xml",
        "$MaestroResultsDir\end-to-end-report.xml"
    )
    
    $allReportsExist = $true
    
    foreach ($report in $reportFiles) {
        if (Test-Path -Path $report) {
            Write-Log "Found: $report" -Level SUCCESS
        }
        else {
            Write-Log "Missing: $report" -Level WARNING
            $allReportsExist = $false
        }
    }
    
    return $allReportsExist
}

function Fix-JUnitXmlForAllure {
    param([string]$XmlPath)
    
    try {
        [xml]$xml = Get-Content -Path $XmlPath -Raw
        
        # Extract suite name from filename (e.g., "regression-report.xml" -> "Regression Test Suite")
        $fileName = [System.IO.Path]::GetFileNameWithoutExtension($XmlPath)
        $suiteName = $fileName -replace '-report$', '' -replace '-', ' ' | ForEach-Object {
            (Get-Culture).TextInfo.ToTitleCase($_.ToLower())
        }
        $suiteName = "$suiteName Test Suite"
        
        if ($xml.testsuites.testsuite) {
            $xml.testsuites.testsuite.name = $suiteName
        }
        
        # Add message attribute to failure elements
        $xml.SelectNodes("//testcase/failure") | ForEach-Object {
            if ($_.InnerText -and -not $_.message) {
                $_.SetAttribute("message", $_.InnerText.Trim())
            }
        }
        
        $xml.Save($XmlPath)
    }
    catch {
        Write-Log "Warning: Could not fix XML format for $XmlPath : $_" -Level WARNING
    }
}

function GenerateAllureReport {
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 11: GENERATE ALLURE REPORT" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    try {
        Write-Log "Fixing JUnit XML format for Allure compatibility" -Level INFO
        
        # Fix XML format for Allure
        Get-ChildItem -Path "$MaestroResultsDir\*.xml" -ErrorAction SilentlyContinue | ForEach-Object {
            Fix-JUnitXmlForAllure -XmlPath $_.FullName
        }
        
        # Set report metadata
        $allureProps = "$MaestroResultsDir\allure.properties"
        "allure.execution.name=Maestro Test Execution - $Environment`nallure.execution.build=Build-$Timestamp" | Out-File -FilePath $allureProps -Encoding utf8
        
        Write-Log "Generating Allure report from test results" -Level INFO
        
        & allure generate --clean --single-file -o "$AllureReportDir" "$MaestroResultsDir" 2>&1 | Out-Null
        
        $reportIndexPath = "$AllureReportDir\index.html"
        
        if (Test-Path -Path $reportIndexPath) {
            Write-Log "Allure report generated successfully" -Level SUCCESS
            Write-Log "Report location: $reportIndexPath" -Level SUCCESS
            return $reportIndexPath
        }
        else {
            Write-Log "Allure report generation failed" -Level ERROR
            return $null
        }
    }
    catch {
        Write-Log "Failed to generate Allure report: $_" -Level ERROR
        return $null
    }
}

function CreatePipelineSummary {
    param(
        [hashtable]$TestResults,
        [string]$AllureReportPath
    )
    
    Write-Host ""
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host "STEP 12: CREATE EXECUTION SUMMARY" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor Cyan
    Write-Host ""
    
    $summaryContent = "================================================================`n"
    $summaryContent += "CRYOTOS MAESTRO CI/CD PIPELINE EXECUTION SUMMARY`n"
    $summaryContent += "================================================================`n"
    $summaryContent += "Execution Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`n"
    $summaryContent += "Environment: $Environment`n"
    $summaryContent += "Config Type: $ConfigType`n"
    $summaryContent += "Execution ID: $Timestamp`n`n"
    
    $summaryContent += "BUILD PHASE:`n"
    $summaryContent += "- Build directory prepared`n"
    $summaryContent += "- Repository cloned: cmms_flutter`n"
    $summaryContent += "- Flutter setup completed`n"
    $summaryContent += "- Environment switched to: $Environment`n`n"
    
    $summaryContent += "DEPLOYMENT PHASE:`n"
    $summaryContent += "- Emulator started and stabilized`n"
    $summaryContent += "- Old application uninstalled: $AppPackageName`n"
    $summaryContent += "- New application installed: $AppPackageName`n"
    $summaryContent += "- Keyboard configured: ADB Keyboard`n`n"
    
    $summaryContent += "TEST EXECUTION PHASE:`n"
    $summaryContent += "- Test scripts updated`n"
    
    $regressionStatus = if ($TestResults['regression']) { 'PASSED' } else { 'FAILED' }
    $integrationStatus = if ($TestResults['integration']) { 'PASSED' } else { 'FAILED' }
    $e2eStatus = if ($TestResults['e2e']) { 'PASSED' } else { 'FAILED' }
    
    $summaryContent += "- Regression tests: $regressionStatus`n"
    $summaryContent += "- Integration tests: $integrationStatus`n"
    $summaryContent += "- End-to-end tests: $e2eStatus`n`n"
    
    $summaryContent += "REPORTING PHASE:`n"
    $summaryContent += "- Test reports verified`n"
    $summaryContent += "- Allure report generated`n`n"
    
    $summaryContent += "TEST RESULTS:`n"
    $summaryContent += "- Regression Report: $MaestroResultsDir\regression-report.xml`n"
    $summaryContent += "- Integration Report: $MaestroResultsDir\integration-report.xml`n"
    $summaryContent += "- End-to-End Report: $MaestroResultsDir\end-to-end-report.xml`n"
    $summaryContent += "- Allure Report: $AllureReportPath`n`n"
    
    $summaryContent += "LOGS DIRECTORY:`n"
    $summaryContent += "$LogsDir`n`n"
    
    $summaryContent += "Emulator Logs: $EmulatorLogFile`n"
    $summaryContent += "Pipeline Summary: $PipelineSummaryLogFile`n"
    $summaryContent += "================================================================`n"
    
    Add-Content -Path $PipelineSummaryLogFile -Value $summaryContent
    
    Write-Log "Pipeline summary created: $PipelineSummaryLogFile" -Level SUCCESS
    Write-Host $summaryContent
}

function ShowFinalStatus {
    param(
        [bool]$Success,
        [string]$AllureReportPath
    )
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    
    if ($Success) {
        Write-Host "PIPELINE EXECUTION COMPLETED SUCCESSFULLY" -ForegroundColor Green
        Write-Host ""
        Write-Host "KEY OUTPUTS:" -ForegroundColor Green
        Write-Host "  Allure Report: $AllureReportPath" -ForegroundColor Green
        Write-Host "  Logs Directory: $LogsDir" -ForegroundColor Green
        Write-Host "  Test Results: $MaestroResultsDir" -ForegroundColor Green
    }
    else {
        Write-Host "PIPELINE EXECUTION FAILED" -ForegroundColor Red
        Write-Host ""
        Write-Host "Check logs for details:" -ForegroundColor Red
        Write-Host "  Pipeline Summary: $PipelineSummaryLogFile" -ForegroundColor Red
        Write-Host "  Emulator Logs: $EmulatorLogFile" -ForegroundColor Red
    }
    
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

function InvokePipeline {
    try {
        # STEP 1: Start emulator FIRST (parallel with other setup)
        Start-EmulatorWithLogging
        
        Initialize-Pipeline
        Prepare-Directories
        Prepare-GitRepositories
        Switch-Environment
        Setup-Flutter
        $builtApkPath = Build-Flutter
        Write-Log "Build-Flutter returned: '$builtApkPath'" -Level INFO

        # STEP 2: Verify ADB connection (emulator should be fully booted by now)
        Write-Host ""
        Write-Host "----------------------------------------" -ForegroundColor Cyan
        Write-Host "VERIFY ADB CONNECTIVITY" -ForegroundColor Cyan
        Write-Host "----------------------------------------" -ForegroundColor Cyan
        Write-Host ""
        $devices = & adb devices 2>&1
        Write-Host "ADB Devices Output:"
        $devices | ForEach-Object { Write-Host $_ }
        
        # Check if any line contains "emulator-" and "device" (simple string match, more reliable)
        $deviceDetected = $devices | Where-Object { $_ -like "*emulator-*device*" -and $_ -notlike "*offline*" -and $_ -notlike "*unauthorized*" }
        if (-not $deviceDetected) {
            Write-Host "Devices array content (debug):" -ForegroundColor Yellow
            $devices | ForEach-Object { Write-Host "  [$_]" -ForegroundColor Yellow }
            throw "CRITICAL: Emulator is running but ADB cannot detect it. Output: $($devices -join '; ')"
        }
        Write-Log "ADB connection verified: $($deviceDetected -join ', ')" -Level SUCCESS
        
        # STEP 3: Install and test
        Uninstall-OldApplication
        Install-Application -ApkPath $builtApkPath
        Configure-InputMethod
        
        $testResults = ExecuteMaestroTests
        
        $reportsExist = VerifyTestReports
        $allureReportPath = GenerateAllureReport
        
        CreatePipelineSummary -TestResults $testResults -AllureReportPath $allureReportPath
        ShowFinalStatus -Success $reportsExist -AllureReportPath $allureReportPath
        
        return $reportsExist
    }
    catch {
        Write-Log "Pipeline execution failed: $_" -Level ERROR
        
        $failureLog = "================================================================`n"
        $failureLog += "PIPELINE EXECUTION FAILED`n"
        $failureLog += "================================================================`n"
        $failureLog += "Error: $_`n"
        $failureLog += "Timestamp: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`n"
        $failureLog += "Environment: $Environment`n"
        $failureLog += "Config Type: $ConfigType`n`n"
        $failureLog += "Check logs:`n"
        $failureLog += "- Emulator: $EmulatorLogFile`n"
        $failureLog += "- Summary: $PipelineSummaryLogFile`n"
        $failureLog += "================================================================`n"
        
        # Ensure log directory exists before writing
        $logDir = Split-Path -Parent $PipelineSummaryLogFile
        if (-not (Test-Path -Path $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }
        Add-Content -Path $PipelineSummaryLogFile -Value $failureLog -ErrorAction SilentlyContinue
        
        ShowFinalStatus -Success $false -AllureReportPath "N/A"
        exit 1
    }
}

$success = InvokePipeline
if (-not $success) {
    exit 1
}
exit 0