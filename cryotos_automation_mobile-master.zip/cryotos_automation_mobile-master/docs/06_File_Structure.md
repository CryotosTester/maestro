# CMMS Mobile Testing Project - File Structure

This document provides a comprehensive overview of the file structure for the CMMS Mobile Testing Project, helping Cursor understand the organization and relationships between project components.

## Project Root Structure

```
CMMS_Testing_Project/
├── README.md                      # Project overview and navigation guide
├── 01_Project_Overview.md         # System architecture and testing strategy
├── 02_Core_Modules.md             # Detailed module specifications
├── 03_Test_Suite_Architecture.md  # Test types and prioritization
├── 04_CMMS_Definitions.md         # Key terminology and concepts
├── 05_Maestro_Testing_Examples.md # Example test scripts
└── 06_File_Structure.md           # This file - structure documentation
```

## Conceptual Structure

The project is organized in layers of increasing specificity:

```
CMMS Mobile Testing Project
│
├── System Architecture            # The application being tested
│   ├── Flutter Mobile App         # iOS & Android platforms
│   ├── Web Portal                 # Admin interface
│   └── Bidirectional Data Flow    # Synchronization mechanism
│
├── Core Modules                   # Functional areas to test
│   ├── Work Order Management      # WO creation, tracking, completion
│   ├── Schedule Management        # Preventive maintenance planning
│   ├── Dynamic Form Fields        # 23+ field types and validation
│   ├── Conditional Fields         # Trigger-based field appearance
│   ├── Meter Reading              # Equipment monitoring
│   ├── Work Request               # Initial maintenance requests
│   └── Client Implementations     # Customer-specific features
│
└── Testing Framework              # Testing approach and tools
    ├── Maestro Testing Tools      # Primary automation framework
    │   ├── inspect_view_hierarchy # UI analysis
    │   ├── query_docs             # Documentation queries
    │   └── run_flow               # Test execution
    │
    └── Test Suites                # Organized by priority
        ├── Smoke Tests            # Critical path validation
        ├── Regression Tests       # Feature validation
        ├── Integration Tests      # Cross-module testing
        ├── End-to-End Tests       # User journey validation
        └── Performance Tests      # Speed and responsiveness
```

## Module Relationships

This diagram illustrates how the different modules interact within the application:

![[Conditional Flow Diagram .jpg]]

Key points about this flow:
1. Work requests can be converted to work orders
2. Both work order and schedule use dynamic forms/workflow system
3. Schedule is for preventive maintenance, while work order/work request is for breakdown maintenance
4. Meter threshold conditions will NOT automatically trigger work orders or requests by default - this requires explicit configuration
5. There is no direct conversion from schedule to work order

## Testing Pyramid

The testing strategy follows this distribution:

```
        ╔════════════════╗
        ║  E2E Tests     ║  40% - Critical user journeys
        ╠════════════════╣
        ║Integration Tests║  30% - Module interactions
        ╠════════════════╣
        ║  Smoke Tests     ║  30% - Component validation
        ╚════════════════╝
```

## Maestro Test File Organization

For implementation, Maestro test files would be organized as:

```
maestro_tests/
├── smoke/                  # Quick validation tests (<5 mins)
│   ├── login.yaml          # Basic login functionality
│   ├── work_order.yaml     # Simple work order creation
│   └── meter_reading.yaml  # Basic meter reading submission
│
├── regression/             # Comprehensive feature tests
│   ├── work_order/         # Work order specific tests
│   │   ├── creation.yaml   # Different creation paths
│   │   ├── workflow.yaml   # Status transitions
│   │   └── fields.yaml     # Form field validation
│   │
│   ├── schedule/           # Schedule specific tests
│   │   └── ...
│   │
│   └── ...                 # Other module tests
│
├── integration/            # Cross-platform tests
│   ├── web_to_mobile.yaml  # Web created, mobile handled
│   └── mobile_to_web.yaml  # Mobile created, web handled
│
└── end-to-end/                    # End-to-end user journeys
    ├── complete_maintenance.yaml  # Full maintenance flow
    └── meter_to_work_order.yaml   # Trigger-based workflows
```

## Test Data Structure

Test data would be organized as:

```
test_data/
├── users/               # Test user credentials
│   ├── admin.json       # Admin users
│   ├── technicians.json # Field technicians
│   └── requesters.json  # Request creators
│
├── assets/              # Test equipment data
│   ├── pumps.json       # Pump equipment
│   └── hvac.json        # HVAC equipment
│
├── locations/           # Test location data
│   └── buildings.json   # Building and room data
│
└── media/               # Test images and files
    ├── photos/          # Equipment photos
    └── documents/       # Test attachments
```

## Implementation Notes for Cursor

When implementing this project structure:

1. All Maestro test files (.yaml) should follow the same pattern for consistency
2. Test files should import common functions from shared utility files
3. Test data should be externalized to support testing different environments
4. Each test should be independent and not rely on state from other tests
5. The structure supports parallel test execution for faster feedback
6. Tests should be tagged for selective execution (smoke, regression, etc.)

This structure provides a clear organization that Cursor can use to navigate and understand the project, making it easier to implement and maintain the testing framework.


maestro-tests/
│
├── 📁 elements/                           # JavaScript Page Objects
│   ├── auth/
│   │   ├── login.js
│   │   └── logout.js
│   │
│   ├── work-order/
│   │   ├── create-work-order.js
│   │   ├── acknowledge-work-order.js
│   │   ├── labor-cost.js
│   │   ├── inventory.js
│   │   └── asset-downtime.js
│   │
│   ├── schedule/
│   │   ├── create-schedule.js
│   │   └── update-schedule.js
│   │
│   ├── work-request/
│   │   ├── create-wr.js
│   │   ├── approval-wr.js
│   │   └── dynamic-fields.js
│   │
│   ├── meter-reading/
│   │   ├── meter-list.js
│   │   ├── reading-entry.js
│   │   └── threshold-validation.js
│   │
│   ├── form-fields/
│   │   ├── text-inputs.js                # Text, TextArea, Number
│   │   ├── media-fields.js               # Image, Video, File Upload
│   │   ├── signature-fields.js           # Signature with/without Satisfactory
│   │   ├── table-fields.js               # Table, Dynamic Table
│   │   ├── selection-fields.js           # Dropdown, Radio, Checkbox, Toggle
│   │   ├── date-fields.js                # Date, DateTime
│   │   └── conditional-fields.js         # Conditional unhides logic
│   │
│   └── common/
│       ├── navigation.js
│       ├── sync-status.js
│       └── error-messages.js
│
├── 📁 flows/                              # Test Cases by Module
│   │
│   ├── auth/
│   │   ├── login-valid.yaml
│   │   ├── login-invalid.yaml
│   │   ├── logout.yaml
│   │   └── session-timeout.yaml
│   │
│   ├── work-order/
│   │   # Basic Operations
│   │   ├── create-basic-wo.yaml
│   │   ├── create-wo-all-fields.yaml
│   │   ├── wo-acknowledge.yaml
│   │   ├── wo-update-status.yaml
│   │   ├── wo-close.yaml
│   │   │
│   │   # Advanced Features
│   │   ├── wo-with-gps-checkin.yaml
│   │   ├── wo-with-labor-cost.yaml
│   │   ├── wo-with-inventory.yaml
│   │   ├── wo-asset-downtime-form.yaml
│   │   ├── wo-asset-downtime-last.yaml
│   │   │
│   │   # Multi-User Workflows
│   │   ├── wo-multi-user-flow.yaml       # A→B→C complete flow
│   │   ├── wo-reassign.yaml
│   │   │
│   │   # Negative Tests
│   │   ├── wo-missing-required.yaml
│   │   ├── wo-invalid-asset.yaml
│   │   └── wo-permission-denied.yaml
│   │
│   ├── schedule/
│   │   ├── create-schedule.yaml
│   │   ├── create-recurring-schedule.yaml
│   │   ├── schedule-view-dashboard.yaml
│   │   ├── schedule-acknowledge.yaml
│   │   ├── schedule-checkin-gps.yaml
│   │   ├── schedule-complete.yaml
│   │   └── schedule-invalid-date.yaml
│   │
│   ├── work-request/
│   │   # Basic Operations
│   │   ├── wr-create-asset-based.yaml
│   │   ├── wr-create-location-based.yaml
│   │   ├── wr-priority-validation.yaml
│   │   ├── wr-with-attachments.yaml
│   │   │
│   │   # Dynamic Fields
│   │   ├── wr-dynamic-number.yaml
│   │   ├── wr-dynamic-datetime.yaml
│   │   ├── wr-dynamic-dropdown.yaml
│   │   │
│   │   # Client Specific
│   │   ├── wr-dfi-quotation.yaml
│   │   │
│   │   # Negative Tests
│   │   ├── wr-invalid-priority.yaml
│   │   └── wr-large-file-upload.yaml
│   │
│   ├── meter-reading/
│   │   ├── meter-list-view.yaml
│   │   ├── meter-basic-entry.yaml
│   │   ├── meter-accumulator-reading.yaml
│   │   ├── meter-accumulator-reset.yaml
│   │   ├── meter-threshold-violation.yaml
│   │   ├── meter-trigger-wr.yaml         # Trigger Work Request
│   │   ├── meter-trigger-wo.yaml         # Trigger Work Order
│   │   ├── meter-invalid-range.yaml
│   │   ├── meter-non-numeric.yaml
│   │   └── meter-extreme-values.yaml
│   │
│   ├── form-fields/
│   │   # Testing all 23 field types
│   │   ├── field-text-input.yaml
│   │   ├── field-text-area.yaml
│   │   ├── field-number.yaml
│   │   ├── field-dropdown.yaml
│   │   ├── field-radio.yaml
│   │   ├── field-checkbox.yaml
│   │   ├── field-table.yaml
│   │   ├── field-image-annotation.yaml
│   │   ├── field-image-upload.yaml
│   │   ├── field-file-upload.yaml
│   │   ├── field-video.yaml
│   │   ├── field-signature-satisfactory.yaml
│   │   ├── field-signature-only.yaml
│   │   ├── field-satisfactory-only.yaml
│   │   ├── field-toggle.yaml
│   │   ├── field-toggle-reason.yaml
│   │   ├── field-datetime.yaml
│   │   ├── field-date.yaml
│   │   ├── field-hyperlink.yaml
│   │   ├── field-static-link.yaml
│   │   ├── field-yes-no-na.yaml
│   │   └── field-pass-fail-na.yaml
│   │
│   ├── conditional/
│   │   # Conditional Logic Testing
│   │   ├── condition-number-less.yaml
│   │   ├── condition-number-greater.yaml
│   │   ├── condition-number-equal.yaml
│   │   ├── condition-dropdown-unhide.yaml
│   │   ├── condition-radio-unhide.yaml
│   │   ├── condition-checkbox-unhide.yaml
│   │   └── condition-audit-workflow.yaml
│   │
│   ├── client-specific/
│   │   ├── dfi-quotation-module.yaml
│   │   ├── lincoln-asset-creation.yaml
│   │   ├── topcon-service-report.yaml
│   │   └── nus-custom-dashboard.yaml
│   │
│   └── common/
│       # Reusable Components Only
│       ├── login.yaml
│       ├── logout.yaml
│       ├── gps-checkin.yaml
│       ├── take-photo.yaml
│       ├── capture-signature.yaml
│       ├── select-asset.yaml
│       ├── select-location.yaml
│       ├── add-attachment.yaml
│       └── wait-for-sync.yaml
│
├── 📁 tests/                              # Test Suites (Orchestration)
│   │
│   ├── smoke/                            # <5 minutes
│   │   ├── smoke-critical-path.yaml      # Login→Create WO→View→Logout
│   │   ├── smoke-wo-basic.yaml
│   │   ├── smoke-wr-basic.yaml
│   │   ├── smoke-schedule.yaml
│   │   └── smoke-meter.yaml
│   │
│   ├── regression/
│   │   ├── regression-work-order.yaml    # All WO test cases
│   │   ├── regression-schedule.yaml
│   │   ├── regression-work-request.yaml
│   │   ├── regression-meter.yaml
│   │   ├── regression-all-fields.yaml    # All 23 field types
│   │   └── regression-conditional.yaml   # All conditional logic
│   │
│   ├── integration/
│   │   ├── web-to-mobile-wo.yaml        # Create on web, complete on mobile
│   │   ├── mobile-to-web-wr.yaml
│   │   ├── offline-sync.yaml
│   │   ├── multi-user-workflow.yaml
│   │   └── cross-module-flow.yaml       # WR→WO→Schedule
│   │
│   ├── end-to-end/
│   │   ├── complete-maintenance-cycle.yaml
│   │   ├── emergency-wo-flow.yaml
│   │   └── scheduled-maintenance.yaml
│   │
│   └── negative/
│       ├── negative-all-modules.yaml
│       ├── network-failures.yaml
│       ├── permission-errors.yaml
│       └── data-validation-errors.yaml
│
├── 📁 data/
│   ├── test-users.yaml
│   ├── test-assets.yaml
│   ├── test-locations.yaml
│   ├── meter-data.yaml
│   ├── field-test-data.yaml             # Test data for all 23 fields
│   └── environments/
│       ├── dev.yaml
│       ├── staging.yaml
│       └── prod.yaml
│
├── 📁 scripts/
│   ├── run-smoke.sh                     # maestro test tests/smoke/
│   ├── run-regression.sh
│   ├── run-platform.sh                  # iOS vs Android
│   └── generate-report.js
│
├── config.yaml
├── .maestroignore
└── README.md