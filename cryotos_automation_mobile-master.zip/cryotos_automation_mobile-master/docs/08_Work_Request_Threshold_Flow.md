# Work Request Straight Line Threshold Condition Flow

This document defines the direct, straight-line threshold condition flow for work requests, similar to work orders but specifically designed for work request creation.

## Straight Line Flow Diagram

```
┌─────────────────┐    ┌──────────────────────┐    ┌─────────────────┐
│                 │    │                      │    │                 │
│   Meter Reading │───▶│  Threshold Condition │───▶│  Work Request   │
│                 │    │                      │    │                 │
└─────────────────┘    └──────────────────────┘    └─────────────────┘
```

## Detailed Flow Process

### 1. Meter Reading Input
- **Trigger**: Meter reading exceeds configured threshold
- **Validation**: System validates reading against predefined limits
- **Configuration**: Threshold action must be set to "Create Work Request"

### 2. Threshold Condition Check
- **Condition**: Reading value > Threshold Value
- **Action**: Automatic work request creation
- **Configuration**: Must be explicitly configured (not default behavior)

### 3. Work Request Creation
- **Automatic Generation**: System creates work request without manual intervention
- **Pre-filled Data**: 
  - Asset information from meter reading
  - Priority level (configurable)
  - Description (auto-generated based on threshold violation)
  - Location data
  - Timestamp of threshold violation

## Configuration Requirements

### Threshold Configuration
```yaml
Meter Configuration:
  - Meter ID: P-101-FLOW
  - Threshold Value: 1500.0
  - Unit: GPM (Gallons Per Minute)
  - Action Type: Create Work Request
  - Priority: NORMAL/URGENT/CRITICAL
  - Auto-Assignment: Enabled/Disabled
```

### Work Request Template
```yaml
Work Request Template:
  - Title: "Threshold Exceeded: {Meter Name}"
  - Description: "Meter reading {current_value} {unit} exceeds threshold {threshold_value} {unit}"
  - Priority: {Configured Priority}
  - Asset: {Meter Asset}
  - Location: {Asset Location}
  - Contact: {System Generated}
  - Created By: System
  - Created Date: {Current Timestamp}
```

## Straight Line Process Steps

### Step 1: Meter Reading Submission
1. User submits meter reading
2. System validates reading format
3. System compares reading to threshold

### Step 2: Threshold Evaluation
1. If reading > threshold:
   - Trigger threshold action
   - Generate work request
2. If reading ≤ threshold:
   - Log reading normally
   - No action taken

### Step 3: Work Request Generation
1. Create work request with pre-filled data
2. Assign priority based on configuration
3. Generate descriptive text
4. Link to originating meter/asset
5. Set status to "Open"

### Step 4: Notification
1. Notify assigned technician (if auto-assignment enabled)
2. Send email notification to maintenance team
3. Update dashboard counters

## Key Differences from Work Order Flow

| Aspect | Work Request Threshold | Work Order Threshold |
|--------|----------------------|---------------------|
| **Purpose** | Initial maintenance request | Formal work authorization |
| **Approval** | No approval required | May require approval |
| **Assignment** | Optional auto-assignment | Usually requires assignment |
| **Priority** | Configurable priority | Usually higher priority |
| **Workflow** | Simple straight line | May involve multiple steps |
| **Documentation** | Basic information | Comprehensive documentation |

## Implementation Requirements

### System Configuration
- Threshold action must be set to "Create Work Request"
- Work request template must be configured
- Priority mapping must be defined
- Auto-assignment rules must be set (optional)

### Data Requirements
- Meter must be linked to an asset
- Asset must have valid location data
- Threshold values must be properly configured
- Work request form fields must be mapped

### Validation Rules
- Reading must be numeric
- Threshold must be positive number
- Asset must be active
- Location must be valid

## Testing Scenarios

### Scenario 1: Normal Threshold Exceeded
- **Input**: Reading = 1550.5, Threshold = 1500.0
- **Expected**: Work request created with URGENT priority
- **Validation**: Check work request details and notifications

### Scenario 2: Critical Threshold Exceeded
- **Input**: Reading = 2000.0, Threshold = 1500.0
- **Expected**: Work request created with CRITICAL priority
- **Validation**: Check priority assignment and escalation

### Scenario 3: Threshold Not Exceeded
- **Input**: Reading = 1200.0, Threshold = 1500.0
- **Expected**: No work request created
- **Validation**: Verify normal meter reading logging

## Benefits of Straight Line Flow

1. **Immediate Response**: Instant work request creation when threshold exceeded
2. **Reduced Manual Work**: No human intervention required for initial request
3. **Consistent Process**: Standardized work request format
4. **Faster Resolution**: Quicker response to equipment issues
5. **Audit Trail**: Complete tracking from meter reading to work request

## Configuration Examples

### Example 1: Pump Flow Meter
```yaml
Meter: P-101-FLOW
Threshold: 1500.0 GPM
Action: Create Work Request
Priority: URGENT
Template: "Pump P-101 flow rate exceeds normal operating parameters"
```

### Example 2: Temperature Sensor
```yaml
Meter: T-205-TEMP
Threshold: 85.0 °C
Action: Create Work Request
Priority: CRITICAL
Template: "Temperature sensor T-205 reading indicates overheating condition"
```

### Example 3: Pressure Gauge
```yaml
Meter: PR-301-PRESSURE
Threshold: 200.0 PSI
Action: Create Work Request
Priority: NORMAL
Template: "Pressure gauge PR-301 reading exceeds recommended operating pressure"
```

This straight line threshold condition flow ensures immediate work request creation when meter readings exceed configured thresholds, providing a direct path from equipment monitoring to maintenance request without intermediate steps.
