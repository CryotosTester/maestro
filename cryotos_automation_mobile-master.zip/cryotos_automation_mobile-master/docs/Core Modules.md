#testcases 
Work Order (1)
==============
- create work order on mobile (**asset or location based**)
   1) labor cost (optional in any form) **( Yet To start )**
   2) meter (any form) (but configured in workflow) (once configured we should fill the meter )**(progress)**
   3) inventory (optional in any form)**(progress)**
- view work order count in main dashboard
- once click any status in work order dashboard it navigate to list base where can find list of wo related to status if status not closed or rejected we can take and update the form
- check-in (enable gps on work order ) - **(progress)**
- acknowledge - **done**
- labor cost 
- inventory addition **(progress)**
- asset down time tracking **(progress)**
    1) form based 
    2) last form workorder close submission 
   these two options are workflow configuration based . if we choose particular form then it will visible on particular form only if we chooses the last form then it will visible in last form of workflow before workorder completion 
- Multi Form Flow  **(progress)**
     - user a create wo assign to user b 
     - user b login ack and update form assign to user c and log out
     - user c login ack and update the form to close 

```
Schedule (2)
===========
- view Schedule  count in main dashboard
- once click any status in Schedule dashboard it navigate to list base where can find list of Schedule related to status if status not closed or rejected we can take and update the form
- check-in (enable gps  )
- acknowledge
- labor cost 
- inventory addition 
- Multi Form Flow
```


 ### **Workflow Form Field Is for Both WORK ORDER AND SCHEDULE's**
 =========================================== 
1. ==**Text Input** - For single-line text entry== 
     ==i) set as default (default visible)==
     ==ii) mandatory==
     ==iii) Text Length==
2. ==**Text Area** - For multi-line text entry==
     ==i) set as default (default visible)==
     ==ii) mandatory==
     ==iii) Text Length==
3. ==**Number Input** - For numeric values only==
     ==i) mandatory==
4. **Drop Down** - For selection from a predefined list 
     i)mandatory
5. **Radio Button** - For single selection from options
      i) mandatory
6. **Checkbox** - For multiple selection options
       i) mandatory
7. ==**Table** - For structured data in rows and columns (mandatory)==
8. **Dynamic Table** - For expandable table structures [skip as of now]
9. **Dynamic Drop Down** - For context-sensitive selection lists [skip as of now]
10. **Image With Annotation** - For uploading images with markup capability
     i) mandatory
     ii) Camera Only
11. **Images** - For standard image uploads
      i) mandatory
12. **File upload** - For document attachment
     i) mandatory
13. **Video** - For video file uploads
     i) mandatory
14. **Signature with Satisfactory** - For digital signatures with approval status
      i) mandatory
15. **Signature Only** - For digital signatures without additional options
     i) mandatory
16. **Satisfactory Only** - For approval status without signature
      i) mandatory
17. **Toggle** - For binary yes/no selection [id field issue ]
      i) mandatory
18. **Toggle With Reason** - For binary selection with explanation field [id field issue ]
      i) set as default
19. **Date And Time** - For datetime selection ( Helper Js with Yaml )
      i) mandatory
20. **Date** - For date-only selection  ( Helper Js with Yaml )
       i) mandatory
21. **Hyperlink** - For clickable URLs
22. **StaticLink** - For non-editable links
23. **Yes/No/N/A** and **Pass/Fail/N/A** - For standardized response options

  **Common Options for All Fields:** 
  
- **Mandatory** toggle - When enabled, the field must be completed before form submission
- **Label** configuration - Custom text to identify the field
- Field-specific settings menu (three dots icon)

**Conditional Fields For Work Order **  ( **Yet To start** )
1. number field ()
   Configuration Conditions 
    1) less then 
    2) greater then 
    3) equal 
   Choose Workflow
   if condition satisfied based on configured workflow,  work order will create and assign to current user (who enter the current value)
2. Audit Field (Dynamic Audit Field )(**Yes/No/N/A**)
     Configuration Conditions 
      1) value == Yes {choose workflow}
      2) value == No {choose workflow}
      3)  value == N/A {choose workflow}
    same like number filed we can configure text is equals
    once condition is achieved we can triggers to create the work order based on configuration
**Conditional Fields For Section Unhides**    ( **Yet To start** )
3. Drop Down  
4. Radio Button 
5. Check Box
6. Audit Field
   these fields has conditional section unhide if user specify condition is satisfied then section will appears on next  
```text 
    each workflow -> n of forms and each form configured to user or usergroup 
    each form -> n of sections 
    each section -> n of fields 
```
if one condition satisfies relevant section will appears

---

Cross Platform Testing (3)
==========================
Integration Testing POC  [Exiting Java Testing Script Work Along With Maestro Yamal Script]
Web to Mobile (Mobile to Web) Bi Directional Flow Testing  
- Work Order 
- Schedule 
For EX
**wo**
   create work order in web and assigns to mobile user 
   mobile user logins in mobile and update the form submit to portal user 
   portal user login in web and close the wo
schedule 
   same like work order schedule also need to test flow test 
   
### Meter Reading Functionality (4) 
==========================
- Meter list display and filtering  ( **Yet To start** )
- Reading entry for various unit types
- Threshold validation for all meter types
- Accumulator Reading 
    1) accumulator reading  resets after predefined value 
- Trigger Reached  (once threshold range reached based on config it will create work request or work order  )
    1) work request 
    2) work order 
### Meter Reading Negative Test Cases

- Invalid reading entry (out of range values)
- Non-numeric entry in numeric fields
- Extreme value entry (very large/small numbers)

Work Request (5) 
=================
- asset based 
- location based
- priority validation 
- Dynamic Form Fields 
- Attachment Handling
- work request to work order converstion once work order closed we should check status is refelcting in work request 
 Additional Dynamic Fields (all field make config optional or mandatory )
    1) Number Input Form 
    2) Date And Time 
    3) Drop Down 
    4) Text Input 
1
**Negative Cases Alone Pending** 
    
### Mobile App Client  Specific Implementation  (6)
============================================
1) Work Request Quotation Module  **[ DFI,POWERMAC ]**
2) Asset Creation **[Lincoln]** 
     - Option to Create Asset  While Creating Work order 
3) Service Report Module **[Top Con]**
4) NUS - Custom Dashboard (Still Working We Might Omit now)
