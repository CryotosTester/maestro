# CMMS Key Definitions

## Work Order

A Work Order in the CMMS context is a formal document or digital record that authorizes and directs maintenance personnel to perform specific maintenance tasks. The work order system serves as the operational backbone of maintenance management, transforming maintenance needs from initial requests into actionable, trackable tasks.

### Key Characteristics:

- **Comprehensive Documentation**:
  - Rich media attachments (PDFs, photos with annotations, videos)
  - Detailed cost breakdown (labor, space, miscellaneous expenses)
  - Multiple file attachments

- **Workflow Integration**:
  - Automated and intelligent workflows
  - Strategic task management for priority-based handling
  - Customizable workflows with detailed checklists

- **Communication and Coordination**:
  - Built-in messaging tools
  - Integrated chat functions
  - Real-time progress updates

- **Resource Management**:
  - Optimized employee deployment
  - Inventory integration
  - Advanced schedule planning

- **Quality and Compliance**:
  - SLA tracking and escalation
  - Warranty tracking
  - Employee presence verification (QR codes, GPS, NFC, camera selfies)

### Business Impact:
- 30% Reduction in Downtime
- 275% Increase in ROI
- 15% Increase in Asset Lifespan
- 25% Decrease in Repair Times

## Work Request

A Work Request is a formal submission within a CMMS that allows employees or stakeholders to report maintenance issues and request maintenance services. It serves as the initial step in the maintenance workflow, enabling users to document problems, equipment failures, or maintenance needs.

### Key Characteristics:

- **Primary Function**: Allows employees or stakeholders to submit maintenance requests directly to the CMMS

- **Information Capture**:
  - Specific issue details
  - Urgency level and priority classification
  - Location information (longitude, latitude, timestamps)
  - Photographic documentation
  - Asset identification (QR code scanning)

- **Creation Methods**:
  - AI-enhanced creation (photo analysis, automatic descriptions)
  - Traditional web interface
  - Mobile applications
  - WhatsApp integration
  - QR code scanning for public requests

### Business Impact:
- Faster resolution times and improved asset uptime
- Enhanced communication across teams
- Seamless workflow integration
- 30% downtime reduction and 25% repair time decrease

### Conversion Process:
Work requests serve as the foundation for creating actionable work orders. Once submitted, they undergo evaluation by maintenance teams who can convert them into formal work orders for execution.

## Schedule

A Schedule in CMMS refers to a planned maintenance task or set of tasks to be performed at specified intervals or dates. These are typically preventive in nature and aim to maintain equipment before failures occur.

### Key Characteristics:

- Dashboard integration showing schedule counts by status
- Status-based navigation to related lists
- Support for recurring maintenance patterns
- Multi-form workflow capabilities
- Resource allocation including labor and inventory

## Meter Reading

Meter Reading functionality allows for monitoring and recording various measurements from equipment or assets to track usage, performance, and trigger maintenance actions.

### Key Characteristics:

- Support for various unit types
- Threshold validation to identify out-of-range values
- Accumulator reading with reset capability
- Automated trigger system to create work requests/orders when thresholds are reached
- Validation controls for data accuracy