# CMMS Core Modules

## 1. Work Order Management

- **Creation Types**: Asset-based or location-based
- **Key Features**:
  - GPS check-in functionality
  - Acknowledgment system
  - Labor cost tracking
  - Inventory addition
  - Asset downtime tracking
  - Multi-form workflow support
- **User Flow Example**:
  - User A creates WO, assigns to User B
  - User B acknowledges, updates form, assigns to User C
  - User C acknowledges, updates form to close
- **Dashboard Integration**: 
  - View work order count in main dashboard
  - Click on status to navigate to list of related work orders
  - Editable if status is not closed or rejected

## 2. Schedule Management

- **Dashboard Integration**: View schedule count in main dashboard
- **Status Navigation**: Click on status to view related schedules
- **Core Functionality**:
  - GPS check-in
  - Acknowledgment system
  - Labor cost tracking
  - Inventory addition
  - Multi-form workflow support

## 3. Dynamic Form Fields (Both Work Order & Schedule)

- **23+ Field Types** including:
  - Text Input/Area
  - Number Input
  - Drop Down
  - Radio Button
  - Checkbox
  - Tables (standard & dynamic)
  - Image With Annotation
  - Images
  - File Upload
  - Video Upload
  - Signature (with/without satisfactory options)
  - Toggle and Toggle With Reason
  - Date/Time selectors
  - Hyperlinks and StaticLinks
  - Yes/No/N/A and Pass/Fail/N/A options
- **Common Options**: 
  - Mandatory toggle
  - Custom label configuration
  - Field-specific settings menu (three dots icon)

## 4. Conditional Fields

- **For Work Order Creation**:
  - Number field conditions (less than, greater than, equal)
  - Audit Field conditions (Yes/No/N/A triggers)
  - Workflow selection based on condition satisfaction
  
- **For Section Unhiding**:
  - Drop Down, Radio Button, Check Box, Audit Field triggers
  - Hierarchical structure: workflow → forms → sections → fields
  - Section appears when specified condition is satisfied

## 5. Meter Reading Functionality

- **Core Features**:
  - List display and filtering
  - Reading entry for various unit types
  - Threshold validation for all meter types
  - Accumulator reading with reset capability after predefined value
  - Trigger functionality (creates work request/order when threshold reached)
  
- **Negative Test Cases**:
  - Invalid reading entry (out of range values)
  - Non-numeric entry in numeric fields
  - Extreme value entry (very large/small numbers)

## 6. Work Request

- **Creation Types**:
  - Asset based
  - Location based
  
- **Features**:
  - Priority validation
  - Dynamic Form Fields
  - Attachment Handling
  
- **Additional Dynamic Fields** (all fields configurable as optional or mandatory):
  - Number Input Form
  - Date And Time
  - Drop Down
  - Text Input
  
- **Note**: Negative cases are pending

## 7. Cross Platform Testing

- Integration Testing POC [Existing Java Testing Script Work Along With Maestro YAML Script]
- Web to Mobile (Mobile to Web) Bi-Directional Flow Testing:
  - Work Order flow testing
  - Schedule flow testing
  
- **Example Flow**:
  - Create work order in web and assign to mobile user
  - Mobile user logs in via mobile app and updates the form, submits to portal user
  - Portal user logs in via web and closes the work order

## 8. Mobile App Client Specific Implementation

1. Work Request Quotation Module **[DFI]**
2. Asset Creation **[Lincoln]**
   - Option to Create Asset While Creating Work order
3. Service Report Module **[Top Con]**
4. NUS - Custom Dashboard (In progress, may be omitted)