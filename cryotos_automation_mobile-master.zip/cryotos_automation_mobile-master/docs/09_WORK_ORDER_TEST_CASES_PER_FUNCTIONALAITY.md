====#testcases 
WORK ORDER TEST CASES PER FUNCTIONALAITY
==========================================================

1. create work order on mobile
     1. ==Choose Direct Asset Based [1]==  - done
     2. ==Choose Direct Location  [2]== - done
     3. ==Choose Account -> Location -> Asset [3]== - done
     4. 1st Form Save As Draft -> then open and Close [4] 
     5. ==1st Form Add Labor [1]== 
     6. ==1st Form Add Parts [1]
     7. ==Meter Reading Within Workflow== [skip validation] [2]
          i) work request threshold (last preference)[2]
          ii) work order threshold (last preference)[3]
          iii) Normal Meter or Accumulator Meter[1]
2. create wo assigned to another user (login as working user to perform following actions )
     1. ==Acknowledge [6]==  - done
     2. ==Check In [6]== - done
          - GPS
          - QRCODE
          - BYPASS - done
     3. ==Labor [6]== 
     4. ==Parts [6]==
     5. ==Meter Reading Within Workflow== [skip validation]
          i) work request threshold (last preference)
          ii) work order threshold (last preference)
          iii) Normal Meter or Accumulator Meter
     6.  Form Save As Draft and Submit or Close [6]
     7. ==Asset Downtime Tracking==  
          ==i) ask down time on last form before close the WO [7]== - done
          ==ii)ask down time on specified from [8]== - done
3. ==Conditional Fields for Work Order Creation (muti form  required)==
          ==i) Number Field [9]== - Progress
          ==ii) Audit Field [10]== - Progress
4. ==Conditional Fields for section unhide (muti form  required)==
         ==i)  Drop Down  [11]== - Progress
         ==ii) Radio Button [11]== - Progress
         ==iii) Check Box  [11]== - Progress
         ==iv) Audit Field  [11]== - Progress
5. Status Based Test Cases [after create wo assigned to another user for next forms ]
         ==i) Work IN Progress [11] - done== 
         ==ii) Pending With Reason [12]== -easy
         iii)Over Due (Need to Check With Possibility) [13]

![[Core Modules#**Workflow Form Field Is for Both WORK ORDER AND SCHEDULE's**]]


Functionality Work Order 
==============================

|       |                                                   |                   |         |                                |         |
| ----- | ------------------------------------------------- | ----------------- | ------- | ------------------------------ | ------- |
| SI NO | Functionality                                     | Create Work Order | Priorty | Next Form [after WO Creation ] | Priorty |
| 1     | Labour Cost                                       | ✅                 | 1       | ✅                              | 1       |
| 2     | Parts [Inventory Consumption]                     | ✅                 | 1       | ✅                              | 1       |
| 3     | Meter Reading Within Workflow                     |                   |         |                                |         |
|       | i) work request threshold                         | ✅                 | 3       | ✅                              | 3       |
|       | ii) work order threshold                          | ✅                 | 3       | ✅                              | 3       |
|       | iii) Normal Meter or Accumulator Meter            | ✅                 | 3       | ✅                              | 3       |
| 4     | Create  WO Choose Direct Asset Based              | ✅                 | 1       | ❌                              |         |
| 5     | Create WO  Choose Direct Location                 | ✅                 | 1       | ❌                              |         |
| 6     | Create Wo  Choose Account -> Location -> Asset    | ✅                 | 1       | ❌                              |         |
| 7     | Acknowledge                                       | ❌                 |         | ✅                              | 1       |
| 8     | Check In                                          |                   |         |                                |         |
|       | i)GPS                                             | ❌                 |         | ✅                              | 1       |
|       | ii)QRCODE                                         | ❌                 |         | ✅                              | 3       |
|       | iii)ByPass                                        | ❌                 |         | ✅                              | 1       |
| 9     | Asset Downtime Tracking                           |                   |         |                                |         |
|       | i) ask down time on last form before close the WO | ✅                 | 2       | ✅                              | 2       |
|       | ii)ask down time on specified from                | ✅                 | 2       | ✅                              | 2       |
| 10    | Conditional Fields for Work Order Creation        |                   |         |                                |         |
|       | i) Number Field                                   | ✅                 | 3       | ✅                              | 3       |
|       | ii) Audit Field                                   | ✅                 | 3       | ✅                              | 3       |
| 11    | Conditional Fields for section unhide             |                   |         |                                |         |
|       | i)  Drop Down                                     | ✅                 | 3       | ✅                              | 3       |
|       | ii) Radio Button                                  | ✅                 | 3       | ✅                              | 3       |
|       | iii) Check Box                                    | ✅                 | 3       | ✅                              | 3       |
|       | iv) Audit Field                                   | ✅                 | 3       | ✅                              | 3       |
| 12    | Status Based Test Cases                           |                   |         |                                |         |
|       | i) Work IN Progress                               | ❌                 |         | ✅                              | 1       |
|       | ii) Pending With Reason                           | ❌                 |         | ✅                              | 1       |


