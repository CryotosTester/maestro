# Maestro Testing Examples for CMMS Application

This document provides practical Maestro testing examples specifically designed for the CMMS mobile application, covering key modules and scenarios.

## 1. Basic Login Flow Test

```yaml
appId: com.company.cmms
---
# Start the application
- launchApp

# Verify login screen elements
- assertVisible: "Username"
- assertVisible: "Password"
- assertVisible: "Login"

# Login process
- tapOn: "Username"
- inputText: "technician1"
- tapOn: "Password" 
- inputText: "test1234"
- tapOn: "Login"

# Verify successful login
- assertVisible: "Dashboard"
- assertVisible: "Work Orders"
- assertVisible: "Schedules"
```

## 2. Work Order Creation Test

```yaml
appId: com.company.cmms
---
# Start the application (assuming already logged in)
- launchApp

# Navigate to Work Orders
- tapOn: "Work Orders"
- tapOn: "Create New"

# Fill basic work order details
- tapOn: "Title"
- inputText: "Pump Maintenance"
- tapOn: "Description"
- inputText: "Regular maintenance for pump system P-101"

# Select asset-based work order
- tapOn: "Asset Based"
- tapOn: "Select Asset"
- tapOn: "P-101"

# Set priority
- tapOn: "Priority"
- tapOn: "High"

# Add image attachment
- tapOn: "Add Image"
- tapOn: "Take Photo"
- takeScreenshot
- tapOn: "Use Photo"

# Submit the work order
- scroll
- tapOn: "Submit"

# Verify work order creation
- assertVisible: "Work Order Created"
- assertVisible: "Pump Maintenance"
```

## 3. Multi-User Workflow Test

```yaml
appId: com.company.cmms
---
# Part 1: User A creates work order
- launchApp
- tapOn: "Login"
- tapOn: "Username"
- inputText: "userA"
- tapOn: "Password"
- inputText: "passA"
- tapOn: "Login"
- tapOn: "Work Orders"
- tapOn: "Create New"
- tapOn: "Title"
- inputText: "Multi-user flow test"
- tapOn: "Description"
- inputText: "Testing multi-user workflow assignment"
- tapOn: "Assign To"
- tapOn: "userB"
- tapOn: "Submit"
- assertVisible: "Work Order Created"
- tapOn: "Logout"

# Part 2: User B acknowledges and updates
- tapOn: "Username"
- inputText: "userB"
- tapOn: "Password"
- inputText: "passB"
- tapOn: "Login"
- tapOn: "Work Orders"
- tapOn: "Pending"
- tapOn: "Multi-user flow test"
- tapOn: "Acknowledge"
- tapOn: "Update Form"
- tapOn: "Status"
- tapOn: "In Progress"
- tapOn: "Notes"
- inputText: "Started work, assigning to userC for completion"
- tapOn: "Assign To"
- tapOn: "userC"
- tapOn: "Submit"
- assertVisible: "Work Order Updated"
- tapOn: "Logout"

# Part 3: User C completes the work order
- tapOn: "Username"
- inputText: "userC"
- tapOn: "Password"
- inputText: "passC"
- tapOn: "Login"
- tapOn: "Work Orders"
- tapOn: "Assigned"
- tapOn: "Multi-user flow test"
- tapOn: "Acknowledge"
- tapOn: "Update Form"
- tapOn: "Status"
- tapOn: "Complete"
- tapOn: "Completion Notes"
- inputText: "Work completed successfully"
- tapOn: "Submit"
- assertVisible: "Work Order Completed"
```

## 4. GPS Check-in Test

```yaml
appId: com.company.cmms
---
# Navigate to an assigned work order
- launchApp
- tapOn: "Work Orders"
- tapOn: "Assigned"
- tapOn: "Pump Repair #1234"

# Perform GPS check-in
- tapOn: "Check In"
- assertVisible: "Requesting Location"
- assertVisible: "Check-in Successful"
- assertVisible: "Current Location"

# Verify location data recorded
- tapOn: "Location Details"
- assertVisible: "Latitude:"
- assertVisible: "Longitude:"
- assertVisible: "Timestamp:"
```

## 5. Dynamic Form Field Validation Test

```yaml
appId: com.company.cmms
---
# Navigate to a form with multiple field types
- launchApp
- tapOn: "Work Orders"
- tapOn: "Create New"
- tapOn: "Advanced Form"

# Test Text Input
- tapOn: "Equipment Name"
- inputText: "Boiler B-101"
- assertVisible: "Boiler B-101"

# Test Number Input
- tapOn: "Temperature Reading"
- inputText: "95.2"
- assertVisible: "95.2"

# Test Dropdown
- tapOn: "Equipment Type"
- tapOn: "HVAC"
- assertVisible: "HVAC"

# Test Radio Buttons
- tapOn: "Operational Status: Operational"
- assertVisible: "Selected: Operational"

# Test Checkbox
- tapOn: "Safety Check: Fire Extinguisher Present"
- assertVisible: "✓ Fire Extinguisher Present"

# Test Date Picker
- tapOn: "Inspection Date"
- tapOn: "15"  # Assuming current month calendar view
- assertVisible: "Inspection Date: 15/"

# Test Signature
- tapOn: "Technician Signature"
- tapOn: {x: 50%, y: 50%}
- drag: {x: 70%, y: 70%}
- tapOn: "Save Signature"
- assertVisible: "Signature Captured"

# Test Pass/Fail/NA
- tapOn: "Pressure Test: Pass"
- assertVisible: "Selected: Pass"

# Submit form
- scroll
- tapOn: "Submit"
- assertVisible: "Form Submitted Successfully"
```

## 6. Meter Reading Test with Threshold Trigger

```yaml
appId: com.company.cmms
---
# Navigate to Meter Reading module
- launchApp
- tapOn: "Meter Reading"

# Select a specific meter
- tapOn: "Filter"
- tapOn: "Equipment Type"
- tapOn: "Pumps"
- tapOn: "Apply"
- tapOn: "P-101 Flow Meter"

# View threshold configuration
- tapOn: "View Details"
- assertVisible: "Threshold: 1500.0"
- assertVisible: "Action When Threshold Reached: Not Configured"

# Configure threshold action
- tapOn: "Configure Threshold Action"
- tapOn: "Action Type"
- tapOn: "Create Work Request"
- tapOn: "Save Configuration"
- assertVisible: "Configuration Saved"
- tapOn: "Back"

# Enter reading below threshold
- tapOn: "Current Reading"
- inputText: "1250.5"
- tapOn: "Reading Notes"
- inputText: "Regular daily reading, normal operation"
- tapOn: "Submit Reading"

# Verify successful submission without threshold trigger
- assertVisible: "Reading Submitted"
- assertVisible: "Previous: 1230.0"
- assertVisible: "Current: 1250.5"
- assertVisible: "Difference: +20.5"
- assertNotVisible: "Threshold Exceeded"

# Enter reading exceeding threshold
- tapOn: "New Reading"
- tapOn: "Current Reading"
- inputText: "1550.8"
- tapOn: "Reading Notes"
- inputText: "Flow rate exceeding normal parameters"
- tapOn: "Submit Reading"

# Verify threshold action triggered
- assertVisible: "Threshold Exceeded"
- assertVisible: "Work Request Created: P-101 Flow Rate Exceeds Threshold"
- tapOn: "View Request"
- assertVisible: "Work Request Details"
- assertVisible: "Created By: Meter Reading System"
```

## 7. Conditional Field Test

```yaml
appId: com.company.cmms
---
# Navigate to form with conditional fields
- launchApp
- tapOn: "Work Orders"
- tapOn: "Create New"
- tapOn: "Conditional Form Test"

# Trigger section unhide with dropdown
- tapOn: "Equipment Status"
- tapOn: "Failed"
- assertVisible: "Failure Details Section"
- assertVisible: "Failure Type"
- assertVisible: "Failure Description"

# Fill in revealed fields
- tapOn: "Failure Type"
- tapOn: "Mechanical"
- tapOn: "Failure Description"
- inputText: "Bearing failure detected"

# Test number field condition trigger for WO creation
- tapOn: "Operating Hours"
- inputText: "5000"  # Exceeds threshold
- assertVisible: "Threshold Exceeded Alert"
- assertVisible: "Work Order Will Be Generated"
- tapOn: "Confirm"
- assertVisible: "Work Order Created: Preventive Maintenance Required"
```

## 8. Offline Mode Synchronization Test

```yaml
appId: com.company.cmms
---
# Enable airplane mode
- executeAdbCommand: "shell settings put global airplane_mode_on 1"
- executeAdbCommand: "shell am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true"
- assertVisible: "No Connection"

# Create work order in offline mode
- tapOn: "Work Orders"
- tapOn: "Create New"
- tapOn: "Title" 
- inputText: "Offline Test WO"
- tapOn: "Description"
- inputText: "Created while offline"
- tapOn: "Priority"
- tapOn: "Medium"
- tapOn: "Submit"
- assertVisible: "Saved Offline"

# Disable airplane mode
- executeAdbCommand: "shell settings put global airplane_mode_on 0"
- executeAdbCommand: "shell am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false"
- wait: 10000

# Verify synchronization
- tapOn: "Sync Now"
- assertVisible: "Synchronizing"
- wait: 5000
- assertVisible: "Sync Complete"
- tapOn: "Work Orders"
- assertVisible: "Offline Test WO"
```

## 9. Work Request to Work Order Conversion Test

```yaml
appId: com.company.cmms
---
# Create work request
- launchApp
- tapOn: "Work Requests"
- tapOn: "Create New"
- tapOn: "Title"
- inputText: "Light Fixture Repair"
- tapOn: "Description"
- inputText: "Office 203 has flickering lights"
- tapOn: "Location"
- tapOn: "Office Building 1"
- tapOn: "Floor 2"
- tapOn: "Room 203"
- tapOn: "Priority"
- tapOn: "Medium"
- tapOn: "Submit"
- assertVisible: "Work Request Created"

# Login as admin
- tapOn: "Logout"
- tapOn: "Username"
- inputText: "admin"
- tapOn: "Password"
- inputText: "admin123"
- tapOn: "Login"

# Convert to work order
- tapOn: "Work Requests"
- tapOn: "Pending"
- tapOn: "Light Fixture Repair"
- tapOn: "Convert to Work Order"
- tapOn: "Assign To"
- tapOn: "Electrical Team"
- tapOn: "Due Date"
- tapOn: "15"  # Select date
- tapOn: "Convert"
- assertVisible: "Converted Successfully"
- tapOn: "Work Orders"
- assertVisible: "Light Fixture Repair"
```

## 10. Image Annotation Test

```yaml
appId: com.company.cmms
---
# Navigate to form with image annotation
- launchApp
- tapOn: "Work Orders"
- tapOn: "Create New"
- tapOn: "With Images"

# Add image with annotation
- tapOn: "Add Image"
- tapOn: "Choose from Gallery"
- tapOn: "test_image.jpg"
- assertVisible: "Image Preview"
- tapOn: "Annotate"

# Create annotations
- tapOn: {x: 30%, y: 40%}
- tapOn: "Add Arrow"
- drag: 
    start: {x: 30%, y: 40%}
    end: {x: 50%, y: 60%}
- tapOn: "Add Text"
- tapOn: {x: 55%, y: 65%}
- inputText: "Damaged component"
- tapOn: "Done"

# Save annotation and submit
- tapOn: "Save Annotation"
- assertVisible: "Annotation Saved"
- tapOn: "Submit"
- assertVisible: "Work Order with Annotated Image Created"
```

These examples provide a foundation for testing the CMMS application with Maestro. Each example can be expanded or modified to suit specific testing requirements and application behaviors.