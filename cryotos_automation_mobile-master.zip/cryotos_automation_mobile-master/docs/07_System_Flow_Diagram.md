# CMMS System Flow Diagram

![[Conditional Flow Diagram .jpg]]



## Key Relationships

1. **Work Request → Work Order**: Work requests can be converted to work orders
   
2. **Dynamic Workflows**:
   - Both work orders and schedules use the same dynamic form/workflow system
   - Conditional fields can trigger work order creation based on configured rules

3. **Schedule (Preventive Maintenance)**:
   - Separate from breakdown maintenance (work orders/requests)
   - Uses the dynamic workflow system
   - No direct conversion to work order
   
4. **Meter Reading → Work Request/Work Order** (Conditional):
   - Meter thresholds can trigger either work requests or work orders ONLY if specifically configured to do so
   - This is not a default or automatic path - it requires explicit configuration
   - When configured, threshold violations can create either a work request or work order based on settings

## Flow Logic

1. **Breakdown Maintenance Path**:
   - Unexpected issues reported as work requests
   - Can be converted to formal work orders
   - Work orders can be created directly without a request

2. **Preventive Maintenance Path**:
   - Scheduled maintenance activities managed via schedules
   - Uses same dynamic form system as work orders
   - Operates independently from breakdown maintenance

3. **Condition-Based Maintenance Path** (When Configured):
   - Meter readings can be configured to trigger work requests or work orders when thresholds are reached
   - This is only active if explicitly configured in the system
   - When configured, the system decides whether to create a work request or work order based on settings

This diagram represents the relationships between the main CMMS components and their interaction with the dynamic workflow system and conditional triggers.